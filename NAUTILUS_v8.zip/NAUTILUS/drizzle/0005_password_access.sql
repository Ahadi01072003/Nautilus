CREATE TABLE `auth_credentials` (
	`member_id` text PRIMARY KEY NOT NULL,
	`password_hash` text NOT NULL,
	`must_change` integer DEFAULT 1 NOT NULL,
	`version` integer DEFAULT 1 NOT NULL,
	`temporary_expires_at` text,
	`updated_at` text NOT NULL,
	`last_login_at` text,
	FOREIGN KEY (`member_id`) REFERENCES `members`(`id`) ON UPDATE no action ON DELETE no action,
	CONSTRAINT "auth_must_change" CHECK("auth_credentials"."must_change" in (0,1)),
	CONSTRAINT "auth_version" CHECK("auth_credentials"."version">0)
);
--> statement-breakpoint
CREATE TABLE `auth_events` (
	`id` text PRIMARY KEY NOT NULL,
	`member_id` text NOT NULL,
	`event` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`member_id`) REFERENCES `members`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE TABLE `auth_sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`member_id` text NOT NULL,
	`credential_version` integer NOT NULL,
	`expires_at` text NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`member_id`) REFERENCES `members`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE INDEX `auth_session_member` ON `auth_sessions` (`member_id`);--> statement-breakpoint
CREATE INDEX `auth_session_expiry` ON `auth_sessions` (`expires_at`);
--> statement-breakpoint
CREATE TRIGGER auth_credential_revoke AFTER UPDATE ON auth_credentials BEGIN
 DELETE FROM auth_sessions WHERE member_id=NEW.member_id AND credential_version!=NEW.version;
END;
--> statement-breakpoint
CREATE TRIGGER auth_member_revoke AFTER UPDATE OF active,profile,email ON members
 WHEN OLD.active!=NEW.active OR OLD.profile!=NEW.profile OR OLD.email!=NEW.email BEGIN
 DELETE FROM auth_sessions WHERE member_id=NEW.id;
END;
