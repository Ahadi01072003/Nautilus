CREATE TABLE `member_provisioning_batches` (
	`revision` text PRIMARY KEY NOT NULL,
	`owner_id` text NOT NULL,
	`member_count` integer NOT NULL,
	`applied_at` text NOT NULL,
	FOREIGN KEY (`owner_id`) REFERENCES `members`(`id`) ON UPDATE no action ON DELETE no action
);
