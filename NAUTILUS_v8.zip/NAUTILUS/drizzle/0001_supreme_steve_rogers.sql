ALTER TABLE `movements` ADD `expected_version` integer;
