CREATE TABLE `audits` (
	`id` text PRIMARY KEY NOT NULL,
	`action` text NOT NULL,
	`entity_id` text NOT NULL,
	`author_id` text NOT NULL,
	`author_name` text NOT NULL,
	`created_at` text NOT NULL,
	`detail` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `equipment` (
	`id` text PRIMARY KEY NOT NULL,
	`tag` text NOT NULL,
	`description` text NOT NULL,
	`type` text NOT NULL,
	`fuel_ids` text NOT NULL,
	`active` integer DEFAULT 1 NOT NULL
);
--> statement-breakpoint
CREATE UNIQUE INDEX `equipment_tag_unique` ON `equipment` (`tag`);--> statement-breakpoint
CREATE TABLE `fuels` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`unit` text NOT NULL,
	`integral` integer DEFAULT 0 NOT NULL,
	`capacity_milli` integer NOT NULL,
	`minimum_milli` integer NOT NULL,
	`stock_milli` integer NOT NULL,
	`lead_days` integer NOT NULL,
	`provisional` integer DEFAULT 1 NOT NULL,
	`active` integer DEFAULT 1 NOT NULL,
	`recipient` text DEFAULT '' NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	CONSTRAINT "stock_limits" CHECK("fuels"."stock_milli">=0 AND "fuels"."stock_milli"<="fuels"."capacity_milli" AND "fuels"."minimum_milli">=0 AND "fuels"."minimum_milli"<"fuels"."capacity_milli" AND "fuels"."lead_days" between 1 and 60)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `fuels_name_unique` ON `fuels` (`name`);--> statement-breakpoint
CREATE TABLE `holidays` (
	`date` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `members` (
	`id` text PRIMARY KEY NOT NULL,
	`auth_id` text,
	`email` text NOT NULL,
	`name` text NOT NULL,
	`role` text NOT NULL,
	`active` integer DEFAULT 1 NOT NULL,
	`created_at` text NOT NULL,
	CONSTRAINT "member_role" CHECK("members"."role" in ('admin','manager','operator'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `members_auth_id_unique` ON `members` (`auth_id`);--> statement-breakpoint
CREATE UNIQUE INDEX `members_email_unique` ON `members` (`email`);--> statement-breakpoint
CREATE TABLE `movements` (
	`id` text PRIMARY KEY NOT NULL,
	`operation_key` text NOT NULL,
	`fuel_id` text NOT NULL,
	`delta_milli` integer NOT NULL,
	`kind` text NOT NULL,
	`supply_id` text,
	`request_id` text,
	`balance_after_milli` integer,
	`occurred_at` text NOT NULL,
	`author_id` text NOT NULL,
	`author_name` text NOT NULL,
	`reason` text NOT NULL,
	FOREIGN KEY (`fuel_id`) REFERENCES `fuels`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`supply_id`) REFERENCES `supplies`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`request_id`) REFERENCES `requests`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`author_id`) REFERENCES `members`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `movements_operation_key_unique` ON `movements` (`operation_key`);--> statement-breakpoint
CREATE INDEX `idx_movements_fuel_date` ON `movements` (`fuel_id`,`occurred_at`);--> statement-breakpoint
CREATE TABLE `operators` (
	`id` text PRIMARY KEY NOT NULL,
	`name` text NOT NULL,
	`badge` text DEFAULT '' NOT NULL,
	`active` integer DEFAULT 1 NOT NULL
);
--> statement-breakpoint
CREATE TABLE `outbox` (
	`id` text PRIMARY KEY NOT NULL,
	`request_id` text NOT NULL,
	`recipient` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`last_error` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL,
	`sent_at` text,
	`locked_at` text,
	FOREIGN KEY (`request_id`) REFERENCES `requests`(`id`) ON UPDATE no action ON DELETE no action
);
--> statement-breakpoint
CREATE UNIQUE INDEX `outbox_request_id_unique` ON `outbox` (`request_id`);--> statement-breakpoint
CREATE TABLE `requests` (
	`id` text PRIMARY KEY NOT NULL,
	`fuel_id` text NOT NULL,
	`requested_milli` integer NOT NULL,
	`received_milli` integer DEFAULT 0 NOT NULL,
	`stock_reference_milli` integer NOT NULL,
	`opened_at` text NOT NULL,
	`deadline` text NOT NULL,
	`status` text DEFAULT 'open' NOT NULL,
	`recipient` text DEFAULT '' NOT NULL,
	FOREIGN KEY (`fuel_id`) REFERENCES `fuels`(`id`) ON UPDATE no action ON DELETE no action,
	CONSTRAINT "request_received" CHECK("requests"."received_milli">=0 AND "requests"."received_milli"<="requests"."requested_milli" AND "requests"."requested_milli">0)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_request_active_fuel` ON `requests` (`fuel_id`) WHERE "requests"."status" in ('open','purchasing','partial');--> statement-breakpoint
CREATE TABLE `supplies` (
	`id` text PRIMARY KEY NOT NULL,
	`operation_key` text NOT NULL,
	`fuel_id` text NOT NULL,
	`equipment_id` text NOT NULL,
	`operator_id` text NOT NULL,
	`quantity_milli` integer NOT NULL,
	`occurred_at` text NOT NULL,
	`created_at` text NOT NULL,
	`author_id` text NOT NULL,
	`author_name` text NOT NULL,
	`equipment_tag` text NOT NULL,
	`equipment_name` text NOT NULL,
	`operator_name` text NOT NULL,
	`fuel_name` text NOT NULL,
	`unit` text NOT NULL,
	`hourmeter_milli` integer,
	`hourmeter_end_milli` integer,
	`notes` text DEFAULT '' NOT NULL,
	`status` text DEFAULT 'confirmed' NOT NULL,
	`cancel_reason` text DEFAULT '' NOT NULL,
	FOREIGN KEY (`fuel_id`) REFERENCES `fuels`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`equipment_id`) REFERENCES `equipment`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`operator_id`) REFERENCES `operators`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`author_id`) REFERENCES `members`(`id`) ON UPDATE no action ON DELETE no action,
	CONSTRAINT "supply_qty" CHECK("supplies"."quantity_milli">0)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `supplies_operation_key_unique` ON `supplies` (`operation_key`);--> statement-breakpoint
CREATE INDEX `idx_supplies_date` ON `supplies` (`occurred_at`);--> statement-breakpoint
CREATE INDEX `idx_supplies_fuel_date` ON `supplies` (`fuel_id`,`occurred_at`);
