-- D1 applies this migration in a transaction. Keep foreign keys enabled.
--> statement-breakpoint
PRAGMA defer_foreign_keys=ON;
--> statement-breakpoint
DROP TRIGGER IF EXISTS audit_actor_guard;
--> statement-breakpoint
DROP TRIGGER IF EXISTS appointment_cancel_guard;
--> statement-breakpoint
DROP TRIGGER IF EXISTS appointment_insert_guard;
--> statement-breakpoint
DROP TRIGGER IF EXISTS appointment_schedule_guard;
--> statement-breakpoint
DROP TRIGGER IF EXISTS member_last_manager_delete;
--> statement-breakpoint
DROP TRIGGER IF EXISTS member_last_manager_update;
--> statement-breakpoint
DROP TRIGGER IF EXISTS movement_actor_guard;
--> statement-breakpoint
DROP TRIGGER IF EXISTS movement_apply;
--> statement-breakpoint
DROP TRIGGER IF EXISTS movement_guard;
--> statement-breakpoint
DROP TRIGGER IF EXISTS request_email;
--> statement-breakpoint
DROP TRIGGER IF EXISTS supply_actor_guard;
--> statement-breakpoint
DROP TRIGGER IF EXISTS supply_appointment_complete;
--> statement-breakpoint
DROP TRIGGER IF EXISTS supply_appointment_guard;
--> statement-breakpoint
DROP TRIGGER IF EXISTS supply_appointment_reopen;
--> statement-breakpoint
DROP TRIGGER IF EXISTS supply_debit;
--> statement-breakpoint
DROP TRIGGER IF EXISTS supply_guard;
--> statement-breakpoint
ALTER TABLE members ADD profile text NOT NULL DEFAULT 'requester' CHECK(profile IN ('requester','planner','fueler','manager'));
--> statement-breakpoint
ALTER TABLE members ADD notify_requests integer NOT NULL DEFAULT 1 CHECK(notify_requests IN (0,1));
--> statement-breakpoint
ALTER TABLE members ADD notify_schedule integer NOT NULL DEFAULT 1 CHECK(notify_schedule IN (0,1));
--> statement-breakpoint
UPDATE members SET profile=CASE WHEN role='admin' THEN 'manager' WHEN role='manager' THEN 'planner' WHEN can_fuel=1 THEN 'fueler' ELSE 'requester' END;
--> statement-breakpoint
UPDATE members SET role=CASE WHEN profile='manager' THEN 'admin' WHEN profile='planner' THEN 'manager' ELSE 'operator' END,can_fuel=CASE WHEN profile IN ('fueler','manager') THEN 1 ELSE 0 END;
--> statement-breakpoint
CREATE TABLE appointment_upgrade_backup AS SELECT * FROM appointments;
--> statement-breakpoint
DROP TABLE appointments;
--> statement-breakpoint
CREATE TABLE `appointments` (
	`id` text PRIMARY KEY NOT NULL,
	`operation_key` text NOT NULL,
	`equipment_id` text NOT NULL,
	`equipment_tag` text NOT NULL,
	`equipment_name` text NOT NULL,
	`fuel_id` text NOT NULL,
	`fuel_name` text NOT NULL,
	`hourmeter_milli` integer NOT NULL,
	`requester_id` text NOT NULL,
	`requester_name` text NOT NULL,
	`created_at` text NOT NULL,
	`status` text DEFAULT 'requested' NOT NULL,
	`scheduled_at` text,
	`assigned_member_id` text,
	`assigned_name` text,
	`scheduled_by_id` text,
	`scheduled_by_name` text,
	`updated_at` text NOT NULL,
	`completed_at` text,
	`cancel_reason` text DEFAULT '' NOT NULL,
	`cancelled_by_id` text,
	`cancelled_by_name` text,
	`version` integer DEFAULT 0 NOT NULL,
	FOREIGN KEY (`equipment_id`) REFERENCES `equipment`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`fuel_id`) REFERENCES `fuels`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`requester_id`) REFERENCES `members`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`assigned_member_id`) REFERENCES `members`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`scheduled_by_id`) REFERENCES `members`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`cancelled_by_id`) REFERENCES `members`(`id`) ON UPDATE no action ON DELETE no action,
	CONSTRAINT "appointment_hourmeter" CHECK("appointments"."hourmeter_milli">=0),
	CONSTRAINT "appointment_status" CHECK("appointments"."status" in ('requested','scheduled','completed','cancelled')),
	CONSTRAINT "appointment_schedule" CHECK("appointments"."status" not in ('scheduled','completed') OR "appointments"."scheduled_at" IS NOT NULL),
	CONSTRAINT "appointment_completed" CHECK("appointments"."status"!='completed' OR "appointments"."completed_at" IS NOT NULL)
);
--> statement-breakpoint
INSERT INTO appointments(id,operation_key,equipment_id,equipment_tag,equipment_name,fuel_id,fuel_name,hourmeter_milli,requester_id,requester_name,created_at,status,scheduled_at,assigned_member_id,assigned_name,scheduled_by_id,scheduled_by_name,updated_at,completed_at,cancel_reason,version) SELECT id,operation_key,equipment_id,equipment_tag,equipment_name,fuel_id,fuel_name,hourmeter_milli,requester_id,requester_name,created_at,status,scheduled_at,assigned_member_id,assigned_name,scheduled_by_id,scheduled_by_name,updated_at,completed_at,cancel_reason,version FROM appointment_upgrade_backup;
--> statement-breakpoint
DROP TABLE appointment_upgrade_backup;
--> statement-breakpoint
CREATE UNIQUE INDEX `appointments_operation_key_unique` ON `appointments` (`operation_key`);--> statement-breakpoint
CREATE INDEX `idx_appointments_created` ON `appointments` (`created_at`);--> statement-breakpoint
CREATE INDEX `idx_appointments_status_schedule` ON `appointments` (`status`,`scheduled_at`);--> statement-breakpoint
CREATE UNIQUE INDEX `idx_appointment_equipment_time` ON `appointments` (`equipment_id`,`scheduled_at`) WHERE "appointments"."status"='scheduled';--> statement-breakpoint

--> statement-breakpoint
CREATE TABLE `notification_events` (
	`id` text PRIMARY KEY NOT NULL,
	`kind` text NOT NULL,
	`entity_type` text NOT NULL,
	`entity_id` text NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	`created_at` text NOT NULL,
	CONSTRAINT "notification_kind" CHECK("notification_events"."kind" in ('requested','scheduled','completed','minimum','cancelled')),
	CONSTRAINT "notification_entity" CHECK("notification_events"."entity_type" in ('appointments','supplies','requests'))
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` text PRIMARY KEY NOT NULL,
	`event_id` text NOT NULL,
	`member_id` text NOT NULL,
	`status` text DEFAULT 'pending' NOT NULL,
	`attempts` integer DEFAULT 0 NOT NULL,
	`locked_at` text,
	`sent_at` text,
	`last_error` text DEFAULT '' NOT NULL,
	`created_at` text NOT NULL,
	FOREIGN KEY (`event_id`) REFERENCES `notification_events`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`member_id`) REFERENCES `members`(`id`) ON UPDATE no action ON DELETE no action,
	CONSTRAINT "notification_status" CHECK("notifications"."status" in ('pending','sending','sent','failed','skipped'))
);
--> statement-breakpoint
CREATE UNIQUE INDEX `idx_notification_event_member` ON `notifications` (`event_id`,`member_id`);--> statement-breakpoint
CREATE INDEX `idx_notifications_status` ON `notifications` (`status`,`created_at`);--> statement-breakpoint
CREATE TABLE `rate_limits` (
	`key` text PRIMARY KEY NOT NULL,
	`window_start` integer NOT NULL,
	`hits` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `idx_rate_window` ON `rate_limits` (`window_start`);--> statement-breakpoint

--> statement-breakpoint
UPDATE fuels SET recipient='';
--> statement-breakpoint
UPDATE requests SET recipient='';
--> statement-breakpoint
UPDATE outbox SET recipient='',status=CASE WHEN status='sent' THEN 'sent' ELSE 'skipped' END,last_error='',locked_at=NULL;
--> statement-breakpoint
UPDATE audits SET detail=json_remove(detail,'$.before.email','$.after.email','$.before.auth_id','$.before.recipient','$.after.recipient') WHERE json_valid(detail);
--> statement-breakpoint
-- Preserve pending workflows; historical completed items do not generate a mail burst.
INSERT OR IGNORE INTO notification_events(id,kind,entity_type,entity_id,version,created_at)
 SELECT 'requested:appointments:'||id||':0','requested','appointments',id,0,created_at FROM appointments WHERE status='requested';
--> statement-breakpoint
INSERT OR IGNORE INTO notification_events(id,kind,entity_type,entity_id,version,created_at)
 SELECT 'scheduled:appointments:'||id||':'||version,'scheduled','appointments',id,version,updated_at FROM appointments WHERE status='scheduled';
--> statement-breakpoint
INSERT OR IGNORE INTO notification_events(id,kind,entity_type,entity_id,version,created_at)
 SELECT 'minimum:requests:'||id||':0','minimum','requests',id,0,opened_at FROM requests WHERE status IN ('open','purchasing','partial');
--> statement-breakpoint
INSERT OR IGNORE INTO notifications(id,event_id,member_id,created_at)
 SELECT e.id||':'||m.id,e.id,m.id,e.created_at FROM notification_events e JOIN members m ON m.active=1 AND (m.profile='manager' OR (e.kind='requested' AND m.profile='planner' AND m.notify_requests=1) OR (e.kind='scheduled' AND m.profile='fueler' AND m.notify_schedule=1));
--> statement-breakpoint
PRAGMA defer_foreign_keys=OFF;
