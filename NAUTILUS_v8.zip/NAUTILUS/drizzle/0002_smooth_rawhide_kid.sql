CREATE TABLE `appointments` (
	`id` text PRIMARY KEY NOT NULL,
	`operation_key` text NOT NULL,
	`equipment_id` text NOT NULL,
	`equipment_tag` text NOT NULL,
	`equipment_name` text NOT NULL,
	`fuel_id` text NOT NULL,
	`fuel_name` text NOT NULL,
	`hourmeter_milli` integer NOT NULL,
	`requester_id` text NOT NULL,
	`requester_name` text NOT NULL,
	`created_at` text NOT NULL,
	`status` text DEFAULT 'requested' NOT NULL,
	`scheduled_at` text,
	`assigned_member_id` text,
	`assigned_name` text,
	`scheduled_by_id` text,
	`scheduled_by_name` text,
	`updated_at` text NOT NULL,
	`completed_at` text,
	`cancel_reason` text DEFAULT '' NOT NULL,
	`version` integer DEFAULT 0 NOT NULL,
	FOREIGN KEY (`equipment_id`) REFERENCES `equipment`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`fuel_id`) REFERENCES `fuels`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`requester_id`) REFERENCES `members`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`assigned_member_id`) REFERENCES `members`(`id`) ON UPDATE no action ON DELETE no action,
	FOREIGN KEY (`scheduled_by_id`) REFERENCES `members`(`id`) ON UPDATE no action ON DELETE no action,
	CONSTRAINT "appointment_hourmeter" CHECK("appointments"."hourmeter_milli">=0),
	CONSTRAINT "appointment_status" CHECK("appointments"."status" in ('requested','scheduled','completed','cancelled')),
	CONSTRAINT "appointment_schedule" CHECK("appointments"."status" not in ('scheduled','completed') OR ("appointments"."scheduled_at" IS NOT NULL AND "appointments"."assigned_member_id" IS NOT NULL)),
	CONSTRAINT "appointment_completed" CHECK("appointments"."status"!='completed' OR "appointments"."completed_at" IS NOT NULL)
);
--> statement-breakpoint
CREATE UNIQUE INDEX `appointments_operation_key_unique` ON `appointments` (`operation_key`);--> statement-breakpoint
CREATE INDEX `idx_appointments_created` ON `appointments` (`created_at`);--> statement-breakpoint
CREATE INDEX `idx_appointments_status_schedule` ON `appointments` (`status`,`scheduled_at`);--> statement-breakpoint
CREATE UNIQUE INDEX `idx_appointment_equipment_time` ON `appointments` (`equipment_id`,`scheduled_at`) WHERE "appointments"."status"='scheduled';--> statement-breakpoint
CREATE UNIQUE INDEX `idx_appointment_member_time` ON `appointments` (`assigned_member_id`,`scheduled_at`) WHERE "appointments"."status"='scheduled';--> statement-breakpoint
ALTER TABLE `members` ADD `can_fuel` integer DEFAULT 0 NOT NULL;--> statement-breakpoint
ALTER TABLE `supplies` ADD `appointment_id` text REFERENCES appointments(id);--> statement-breakpoint
CREATE UNIQUE INDEX `idx_supply_active_appointment` ON `supplies` (`appointment_id`) WHERE "supplies"."appointment_id" IS NOT NULL AND "supplies"."status"='confirmed';