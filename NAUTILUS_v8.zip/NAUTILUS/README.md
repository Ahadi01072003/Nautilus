# NAUTILUS · Abastecimentos

**Versão de desenvolvimento v8:** login por e-mail e senha, troca obrigatória no primeiro acesso e gestão interna dos usuários. Consulte [o guia de acesso e atualização](docs/acesso-por-senha.md) para executar esta versão e atualizar o site. As seções abaixo documentam a versão anterior exportada.

Sistema privado da Base Açu em React/Vinext, Worker do Sites e banco D1. O proprietário aprovou a publicação da revisão de 08/10/2026. O domínio do Resend foi verificado, a chave privada provisionada e a entrega do teste confirmada pelo proprietário, permitindo ativar os alertas na configuração de produção. Consulte [a revisão de segurança e regras](docs/revisao-seguranca-2026-10-08.md).

## Perfis e fluxo

Solicitante acompanha e cancela apenas seus pedidos ainda não agendados. Planejador organiza solicitações e agenda. Abastecedor vê a agenda compartilhada, realiza qualquer agendamento e consulta seus próprios registros. Gestor administra a operação, parâmetros, valores, estoque, cadastros, acessos, correções e exportação. As permissões são conferidas no servidor e no banco; a interface exibe somente os módulos permitidos.

Solicitar → agendar → registrar em Abastecimentos. A solicitação exige equipamento, TAG do cadastro, horímetro atual e combustível compatível. Responsável previsto opcional, sem exclusividade de execução. Quem efetivamente lança o consumo é identificado pela conta autenticada. O estoque só muda na realização ou nas entradas/conferências. Somente gestores podem registrar uma exceção sem agenda, com justificativa.

Valores são inteiros em milésimos; unidades inteiras não aceitam frações. Triggers e transações protegem estoque, capacidade, idempotência, autoria e versão. Estornos preservam registros e reabrem a solicitação. Compras não aumentam saldo; recebimentos reais podem ser parciais. Há um pedido de reposição ativo por combustível e conflito para o mesmo equipamento no mesmo horário exato; não há reserva de intervalos/duração.

Datas em UTC, apresentação em Brasília. Dias úteis excluem abertura, fins de semana e feriados. Saldos iniciais provisórios exigem conferência física. As regras do banco são instaladas por instruções preparadas antes do acesso autenticado; falha na instalação bloqueia o acesso. As migrações publicadas permanecem imutáveis.

## Acesso e proteção

Entrada individual pelo ChatGPT e cadastro prévio ativo com identidade vinculada. Não há promoção automática no primeiro login. Na atualização, o administrador existente passa a gestor; antigos gestores limitados passam a planejadores, operadores autorizados a abastecedores e demais operadores a solicitantes. Não conceder edição do projeto Sites aos usuários operacionais: o compartilhamento para visualização e as permissões internas são separados.

A equipe inicial pode ser provisionada por `MEMBER_PROVISIONING`, configuração privada marcada como segredo no Sites. A lista não fica no Git nem no navegador. Uma revisão é aplicada apenas uma vez, com batch atômico e auditoria, ancorada em um gestor existente, ativo e com identidade vinculada. IDs, identidades e histórico existentes são preservados; revisões já aplicadas não desfazem edições nem revogações posteriores. A aplicação ocorre na primeira requisição ao Worker ou acesso autenticado após implantação. Nunca receber essa configuração por formulário ou endpoint público.

API com origem validada, limite real de 32 KB, frequência por conta, consultas parametrizadas, respostas privadas sem cache e erros sem dados internos. Listagens de solicitações/abastecimentos têm páginas de 100 itens; exportação por período/combustível limitada a 10.000 registros, com neutralização de fórmulas CSV.

## Avisos

Todos os gestores ativos recebem solicitação, agendamento, realização, cancelamento e estoque mínimo. Planejadores recebem novas solicitações e abastecedores recebem agendamentos conforme opções do cadastro. Destinatários somente cadastrados e ativos; e-mails individuais, com conteúdo mínimo e links que exigem acesso ao sistema.

Configurar `RESEND_API_KEY` e `EMAIL_FROM` na configuração privada de execução do Sites. A chave deve ter somente permissão de envio, restrita ao domínio. `EMAIL_ENABLED` ausente ou diferente de `true` pausa os alertas. O gestor pode consultar o diagnóstico e solicitar um teste somente para sua própria conta autenticada; sem destinatários livres, sem dados operacionais e com limite de dois testes por minuto. Presença/formato da configuração não certificam o domínio ou a validade da chave no fornecedor. Segredos não são devolvidos ao navegador.

As mensagens contêm aviso resumido e link privado, sem TAG, nomes, combustível, horímetro, quantidades ou saldos. As ações e consultas processam até 20 avisos em segundo plano, iniciando tentativas por até 15 segundos e espaçando os envios em pelo menos 500 ms. Cada chamada ao Resend expira em 10 segundos. O fluxo da equipe atual cabe em um único lote; excesso e falhas posteriores continuam aguardando consultas, ações ou reenvio pelo gestor. A tela consulta a fila a cada cinco segundos enquanto há avisos pendentes/em envio e ao voltar à aba; depois retorna ao intervalo normal de 45 segundos. Avisos de estoque mínimo ligados a reposições recebidas ou canceladas são dispensados antes do envio. Reserva atômica, reconferência do destinatário, idempotência, espera progressiva e limite de tentativas protegem o envio. O Resend conserva a idempotência por 24 h; falhas ambíguas retomadas depois desse prazo exigem conferência antes de reenvio manual. Aceitação pelo fornecedor não confirma entrega na caixa de entrada. O gestor pode reiniciar tentativas com falha quando os alertas estiverem ativados. O token opcional `AUTOMATION_TOKEN` protege `POST /api/automation`; nenhuma rotina externa está ativa.

Veja [configuração e ativação do Resend](docs/configuracao-email-resend.md). Plugin de administração e credencial privada de execução são configurações distintas.

A CSP permite scripts inline necessários à hidratação React, restringe origens e bloqueia objetos. Uma política estrita com nonce por resposta exigiria integração adicional ao renderer; não afirmar proteção total contra XSS apenas por esse cabeçalho.

## Verificação

- `pnpm test`: dez grupos isolados, sem produção ou e-mails reais, incluindo integração Resend, teste restrito ao gestor e provisionamento privado da equipe.
- `pnpm exec tsc --noEmit --incremental false`.
- `pnpm exec eslint lib/permissions.ts lib/security.ts lib/notifications.ts lib/resend.ts lib/db.ts lib/service.ts app/appointments.tsx app/email-setup.tsx app/workspace.tsx 'app/api/[...path]/route.ts'`.
- `pnpm run build` e auditorias de dependências completa/produção.

`tests/verify_d1.mjs` usa o Miniflare fornecido pelo Wrangler instalado, incluindo seu adaptador oficial de opções para a versão atual. Os demais testes usam SQLite isolado e funções reais do serviço. A renderização React verifica navegação/ações; testes interativos de navegador ainda dependem do controle de navegador da prévia gerenciada.

## Projeto e manutenção

Preservar `.openai/hosting.json`, ID do projeto e público privado. Código no repositório do Sites; publicar somente após aprovação desta revisão, pelo fluxo oficial com fonte e artefato correspondentes. Nunca versionar segredos, `.env`, `.wrangler` ou `.sites-runtime`. Mudanças na configuração de produção só entram em vigor após implantação de uma versão.

O banco ativo é D1. Nenhum projeto Supabase recebeu dados; `docs/supabase-schema-draft.sql` é um rascunho antigo de portabilidade, não uma migração aplicada, e deve ser adaptado aos quatro perfis antes de eventual migração. Nenhum repositório GitHub externo foi criado. Identidade editável no [Figma](https://www.figma.com/design/NiLfMW17I3t6gFqJ0B1S3X).
