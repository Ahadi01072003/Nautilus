CREATE TRIGGER appointment_insert_guard BEFORE INSERT ON appointments BEGIN
 SELECT CASE WHEN NEW.status!='requested' THEN RAISE(ABORT,'Uma solicitação deve começar como solicitada') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM equipment e JOIN fuels f ON f.id=NEW.fuel_id WHERE e.id=NEW.equipment_id AND e.active=1 AND f.active=1 AND EXISTS(SELECT 1 FROM json_each(e.fuel_ids) WHERE value=f.id)) THEN RAISE(ABORT,'Equipamento incompatível ou inativo') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM members WHERE id=NEW.requester_id AND active=1 AND profile IN ('requester','manager')) THEN RAISE(ABORT,'Solicitante sem acesso ativo') END;
END;
--> statement-breakpoint
CREATE TRIGGER appointment_schedule_guard BEFORE UPDATE ON appointments WHEN NEW.status='scheduled' AND OLD.status IN ('requested','scheduled') BEGIN
 SELECT CASE WHEN NEW.assigned_member_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM members WHERE id=NEW.assigned_member_id AND active=1 AND profile IN ('fueler','manager')) THEN RAISE(ABORT,'Responsável sem autorização para abastecer') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM members WHERE id=NEW.scheduled_by_id AND active=1 AND profile IN ('planner','manager')) THEN RAISE(ABORT,'Agendamento sem autorização') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM equipment e JOIN fuels f ON f.id=NEW.fuel_id WHERE e.id=NEW.equipment_id AND e.active=1 AND f.active=1 AND EXISTS(SELECT 1 FROM json_each(e.fuel_ids) WHERE value=f.id)) THEN RAISE(ABORT,'Equipamento incompatível ou inativo') END;
END;
--> statement-breakpoint
CREATE TRIGGER supply_actor_guard BEFORE INSERT ON supplies BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM members WHERE id=NEW.author_id AND active=1 AND profile IN ('fueler','manager')) THEN RAISE(ABORT,'Acesso sem autorização para abastecer') END;
 SELECT CASE WHEN NEW.appointment_id IS NULL AND NOT EXISTS(SELECT 1 FROM members WHERE id=NEW.author_id AND active=1 AND profile='manager' AND length(trim(NEW.notes))>0) THEN RAISE(ABORT,'Registro sem agendamento exige gestor e justificativa') END;
END;
--> statement-breakpoint
CREATE TRIGGER supply_appointment_guard BEFORE INSERT ON supplies WHEN NEW.appointment_id IS NOT NULL BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM appointments a JOIN members m ON m.id=NEW.author_id WHERE a.id=NEW.appointment_id AND a.status='scheduled' AND a.equipment_id=NEW.equipment_id AND a.fuel_id=NEW.fuel_id AND NEW.hourmeter_milli>=a.hourmeter_milli AND NEW.occurred_at>=a.created_at AND m.active=1 AND m.profile IN ('fueler','manager')) THEN RAISE(ABORT,'Agendamento indisponível ou abastecimento incompatível') END;
END;
--> statement-breakpoint
CREATE TRIGGER supply_appointment_complete AFTER INSERT ON supplies WHEN NEW.appointment_id IS NOT NULL BEGIN
 UPDATE appointments SET status='completed',completed_at=NEW.created_at,updated_at=NEW.created_at,version=version+1 WHERE id=NEW.appointment_id;
END;
--> statement-breakpoint
CREATE TRIGGER supply_appointment_reopen AFTER UPDATE OF status ON supplies WHEN OLD.status='confirmed' AND NEW.status='cancelled' AND NEW.appointment_id IS NOT NULL BEGIN
 UPDATE appointments SET status='requested',scheduled_at=NULL,assigned_member_id=NULL,assigned_name=NULL,scheduled_by_id=NULL,scheduled_by_name=NULL,completed_at=NULL,updated_at=strftime('%Y-%m-%dT%H:%M:%fZ','now'),version=version+1 WHERE id=NEW.appointment_id AND status='completed';
END;
