CREATE TRIGGER movement_guard BEFORE INSERT ON movements BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM fuels WHERE id=NEW.fuel_id AND active=1) THEN RAISE(ABORT,'Combustível indisponível') END;
 SELECT CASE WHEN NEW.expected_version IS NOT NULL AND NEW.expected_version!=(SELECT version FROM fuels WHERE id=NEW.fuel_id) THEN RAISE(ABORT,'Estoque alterado durante conferência') END;
 SELECT CASE WHEN (SELECT integral FROM fuels WHERE id=NEW.fuel_id)=1 AND NEW.delta_milli % 1000 != 0 THEN RAISE(ABORT,'Quantidade deve ser inteira') END;
 SELECT CASE WHEN (SELECT stock_milli FROM fuels WHERE id=NEW.fuel_id)+NEW.delta_milli < 0 THEN RAISE(ABORT,'Estoque insuficiente') END;
 SELECT CASE WHEN (SELECT stock_milli FROM fuels WHERE id=NEW.fuel_id)+NEW.delta_milli > (SELECT capacity_milli FROM fuels WHERE id=NEW.fuel_id) THEN RAISE(ABORT,'Quantidade excede a capacidade máxima') END;
 SELECT CASE WHEN NEW.kind='receipt' AND NEW.request_id IS NOT NULL AND NOT EXISTS(SELECT 1 FROM requests WHERE id=NEW.request_id AND fuel_id=NEW.fuel_id AND status IN ('open','purchasing','partial') AND received_milli+NEW.delta_milli<=requested_milli AND NEW.delta_milli>0) THEN RAISE(ABORT,'Recebimento excede a solicitação ou ela está encerrada') END;
END;
--> statement-breakpoint
CREATE TRIGGER movement_apply AFTER INSERT ON movements BEGIN
 UPDATE fuels SET stock_milli=stock_milli+NEW.delta_milli,version=version+1 WHERE id=NEW.fuel_id;
 UPDATE movements SET balance_after_milli=(SELECT stock_milli FROM fuels WHERE id=NEW.fuel_id) WHERE id=NEW.id;
 UPDATE requests SET received_milli=received_milli+NEW.delta_milli,status= CASE WHEN received_milli+NEW.delta_milli=requested_milli THEN 'received' ELSE 'partial' END WHERE id=NEW.request_id AND NEW.kind='receipt';
END;
--> statement-breakpoint
CREATE TRIGGER supply_guard BEFORE INSERT ON supplies BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM equipment WHERE id=NEW.equipment_id AND active=1 AND EXISTS(SELECT 1 FROM json_each(equipment.fuel_ids) WHERE value=NEW.fuel_id)) THEN RAISE(ABORT,'Equipamento incompatível ou inativo') END;
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM operators WHERE id=NEW.operator_id AND active=1) THEN RAISE(ABORT,'Operador inativo') END;
 SELECT CASE WHEN NEW.quantity_milli<=0 THEN RAISE(ABORT,'Quantidade inválida') END;
END;
--> statement-breakpoint
CREATE TRIGGER supply_debit AFTER INSERT ON supplies BEGIN
 INSERT INTO movements(id,operation_key,fuel_id,delta_milli,kind,supply_id,occurred_at,author_id,author_name,reason) VALUES(NEW.id,'supply:'||NEW.operation_key,NEW.fuel_id,-NEW.quantity_milli,'debit',NEW.id,NEW.created_at,NEW.author_id,NEW.author_name,'Abastecimento '||NEW.equipment_tag);
END;
