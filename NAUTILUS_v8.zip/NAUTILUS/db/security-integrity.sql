CREATE TRIGGER member_last_manager_update BEFORE UPDATE OF active,profile ON members WHEN OLD.profile='manager' AND OLD.active=1 AND (NEW.profile!='manager' OR NEW.active!=1) BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM members WHERE id!=OLD.id AND active=1 AND profile='manager') THEN RAISE(ABORT,'Mantenha ao menos um gestor ativo') END;
END;
--> statement-breakpoint
CREATE TRIGGER audit_actor_guard BEFORE INSERT ON audits BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM members WHERE id=NEW.author_id AND active=1 AND (
  profile='manager' OR
  (profile='planner' AND NEW.action IN ('Abastecimento agendado','Abastecimento reagendado','Solicitação de abastecimento cancelada')) OR
  (profile='fueler' AND NEW.action='Abastecimento registrado') OR
  (profile='requester' AND NEW.action IN ('Abastecimento solicitado','Solicitação de abastecimento cancelada') AND EXISTS(SELECT 1 FROM appointments WHERE id=NEW.entity_id AND requester_id=NEW.author_id))
 )) THEN RAISE(ABORT,'Auditoria sem autorização') END;
END;
--> statement-breakpoint
CREATE TRIGGER member_last_manager_delete BEFORE DELETE ON members WHEN OLD.profile='manager' AND OLD.active=1 BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM members WHERE id!=OLD.id AND active=1 AND profile='manager') THEN RAISE(ABORT,'Mantenha ao menos um gestor ativo') END;
END;
--> statement-breakpoint
CREATE TRIGGER appointment_cancel_guard BEFORE UPDATE OF status ON appointments WHEN NEW.status='cancelled' AND OLD.status IN ('requested','scheduled') BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM members WHERE id=NEW.cancelled_by_id AND active=1 AND (profile IN ('planner','manager') OR (profile='requester' AND id=OLD.requester_id AND OLD.status='requested'))) THEN RAISE(ABORT,'Cancelamento sem autorização') END;
END;
--> statement-breakpoint
CREATE TRIGGER movement_actor_guard BEFORE INSERT ON movements BEGIN
 SELECT CASE WHEN NOT EXISTS(SELECT 1 FROM members WHERE id=NEW.author_id AND active=1 AND (profile='manager' OR (NEW.kind='debit' AND profile='fueler'))) THEN RAISE(ABORT,'Estoque sem autorização') END;
END;
