import {readFileSync,writeFileSync,mkdirSync,existsSync,readdirSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createRequire} from 'node:module';
import {fileURLToPath} from 'node:url';
import path from 'node:path';

// Ferramenta adicional da exportação. Não integra o Worker publicado.
const root=fileURLToPath(new URL('../',import.meta.url));
const args=process.argv.slice(2);
if(args.some(arg=>arg!=='--com-dados'))throw new Error('Use sem argumentos ou somente --com-dados.');
const state=path.join(root,'.wrangler/state');
if(existsSync(state)&&readdirSync(state).length)throw new Error('Já existe um banco local. Use outra pasta de extração para preservar os dados existentes.');
const folder=path.join(root,'exportacao/banco');
const personal=args.includes('--com-dados');
let sql=readFileSync(path.join(folder,personal?'restauracao-completa.sql':'estrutura.sql'),'utf8');
const time=new Date().toISOString();
sql+=`\nINSERT INTO members(id,auth_id,email,name,role,profile,can_fuel,active,created_at) VALUES('nautilus-local-manager','local_seedy','seedy@sites.test','Gestor local de desenvolvimento','admin','manager',1,1,'${time}');\n`;
if(!personal){
 sql+="INSERT INTO fuels(id,name,unit,integral,capacity_milli,minimum_milli,stock_milli,lead_days,provisional) VALUES('diesel','Diesel','L',0,1000000,100000,0,2,1),('gas','Gás','cilindros',1,5000,2000,0,5,1);\n";
 sql+=readFileSync(path.join(folder,'regras-integridade.sql'),'utf8');
}
sql+='\n'+readFileSync(path.join(root,'drizzle/0005_password_access.sql'),'utf8');
mkdirSync(path.join(root,'.wrangler'),{recursive:true});
const file=path.join(root,'.wrangler/nautilus-export-init.sql');
writeFileSync(file,sql,{mode:0o600});
const envFile=path.join(root,'.env.local');
if(existsSync(envFile))throw new Error('Já existe .env.local. Revise sua configuração antes de preparar este ambiente.');
writeFileSync(envFile,'EMAIL_ENABLED=false\nRESEND_API_KEY=\nEMAIL_FROM=\nAUTOMATION_TOKEN=\nMEMBER_PROVISIONING=\n',{mode:0o600});
const require=createRequire(import.meta.url);
const cli=path.join(path.dirname(require.resolve('wrangler/package.json')),'bin/wrangler.js');
const result=spawnSync(process.execPath,[cli,'d1','execute','DB','--local','--config',path.join(root,'exportacao/wrangler.local.json'),'--persist-to',state,'--file',file,'--yes'],{cwd:root,encoding:'utf8',maxBuffer:10*1024*1024,env:{...process.env,CLOUDFLARE_CF_FETCH_ENABLED:'false',WRANGLER_SEND_METRICS:'false',WRANGLER_WRITE_LOGS:'false'}});
if(result.error)throw result.error;
if(result.status!==0){console.error(result.stderr||result.stdout);process.exit(result.status??1);}
console.log('Banco local preparado. E-mails pausados. Execute pnpm dev e entre como gestor local em http://localhost:5173.');
