import {existsSync,mkdirSync,readdirSync,writeFileSync,readFileSync} from 'node:fs';
import {spawnSync} from 'node:child_process';
import {fileURLToPath} from 'node:url';
import path from 'node:path';
const root=fileURLToPath(new URL('../',import.meta.url));
const state=path.join(root,'.wrangler/state'),tooling=path.join(root,'.wrangler');
const existing=existsSync(state)&&readdirSync(state).length>0;
mkdirSync(tooling,{recursive:true});
const envFile=path.join(root,'.env.local');
if(!existsSync(envFile))writeFileSync(envFile,'EMAIL_ENABLED=false\nRESEND_API_KEY=\nEMAIL_FROM=\nAUTOMATION_TOKEN=\nMEMBER_PROVISIONING=\n',{mode:0o600});
function wrangler(args){
 const result=spawnSync(process.execPath,['--import','./scripts/sites-env.mjs','./node_modules/wrangler/bin/wrangler.js','d1',...args,'--local','--config','exportacao/wrangler.local.json','--persist-to',state,...(args[0]==='execute'?['--yes']:[])],{cwd:root,encoding:'utf8',maxBuffer:10*1024*1024,env:{...process.env,CLOUDFLARE_CF_FETCH_ENABLED:'false',WRANGLER_SEND_METRICS:'false',WRANGLER_WRITE_LOGS:'false'}});
 if(result.error)throw result.error;
 if(result.status!==0){console.error(result.stderr||result.stdout);process.exit(result.status??1);}
}
if(!existing){
 wrangler(['migrations','apply','DB']);
 const time=new Date().toISOString();
 const seed=path.join(tooling,'development-seed.sql');
 writeFileSync(seed,"INSERT INTO members(id,auth_id,email,name,role,profile,can_fuel,active,created_at) VALUES('nautilus-local-manager','local_seedy','seedy@sites.test','Gestor local de desenvolvimento','admin','manager',1,1,'"+time+"');\n"+"INSERT INTO fuels(id,name,unit,integral,capacity_milli,minimum_milli,stock_milli,lead_days,provisional) VALUES('diesel','Diesel','L',0,1000000,100000,0,2,1),('gas','Gás','cilindros',1,5000,2000,0,5,1);\n",{mode:0o600});
 wrangler(['execute','DB','--file',seed]);
 console.log('Banco de desenvolvimento vazio criado pelas migrações. Gestor exclusivamente local: seedy@sites.test.');
}else{
 // Atualização aditiva da cópia local v7. Nunca toca dados de produção nem redefine contas.
 const upgrade=readFileSync(path.join(root,'drizzle/0005_password_access.sql'),'utf8').replaceAll('CREATE TABLE ','CREATE TABLE IF NOT EXISTS ').replaceAll('CREATE INDEX ','CREATE INDEX IF NOT EXISTS ').replaceAll('CREATE TRIGGER ','CREATE TRIGGER IF NOT EXISTS ');
 const file=path.join(tooling,'development-auth-upgrade.sql');writeFileSync(file,upgrade,{mode:0o600});
 wrangler(['execute','DB','--file',file]);
 console.log('Banco local existente preservado; estruturas de acesso verificadas sem sobrescrever cadastros.');
}
console.log('Nenhuma operação remota executada. E-mails pausados no arquivo local gerado; configurações existentes foram preservadas.');
