import integritySQL from '@/db/integrity.sql?raw';
import schedulingSQL from '@/db/scheduling-integrity.sql?raw';
import securitySQL from '@/db/security-integrity.sql?raw';
import {db} from './db';
let ready:Promise<void>|null=null;
/** Fail closed: all database entry points await guard installation before use. */
export function ensureIntegrity(){
 if(!ready){
  const statements=(integritySQL+'\n--> statement-breakpoint\n'+schedulingSQL+'\n--> statement-breakpoint\n'+securitySQL).split('--> statement-breakpoint').map(sql=>sql.trim()).filter(Boolean).map(sql=>sql.replace('CREATE TRIGGER ','CREATE TRIGGER IF NOT EXISTS '));
  ready=db().batch(statements.map(sql=>db().prepare(sql))).then(()=>{}).catch(error=>{ready=null;throw error;});
 }
 return ready;
}
