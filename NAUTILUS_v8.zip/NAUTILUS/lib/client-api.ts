export async function apiRequest<T>(path:string,body?:unknown):Promise<T> {
 let response:Response;
 try {
  response=await fetch(path,{method:body===undefined?'GET':'POST',cache:'no-store',credentials:'same-origin',signal:AbortSignal.timeout(15000),...(body===undefined?{}:{headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})});
 }catch {throw new Error('Não foi possível conectar. Confira sua conexão e tente novamente.');}
 let result;
 try{result=await response.json();}catch{throw new Error('O servidor não respondeu como esperado. Tente novamente.');}
 if(!response.ok){
  if(response.status===401&&!path.startsWith('/api/auth/'))window.dispatchEvent(new Event('nautilus:session-expired'));
  const message=result&&typeof result==='object'&&'error' in result&&typeof result.error==='string'?result.error:'Não foi possível concluir.';
  throw new Error(message);
 }
 return result as T;
}
