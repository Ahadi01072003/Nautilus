import {scheduledDate,appointmentVersion} from './scheduling';
import {Member,Profile,isManager,canPlan,canRecord,requireProfile,modules,legacyRole,profiles} from './permissions';
import {notificationStatements,minimumStatements,flushNotifications} from './notifications';
import {emailSetup,sendResendEmail} from './resend';
import {ensureIntegrity} from './integrity';
import {ensureMemberProvisioning} from './member-provisioning';
import {db} from './db';
import {sessionMember} from './auth';
import {hashPassword,validatePassword,TEMPORARY_PASSWORD_DAYS} from './password';
import {AppError,businessDeadline,email,required,text,milli,dateISO,calendarDate,safeCSV} from './domain';
// eslint-disable-next-line @typescript-eslint/no-explicit-any -- Colunas e aliases SQL variam por consulta; entradas passam pelos validadores abaixo.
type Row=Record<string,any>;
const id=()=>crypto.randomUUID();
const now=()=>new Date().toISOString();
const stmt=(query:string,...values:unknown[])=>db().prepare(query).bind(...values);
const all=async(query:string,...values:unknown[])=>(await stmt(query,...values).all<Row>()).results;
const first=(query:string,...values:unknown[])=>stmt(query,...values).first<Row>();
export async function actor(){
 await ensureIntegrity();
 await ensureMemberProvisioning();
 const member=await sessionMember();
 if(!member)throw new AppError('Sua sessão expirou. Entre com seu e-mail e senha.',401);
 if(member.must_change)throw new AppError('Crie e confirme sua nova senha antes de acessar a operação.',403);
 return member as Member;
}
async function requireFresh(a:Member){const current=await first('SELECT profile,active FROM members WHERE id=?',a.id);if(a.session_hash&&!await first('SELECT s.token_hash FROM auth_sessions s JOIN auth_credentials c ON c.member_id=s.member_id WHERE s.token_hash=? AND s.credential_version=c.version AND s.expires_at>? AND c.must_change=0',a.session_hash,now()))throw new AppError('Sua sessão expirou. Entre novamente.',401);if(!current?.active||current.profile!==a.profile)throw new AppError('Seu acesso mudou. Atualize a tela.',403);}
function audit(a:Row,action:string,entityId:string,detail:unknown){return stmt('INSERT INTO audits(id,action,entity_id,author_id,author_name,created_at,detail) VALUES(?,?,?,?,?,?,?)',id(),action,entityId,a.id,a.name,now(),JSON.stringify(detail));}
function auditChange(a:Row,action:string,entityId:string,detail:unknown){return stmt('INSERT INTO audits(id,action,entity_id,author_id,author_name,created_at,detail) SELECT ?,?,?,?,?,?,? WHERE changes()>0',id(),action,entityId,a.id,a.name,now(),JSON.stringify(detail));}
async function alertStatements(fuelId:string,leadDays?:number){
 const fuel=await first('SELECT * FROM fuels WHERE id=?',fuelId);const lead=leadDays??fuel?.lead_days;if(lead===undefined)return [];
 const hs=await all('SELECT date FROM holidays');const opened=now();const deadline=businessDeadline(opened,lead,hs.map(h=>h.date));
 return [stmt("INSERT INTO requests(id,fuel_id,requested_milli,stock_reference_milli,opened_at,deadline,status,recipient) SELECT ?,id,capacity_milli-stock_milli,stock_milli,?,?,'open','' FROM fuels WHERE id=? AND active=1 AND stock_milli<=minimum_milli AND NOT EXISTS(SELECT 1 FROM requests WHERE fuel_id=? AND status IN ('open','purchasing','partial'))",id(),opened,deadline,fuelId,fuelId),...minimumStatements(fuelId,opened)];
}
export async function state(a:Member,page=0,filters:{search?:string|null;fuel?:string|null;start?:string|null;end?:string|null}={}){
 if(!Number.isSafeInteger(page)||page<0||page>10000)throw new AppError('Página inválida.');
 const manager=isManager(a),requester=a.profile==='requester',fueler=a.profile==='fueler',limit=100,offset=page*limit;
 const appointmentWhere=requester?' WHERE a.requester_id=?':fueler?" WHERE a.status='scheduled' OR EXISTS(SELECT 1 FROM supplies own WHERE own.appointment_id=a.id AND own.author_id=?)":'';
 const appointmentArgs=requester||fueler?[a.id]:[];
 const clauses:string[]=manager?[]:['s.author_id=?'],supplyArgs:unknown[]=manager?[]:[a.id];
 const search=text(filters.search,120),fuel=text(filters.fuel,100),start=filters.start?calendarDate(filters.start):'',end=filters.end?calendarDate(filters.end):'';
 if(start&&end&&start>end)throw new AppError('A data inicial deve ser anterior ou igual à data final.');
 if(fuel&&fuel!=='all'){clauses.push('s.fuel_id=?');supplyArgs.push(fuel);}
 if(start){clauses.push('s.occurred_at>=?');supplyArgs.push(new Date(start+'T00:00:00-03:00').toISOString());}
 if(end){clauses.push('s.occurred_at<=?');supplyArgs.push(new Date(end+'T23:59:59.999-03:00').toISOString());}
 if(search){
  // SQLite lower() cobre ASCII; normalize também as maiúsculas acentuadas dos nomes em português.
  const columns="s.id||' '||coalesce(s.appointment_id,'')||' '||s.equipment_tag||' '||s.equipment_name||' '||s.operator_name||' '||s.author_name||' '||s.fuel_name";
  const normalized=Array.from('ÀÁÂÃÄÈÉÊËÌÍÎÏÒÓÔÕÖÙÚÛÜÇÑ').reduce((sql,letter)=>"replace("+sql+",'"+letter+"','"+letter.toLowerCase()+"')",columns);
  clauses.push('instr(lower('+normalized+'),?)>0');supplyArgs.push(search.toLocaleLowerCase('pt-BR'));
 }
 const supplyWhere=clauses.length?' WHERE '+clauses.join(' AND '):'';

 const [fuels,equipment,operators,supplies,movements,requests,holidays,members,audits,stats,daily,appointments,executors,notifications,appointmentCount,supplyCount]=await Promise.all([
 all(manager?'SELECT * FROM fuels ORDER BY name':`SELECT id,name,unit,integral,active${fueler?',stock_milli':''} FROM fuels WHERE active=1 ORDER BY name`),
 all(manager?'SELECT * FROM equipment ORDER BY tag':"SELECT id,tag,description,type,fuel_ids,active FROM equipment WHERE active=1 ORDER BY tag"),
 manager||fueler?all('SELECT id,name,badge,active FROM operators'+(manager?'':' WHERE active=1')+' ORDER BY name'):Promise.resolve([]),
 manager||fueler?all('SELECT s.id,s.appointment_id,s.fuel_id,s.equipment_id,s.operator_id,s.quantity_milli,s.occurred_at,s.created_at,s.author_id,s.author_name,s.equipment_tag,s.equipment_name,s.operator_name,s.fuel_name,s.unit,s.hourmeter_milli,s.hourmeter_end_milli,s.notes,s.status,s.cancel_reason FROM supplies s'+supplyWhere+' ORDER BY s.occurred_at DESC LIMIT ? OFFSET ?',...supplyArgs,limit,offset):Promise.resolve([]),
 manager?all('SELECT m.*,f.name fuel_name,f.unit FROM movements m JOIN fuels f ON f.id=m.fuel_id ORDER BY m.occurred_at DESC LIMIT 200'):Promise.resolve([]),
 manager?all("SELECT r.id,r.fuel_id,r.requested_milli,r.received_milli,r.stock_reference_milli,r.opened_at,r.deadline,r.status,f.name fuel_name,f.unit,f.stock_milli,f.minimum_milli FROM requests r JOIN fuels f ON f.id=r.fuel_id ORDER BY r.opened_at DESC LIMIT 200"):Promise.resolve([]),
 manager?all('SELECT * FROM holidays ORDER BY date'):Promise.resolve([]),
 manager?all('SELECT m.id,m.email,m.name,m.profile role,m.notify_requests,m.notify_schedule,m.active,m.created_at,c.must_change mustChangePassword,c.temporary_expires_at temporaryExpiresAt,c.last_login_at lastLoginAt,CASE WHEN c.member_id IS NULL THEN 0 ELSE 1 END passwordConfigured FROM members m LEFT JOIN auth_credentials c ON c.member_id=m.id ORDER BY m.name'):Promise.resolve([]),
 manager?all('SELECT * FROM audits ORDER BY created_at DESC LIMIT 100'):Promise.resolve([]),
 manager?all("SELECT fuel_id,COUNT(*) count,SUM(quantity_milli) quantity_milli FROM supplies WHERE status='confirmed' AND substr(datetime(occurred_at,'-3 hours'),1,7)=? GROUP BY fuel_id",new Intl.DateTimeFormat('sv-SE',{timeZone:'America/Sao_Paulo',year:'numeric',month:'2-digit'}).format(new Date())):Promise.resolve([]),
 manager?all("SELECT substr(datetime(occurred_at,'-3 hours'),1,10) day,fuel_id,SUM(quantity_milli) quantity_milli FROM supplies WHERE status='confirmed' AND occurred_at>=? GROUP BY day,fuel_id ORDER BY day",new Date(Date.now()-28*86400000).toISOString()):Promise.resolve([]),
  all(`SELECT a.id,a.equipment_id,a.equipment_tag,a.equipment_name,a.fuel_id,a.fuel_name,a.hourmeter_milli,a.requester_id,a.requester_name,a.created_at,a.status,a.scheduled_at,a.assigned_member_id,a.assigned_name,a.updated_at,a.completed_at,a.cancel_reason,a.version,s.id supply_id FROM appointments a LEFT JOIN supplies s ON s.appointment_id=a.id AND s.status='confirmed'${appointmentWhere} ORDER BY CASE WHEN a.status='scheduled' THEN 0 WHEN a.status='requested' THEN 1 ELSE 2 END,a.created_at DESC LIMIT ? OFFSET ?`,...appointmentArgs,limit,offset),
 canPlan(a)?all("SELECT id,name FROM members WHERE active=1 AND profile IN ('fueler','manager') ORDER BY name"):Promise.resolve([]),
 manager?all('SELECT n.id,n.status,n.attempts,n.sent_at,n.last_error,n.created_at,e.kind,m.name recipient_name FROM notifications n JOIN notification_events e ON e.id=n.event_id JOIN members m ON m.id=n.member_id ORDER BY n.created_at DESC LIMIT 100'):Promise.resolve([]),
 first('SELECT count(*) total FROM appointments a'+appointmentWhere,...appointmentArgs),
 manager||fueler?first('SELECT count(*) total FROM supplies s'+supplyWhere,...supplyArgs):Promise.resolve({total:0})
 ]);
 await requireFresh(a);
 return {actor:{id:a.id,name:a.name,role:a.profile,canFuel:canRecord(a),canPlan:canPlan(a),canRequest:a.profile==='requester'||manager,modules:modules(a)},fuels,equipment:equipment.map(e=>({...e,fuel_ids:JSON.parse(e.fuel_ids)})),operators,supplies,movements,requests,holidays,members,audits,stats,daily,appointments,executors,notifications,pagination:{page,limit,appointments:appointmentCount?.total||0,supplies:supplyCount?.total||0},emailReady:emailSetup().ready&&emailSetup().enabled,...(manager?{emailSetup:emailSetup()}:{}),generatedAt:now()};
}
export async function mutate(path:string,b:Row,a:Member){
 await requireFresh(a);
 const t=now();
 if(path==='appointments'){
  requireProfile(a,['requester','manager']);
  const key=required(b.operationKey,'Identificador da solicitação',100);
  const previous=await first('SELECT id,requester_id FROM appointments WHERE operation_key=?',key);
  if(previous){if(previous.requester_id!==a.id)throw new AppError('Esta solicitação pertence a outra pessoa.',403);return {id:previous.id,repeated:true};}
  const [e,f]=await Promise.all([first('SELECT * FROM equipment WHERE id=? AND active=1',required(b.equipmentId,'Equipamento')),first('SELECT * FROM fuels WHERE id=? AND active=1',required(b.fuelId,'Tipo de abastecimento'))]);
  if(!e||!f)throw new AppError('Selecione equipamento e combustível ativos.');
  if(!JSON.parse(e.fuel_ids).includes(f.id))throw new AppError('Combustível incompatível com este equipamento.');
  const hour=milli(b.hourmeter,false,true),created=id();
  await db().batch([
   stmt('INSERT INTO appointments(id,operation_key,equipment_id,equipment_tag,equipment_name,fuel_id,fuel_name,hourmeter_milli,requester_id,requester_name,created_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)',created,key,e.id,e.tag,e.description,f.id,f.name,hour,a.id,a.name,t,t),
   audit(a,'Abastecimento solicitado',created,{equipment:e.tag,fuel:f.name,hourmeter:hour/1000}),...notificationStatements('requested',created,t)
  ]);return {id:created};
 }
 if(path==='appointments/schedule'){
  requireProfile(a,['planner','manager']);const aid=required(b.id,'Solicitação'),version=appointmentVersion(b.version),date=scheduledDate(b.scheduledAt);
  const assigned=b.assignedMemberId?await first("SELECT id,name FROM members WHERE id=? AND active=1 AND profile IN ('fueler','manager')",required(b.assignedMemberId,'Responsável previsto')):null;
  if(b.assignedMemberId&&!assigned)throw new AppError('Escolha uma pessoa ativa da equipe de abastecimento.');
  const previous=await first('SELECT * FROM appointments WHERE id=?',aid);
  if(!previous||!['requested','scheduled'].includes(previous.status))throw new AppError('Solicitação já encerrada ou não encontrada.',409);
  const results=await db().batch([
   stmt("UPDATE appointments SET status='scheduled',scheduled_at=?,assigned_member_id=?,assigned_name=?,scheduled_by_id=?,scheduled_by_name=?,updated_at=?,version=version+1 WHERE id=? AND version=? AND status IN ('requested','scheduled')",date,assigned?.id||null,assigned?.name||null,a.id,a.name,t,aid,version),
   auditChange(a,previous.status==='scheduled'?'Abastecimento reagendado':'Abastecimento agendado',aid,{before:{scheduledAt:previous.scheduled_at,assignedId:previous.assigned_member_id},after:{scheduledAt:date,assignedId:assigned?.id||null,assignedName:assigned?.name||null}}),...notificationStatements('scheduled',aid,t,version+1,'appointments',true)
  ]);
  if(!results[0].meta.changes)throw new AppError('A solicitação mudou. Atualize a tela antes de agendar.',409);
  return {ok:true};
 }
 if(path==='appointments/cancel'){
  requireProfile(a,['requester','planner','manager']);
  const aid=required(b.id,'Solicitação'),version=appointmentVersion(b.version),reason=required(b.reason,'Justificativa',1200),previous=await first('SELECT * FROM appointments WHERE id=?'+(a.profile==='requester'?' AND requester_id=?':''),aid,...(a.profile==='requester'?[a.id]:[]));
  if(!previous||!['requested','scheduled'].includes(previous.status))throw new AppError('Solicitação já encerrada ou não encontrada.',409);
  if(!canPlan(a)&&!(a.profile==='requester'&&previous.requester_id===a.id&&previous.status==='requested'))throw new AppError('Seu perfil não permite cancelar esta solicitação.',403);
  const results=await db().batch([
   stmt("UPDATE appointments SET status='cancelled',cancel_reason=?,cancelled_by_id=?,cancelled_by_name=?,updated_at=?,version=version+1 WHERE id=? AND version=? AND status IN ('requested','scheduled')",reason,a.id,a.name,t,aid,version),
   auditChange(a,'Solicitação de abastecimento cancelada',aid,{reason}),...notificationStatements('cancelled',aid,t,version+1,'appointments',true)
  ]);
  if(!results[0].meta.changes)throw new AppError('A solicitação mudou. Atualize a tela antes de cancelar.',409);
  return {ok:true};
 }
 if(path==='supplies'){
  requireProfile(a,['fueler','manager']);const key=required(b.operationKey,'Identificador da operação',100);
  const previous=await first('SELECT id,author_id,quantity_milli FROM supplies WHERE operation_key=?',key);if(previous){if(previous.author_id!==a.id)throw new AppError('Operação já utilizada.',409);return {id:previous.id,repeated:true};}
  const [f,e,o]=await Promise.all([first('SELECT * FROM fuels WHERE id=? AND active=1',b.fuelId),first('SELECT * FROM equipment WHERE id=? AND active=1',b.equipmentId),first('SELECT * FROM operators WHERE id=? AND active=1',b.operatorId)]);
  if(!f||!e||!o)throw new AppError('Selecione combustível, equipamento e operador ativos.');
  if(!JSON.parse(e.fuel_ids).includes(f.id))throw new AppError('Combustível incompatível com este equipamento.');
  const quantity=milli(b.quantity,!!f.integral),date=dateISO(b.occurredAt),notes=text(b.notes,1200);
  const hour=b.hourmeter==null||b.hourmeter===''?null:milli(b.hourmeter,false,true);const end=b.hourmeterEnd==null||b.hourmeterEnd===''?null:milli(b.hourmeterEnd,false,true);
  if(end!==null&&(hour===null||end<hour))throw new AppError('Horímetro final deve ser igual ou maior que o inicial.');
  let appointment:Row|null=null;
  if(b.appointmentId){
   appointment=await first('SELECT * FROM appointments WHERE id=?',required(b.appointmentId,'Agendamento'));
   if(!appointment||appointment.status!=='scheduled')throw new AppError('Agendamento indisponível ou já realizado.',409);
   if(appointment.equipment_id!==e.id||appointment.fuel_id!==f.id)throw new AppError('Equipamento e combustível devem corresponder ao agendamento.');
   if(hour===null||hour<appointment.hourmeter_milli)throw new AppError('O horímetro inicial deve ser igual ou maior que o informado na solicitação.');
   if(date<appointment.created_at)throw new AppError('A data do abastecimento não pode ser anterior à solicitação.');
  }
  if(!appointment&&!isManager(a))throw new AppError('Registre o consumo a partir de um abastecimento agendado.',403);
  if(!appointment&&!notes)throw new AppError('Justifique o registro excepcional sem agendamento.');
  const created=id();await db().batch([
   stmt('INSERT INTO supplies(id,operation_key,fuel_id,equipment_id,operator_id,quantity_milli,occurred_at,created_at,author_id,author_name,equipment_tag,equipment_name,operator_name,fuel_name,unit,hourmeter_milli,hourmeter_end_milli,notes,appointment_id) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',created,key,f.id,e.id,o.id,quantity,date,t,a.id,a.name,e.tag,e.description,o.name,f.name,f.unit,hour,end,notes,appointment?.id||null),
   audit(a,'Abastecimento registrado',created,{quantity:quantity/1000,equipment:e.tag,fuel:f.name,appointmentId:appointment?.id||null}),...notificationStatements('completed',created,t,0,'supplies'),...await alertStatements(f.id)
  ]);return {id:created};
 }
 if(path==='supplies/cancel'){
  requireProfile(a,['manager']);const s=await first('SELECT * FROM supplies WHERE id=?',b.id);if(!s||s.status!=='confirmed')throw new AppError('Registro já cancelado ou não encontrado.');
  const reason=required(b.reason,'Justificativa',1200);await db().batch([
   stmt("INSERT INTO movements(id,operation_key,fuel_id,delta_milli,kind,supply_id,occurred_at,author_id,author_name,reason) SELECT ?,?,fuel_id,quantity_milli,'reversal',id,?,?,?,? FROM supplies WHERE id=? AND status='confirmed'",id(),'cancel:'+s.id,t,a.id,a.name,reason,s.id),
   stmt("UPDATE supplies SET status='cancelled',cancel_reason=? WHERE id=? AND status='confirmed'",reason,s.id),auditChange(a,'Abastecimento cancelado',s.id,{reason}),...notificationStatements('cancelled',s.id,t,0,'supplies',true)]);return {ok:true};
 }
 if(path==='stock'){
  requireProfile(a,['manager']);const f=await first('SELECT * FROM fuels WHERE id=? AND active=1',b.fuelId);if(!f)throw new AppError('Combustível não encontrado.');
  const key=required(b.operationKey,'Identificador da operação',100);const repeat=await first('SELECT id FROM movements WHERE operation_key=?',key);if(repeat)return {repeated:true};
  const reason=required(b.reason,'Justificativa',1200);let delta:number;let kind:string;
  if(b.kind==='adjustment'){const q=milli(b.balance,!!f.integral,true);delta=q-f.stock_milli;kind='adjustment';if(b.version!==f.version)throw new AppError('O estoque mudou. Atualize a tela e confira o saldo novamente.',409);}
  else{delta=milli(b.quantity,!!f.integral);kind='receipt';}
  const query='INSERT INTO movements(id,operation_key,fuel_id,delta_milli,kind,request_id,occurred_at,author_id,author_name,reason) VALUES(?,?,?,?,?,?,?,?,?,?)';
  let movement=stmt(query,id(),key,f.id,delta,kind,b.requestId||null,t,a.id,a.name,reason);
  if(kind==='adjustment')movement=stmt('INSERT INTO movements(id,operation_key,fuel_id,delta_milli,kind,occurred_at,author_id,author_name,reason,expected_version) VALUES(?,?,?,?,\'adjustment\',?,?,?,?,?)',id(),key,f.id,delta,t,a.id,a.name,reason,b.version);
  const results=await db().batch([movement,...(kind==='adjustment'?[stmt('UPDATE fuels SET provisional=0 WHERE id=? AND EXISTS(SELECT 1 FROM movements WHERE operation_key=?)',f.id,key)]:[]),audit(a,kind==='adjustment'?'Estoque conferido':'Reposição recebida',f.id,{delta:delta/1000,reason}),...await alertStatements(f.id)]);
  if(!results[0].meta.changes)throw new AppError('O estoque mudou. Atualize a tela antes de confirmar.',409);
  return {ok:true};
 }
 if(path==='equipment'){
  requireProfile(a,['manager']);const tag=required(b.tag,'TAG',60).toUpperCase(),description=required(b.description,'Descrição',250),type=required(b.type,'Tipo',100);
  if(!Array.isArray(b.fuelIds)||!b.fuelIds.length)throw new AppError('Selecione ao menos um combustível compatível.');
  const allowed=await all('SELECT id FROM fuels WHERE active=1');if(b.fuelIds.some((f:unknown)=>!allowed.some(v=>v.id===f)))throw new AppError('Combustível inválido.');
  const eid=b.id||id();const old=await first('SELECT * FROM equipment WHERE id=?',eid);
  await db().batch([stmt('INSERT INTO equipment(id,tag,description,type,fuel_ids,active) VALUES(?,?,?,?,?,?) ON CONFLICT(id) DO UPDATE SET tag=excluded.tag,description=excluded.description,type=excluded.type,fuel_ids=excluded.fuel_ids,active=excluded.active',eid,tag,description,type,JSON.stringify(b.fuelIds),b.active===false?0:1),audit(a,old?'Equipamento atualizado':'Equipamento cadastrado',eid,{before:old,after:{tag,description,type,fuelIds:b.fuelIds,active:b.active!==false}})]);return {id:eid};
 }
 if(path==='operators'){
  requireProfile(a,['manager']);const oid=b.id||id(),name=required(b.name,'Nome',180),badge=text(b.badge,60),old=await first('SELECT * FROM operators WHERE id=?',oid);
  await db().batch([stmt('INSERT INTO operators(id,name,badge,active) VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,badge=excluded.badge,active=excluded.active',oid,name,badge,b.active===false?0:1),audit(a,old?'Operador atualizado':'Operador cadastrado',oid,{before:old,after:{name,badge,active:b.active!==false}})]);return {id:oid};
 }
 if(path==='members'){
  requireProfile(a,['manager']);const addr=email(b.email),name=required(b.name,'Nome',180);if(!profiles.includes(b.role))throw new AppError('Perfil inválido.');
  const profile=b.role as Profile,existing=b.id?await first('SELECT * FROM members WHERE id=?',required(b.id,'Usuário')):null;
  if(b.id&&!existing)throw new AppError('Usuário não encontrado.',404);
  const duplicate=await first('SELECT id FROM members WHERE email=?',addr);
  if(duplicate&&duplicate.id!==existing?.id)throw new AppError('Já existe um usuário com este e-mail. Edite o cadastro existente.',409);
  const mid=existing?.id||id();
  if(existing&&addr!==existing.email)throw new AppError('O e-mail de login não pode ser alterado neste cadastro.');
  if(mid===a.id&&(b.active===false||profile!=='manager'))throw new AppError('Mantenha seu próprio acesso de gestor.');
  const reset=typeof b.temporaryPassword==='string'&&b.temporaryPassword.length>0;
  if(!existing&&!reset)throw new AppError('Defina a senha temporária do primeiro acesso.');
  if(reset&&mid===a.id)throw new AppError('Use Alterar minha senha para mudar sua própria senha.');
  if(reset&&b.temporaryPassword!==b.confirmTemporaryPassword)throw new AppError('A confirmação da senha temporária não confere.');
  const hash=reset?hashPassword(validatePassword(b.temporaryPassword,true)):null;
  const expires=new Date(Date.now()+TEMPORARY_PASSWORD_DAYS*86400000).toISOString();
  const notifyRequests=profile==='planner'?Number(b.notifyRequests!==false):1,notifySchedule=profile==='fueler'?Number(b.notifySchedule!==false):1;
  const queries=[
   existing?stmt('UPDATE members SET name=?,role=?,profile=?,can_fuel=?,notify_requests=?,notify_schedule=?,active=? WHERE id=?',name,legacyRole(profile),profile,Number(profile==='fueler'||profile==='manager'),notifyRequests,notifySchedule,b.active===false?0:1,mid):stmt('INSERT INTO members(id,email,name,role,profile,can_fuel,notify_requests,notify_schedule,active,created_at) VALUES(?,?,?,?,?,?,?,?,?,?)',mid,addr,name,legacyRole(profile),profile,Number(profile==='fueler'||profile==='manager'),notifyRequests,notifySchedule,b.active===false?0:1,t),
   audit(a,existing?'Acesso atualizado':'Usuário cadastrado',mid,{before:existing?{profile:existing.profile,active:existing.active}:null,after:{profile,active:b.active!==false,notifyRequests,notifySchedule},passwordReset:reset})
  ];
  if(hash)queries.push(stmt('INSERT INTO auth_credentials(member_id,password_hash,must_change,temporary_expires_at,updated_at) VALUES(?,?,1,?,?) ON CONFLICT(member_id) DO UPDATE SET password_hash=excluded.password_hash,must_change=1,temporary_expires_at=excluded.temporary_expires_at,updated_at=excluded.updated_at,version=auth_credentials.version+1',mid,hash,expires,t),stmt('DELETE FROM auth_sessions WHERE member_id=?',mid));
  await db().batch(queries);return {id:mid};
 }
 if(path==='fuels'){
  requireProfile(a,['manager']);const fid=b.id||id(),old=await first('SELECT * FROM fuels WHERE id=?',fid),name=required(b.name,'Nome',100),unit=required(b.unit,'Unidade',30),integral=!!b.integral,capacity=milli(b.capacity,integral),minimum=milli(b.minimum,integral,true),lead=Number(b.leadDays),recipient='';
  if(minimum>=capacity)throw new AppError('O mínimo deve ser menor que a capacidade máxima.');if(!Number.isInteger(lead)||lead<1||lead>60)throw new AppError('Prazo deve ser de 1 a 60 dias úteis.');
  if(old&&(old.unit!==unit||old.integral!==Number(integral))&&(await first('SELECT id FROM movements WHERE fuel_id=? LIMIT 1',fid)))throw new AppError('A unidade de um combustível com movimentações não pode ser alterada. Cadastre outro combustível.');
  if(old&&capacity<old.stock_milli)throw new AppError('Capacidade não pode ser menor que o saldo atual.');
  const queries=[stmt('INSERT INTO fuels(id,name,unit,integral,capacity_milli,minimum_milli,stock_milli,lead_days,recipient,provisional,active) VALUES(?,?,?,?,?,?,0,?,?,1,?) ON CONFLICT(id) DO UPDATE SET name=excluded.name,minimum_milli=excluded.minimum_milli,capacity_milli=excluded.capacity_milli,lead_days=excluded.lead_days,recipient=excluded.recipient,active=excluded.active',fid,name,unit,Number(integral),capacity,minimum,lead,recipient,b.active===false?0:1),audit(a,old?'Parâmetros atualizados':'Combustível cadastrado',fid,{before:old,after:{name,unit,capacity:capacity/1000,minimum:minimum/1000,lead,recipient}})];
  if(!old){const balance=milli(b.balance??0,integral,true);queries.push(stmt('INSERT INTO movements(id,operation_key,fuel_id,delta_milli,kind,occurred_at,author_id,author_name,reason) VALUES(?,?,?,?,\'initial\',?,?,?,\'Saldo inicial provisório\')',id(),'initial:'+fid,fid,balance,t,a.id,a.name));}
  queries.push(...await alertStatements(fid,lead));await db().batch(queries);return {id:fid};
 }
 if(path==='requests/status'){
  requireProfile(a,['manager']);if(!['purchasing','cancelled'].includes(b.status))throw new AppError('Estado inválido.');
  const r=await first('SELECT * FROM requests WHERE id=?',b.id);if(!r||!['open','purchasing','partial'].includes(r.status))throw new AppError('Solicitação já encerrada.');
  if(b.status==='cancelled'&&!text(b.reason))throw new AppError('Informe a justificativa do cancelamento.');
  await db().batch([stmt('UPDATE requests SET status=? WHERE id=? AND status IN (\'open\',\'purchasing\',\'partial\')',b.status,b.id),auditChange(a,'Solicitação atualizada',b.id,{status:b.status,reason:text(b.reason,1200)}),...(b.status==='cancelled'?notificationStatements('cancelled',r.id,t,0,'requests',true):[])]);return {ok:true};
 }
 if(path==='holidays'){
  requireProfile(a,['manager']);const date=calendarDate(b.date);
  const q=b.remove?stmt('DELETE FROM holidays WHERE date=?',date):stmt('INSERT INTO holidays(date,name) VALUES(?,?) ON CONFLICT(date) DO UPDATE SET name=excluded.name',date,required(b.name,'Nome',180));
  await db().batch([q,audit(a,b.remove?'Feriado removido':'Feriado cadastrado',date,{name:b.name})]);return {ok:true};
 }
 if(path==='emails/test'){
  requireProfile(a,['manager']);
  if(!emailSetup().ready)throw new AppError('Configure o remetente e a chave privada do Resend antes de testar.',409);
  const key=required(b.operationKey,'Identificador do teste',80);if(!/^[A-Za-z0-9_-]{16,80}$/.test(key))throw new AppError('Identificador do teste inválido.');
  const recipient=await first("SELECT email FROM members WHERE id=? AND active=1 AND profile='manager' ",a.id);
  if(!recipient)throw new AppError('Seu acesso mudou. Atualize a tela.',403);
  await sendResendEmail(recipient.email,'NAUTILUS · Teste de envio','Este é um teste solicitado pela sua conta de gestor. Nenhum dado de abastecimento foi incluído. Confira a chegada deste aviso na caixa de entrada e no spam.',`nautilus-test/${a.id}/${key}`);
  await stmt("INSERT INTO audits(id,action,entity_id,author_id,author_name,created_at,detail) SELECT ?,'Teste de e-mail solicitado',id,id,name,?,'{\"accepted\":true}' FROM members WHERE id=? AND active=1 AND profile='manager'",id(),t,a.id).run();
  return {accepted:true,message:'O Resend aceitou o teste. Confira a chegada no e-mail da sua conta de gestor.'};
 }
 if(path==='emails/retry'){requireProfile(a,['manager']);const setup=emailSetup();if(!setup.ready||!setup.enabled)throw new AppError('Configure o remetente e ative os alertas antes de tentar novamente.',409);await stmt("UPDATE notifications SET attempts=0,last_error='',locked_at=NULL WHERE status='failed'").run();return {ok:true};}
 throw new AppError('Ação não encontrada.',404);
}
export const flushEmails=flushNotifications;
export async function exportCSV(url:URL,a:Member){
 requireProfile(a,['manager']);const kind=url.searchParams.get('kind')||'supplies',start=url.searchParams.get('start'),end=url.searchParams.get('end'),fuel=url.searchParams.get('fuel');
 const where:string[]=[];const values:unknown[]=[];const datecol=kind==='supplies'?'s.occurred_at':kind==='movements'?'m.occurred_at':'r.opened_at';
 if(start&&end&&calendarDate(start)>calendarDate(end))throw new AppError('A data inicial deve ser anterior ou igual à data final.');
 if(start){calendarDate(start);where.push(datecol+'>=?');values.push(start+'T00:00:00-03:00');values[values.length-1]=new Date(String(values.at(-1))).toISOString();}
 if(end){calendarDate(end);where.push(datecol+'<=?');values.push(new Date(end+'T23:59:59.999-03:00').toISOString());}
 if(fuel&&fuel!=='all'){where.push((kind==='supplies'?'s':kind==='movements'?'m':'r')+'.fuel_id=?');values.push(fuel);}
 const defs:Record<string,{query:string,headers:string[],map:(r:Row)=>unknown[]}>= {
 supplies:{query:'SELECT s.* FROM supplies s',headers:['ID','Data_UTC','Data_Local','Equipamento_ID','TAG','Equipamento','Operador_ID','Operador','Combustivel_ID','Combustivel','Quantidade','Unidade','Horimetro_Inicial','Horimetro_Final','Responsavel_ID','Responsavel_Lancamento','Lancado_Em_UTC','Situacao','Observacao','Justificativa_Cancelamento','Solicitacao_Abastecimento_ID'],map:r=>[r.id,r.occurred_at,new Date(r.occurred_at).toLocaleString('sv-SE',{timeZone:'America/Sao_Paulo'}),r.equipment_id,r.equipment_tag,r.equipment_name,r.operator_id,r.operator_name,r.fuel_id,r.fuel_name,r.quantity_milli/1000,r.unit,r.hourmeter_milli===null?'':r.hourmeter_milli/1000,r.hourmeter_end_milli===null?'':r.hourmeter_end_milli/1000,r.author_id,r.author_name,r.created_at,r.status,r.notes,r.cancel_reason,r.appointment_id]},
 movements:{query:'SELECT m.*,f.name fuel_name,f.unit FROM movements m JOIN fuels f ON f.id=m.fuel_id',headers:['ID','Data_UTC','Combustivel_ID','Combustivel','Tipo','Quantidade_Com_Sinal','Saldo_Apos','Unidade','Abastecimento_ID','Solicitacao_ID','Responsavel_ID','Responsavel','Justificativa'],map:r=>[r.id,r.occurred_at,r.fuel_id,r.fuel_name,r.kind,r.delta_milli/1000,r.balance_after_milli/1000,r.unit,r.supply_id,r.request_id,r.author_id,r.author_name,r.reason]},
 requests:{query:'SELECT r.*,f.name fuel_name,f.unit FROM requests r JOIN fuels f ON f.id=r.fuel_id',headers:['ID','Combustivel_ID','Combustivel','Abertura_UTC','Prazo_UTC','Quantidade_Solicitada','Quantidade_Recebida','Unidade','Situacao'],map:r=>[r.id,r.fuel_id,r.fuel_name,r.opened_at,r.deadline,r.requested_milli/1000,r.received_milli/1000,r.unit,r.status]}
 };const def=defs[kind];if(!def)throw new AppError('Tipo de exportação inválido.');
 const lines=[def.headers.map(safeCSV).join(';')];let offset=0;
 while(offset<10000){const rows=await all(def.query+(where.length?' WHERE '+where.join(' AND '):'')+' ORDER BY '+datecol+' ASC LIMIT 1000 OFFSET ?',...values,offset);lines.push(...rows.map(r=>def.map(r).map(safeCSV).join(';')));if(rows.length<1000)break;offset+=1000;}
 if(offset>=10000&&(await all(def.query+(where.length?' WHERE '+where.join(' AND '):'')+' LIMIT 1 OFFSET 10000',...values)).length)throw new AppError('Selecione um período menor: limite de 10.000 registros por exportação.',413);
 await requireFresh(a);
 return new Response('\uFEFF'+lines.join('\r\n'),{headers:{'Content-Type':'text/csv; charset=utf-8','Content-Disposition':`attachment; filename="nautilus_${kind}_${now().slice(0,10)}.csv"`,'Cache-Control':'no-store'}});
}
