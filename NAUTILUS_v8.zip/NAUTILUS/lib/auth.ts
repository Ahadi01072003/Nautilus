import {headers} from 'next/headers';
import {getChatGPTUser} from '@/app/chatgpt-auth';
import {db} from './db';
import {ensureIntegrity} from './integrity';
import {AppError,email} from './domain';
import {profiles,Member} from './permissions';
import {digest,hashPassword,verifyPassword,validatePassword,SESSION_HOURS} from './password';

export const SESSION_COOKIE='nautilus_session';
type Credential={password_hash:string;must_change:number;version:number;temporary_expires_at:string|null};
export type AuthMember=Member & {email:string;must_change:number;credential_version:number;session_hash:string;temporary_expires_at:string|null};
const statement=(sql:string,...params:unknown[])=>db().prepare(sql).bind(...params);
const now=()=>new Date().toISOString();
function cookieToken(cookie:string|null) {
 const tokens=(cookie||'').split(';').map(s=>s.trim()).filter(s=>s.startsWith(SESSION_COOKIE+'='));
 if(tokens.length!==1)return null;
 const token=tokens[0].slice(SESSION_COOKIE.length+1);
 return /^[a-f0-9]{64}$/.test(token)?token:null;
}
export async function sessionMember(request?:Request):Promise<AuthMember|null> {
 const h=request?.headers||await headers(),token=cookieToken(h.get('Cookie'));
 if(!token)return null;
 const hash=await digest(token),time=now();
 const member=await statement('SELECT m.*,c.must_change,c.version credential_version,c.temporary_expires_at,s.token_hash session_hash FROM auth_sessions s JOIN members m ON m.id=s.member_id JOIN auth_credentials c ON c.member_id=m.id WHERE s.token_hash=? AND s.expires_at>? AND s.credential_version=c.version AND m.active=1 AND (c.must_change=0 OR c.temporary_expires_at>?)',hash,time,time).first<AuthMember>();
 return member&&profiles.includes(member.profile)?member:null;
}
async function bootstrapMember() {
 const identity=await getChatGPTUser();if(!identity)return null;
 const member=await statement("SELECT m.* FROM members m LEFT JOIN auth_credentials c ON c.member_id=m.id WHERE m.email=? AND m.profile='manager' AND m.active=1 AND c.member_id IS NULL",email(identity.email)).first<Member & {auth_id:string|null;email:string}>();
 if(!member||member.auth_id!==identity.userId)return null;
 return member;
}
export async function authStatus(request:Request) {
 const member=await sessionMember(request);
 if(member)return {authenticated:true,user:{id:member.id,name:member.name,email:member.email,role:member.profile},mustChangePassword:!!member.must_change};
 const bootstrap=await bootstrapMember();
 return {authenticated:false,bootstrapEligible:!!bootstrap,bootstrapName:bootstrap?.name||null};
}
function sessionData(memberId:string,version:number) {
 const token=Buffer.from(crypto.getRandomValues(new Uint8Array(32))).toString('hex');
 return {token,memberId,version,created:now(),expires:new Date(Date.now()+SESSION_HOURS*3600000).toISOString()};
}
async function insertSession(session:ReturnType<typeof sessionData>,expectedHash?:string) {
 return statement('INSERT INTO auth_sessions(token_hash,member_id,credential_version,expires_at,created_at) SELECT ?,m.id,c.version,?,? FROM members m JOIN auth_credentials c ON c.member_id=m.id WHERE m.id=? AND m.active=1 AND c.version=? AND (c.must_change=0 OR c.temporary_expires_at>?)'+(expectedHash?' AND c.password_hash=?':''),await digest(session.token),session.expires,session.created,session.memberId,session.version,session.created,...(expectedHash?[expectedHash]:[]));
}
export function sessionCookie(token:string,request:Request,clear=false) {
 return SESSION_COOKIE+'='+token+'; Path=/; HttpOnly; SameSite=Lax; Max-Age='+(clear?0:SESSION_HOURS*3600)+(new URL(request.url).protocol==='https:'?'; Secure':'');
}
function authEvent(memberId:string,event:string,expectedHash?:string) {
 return statement('INSERT INTO auth_events(id,member_id,event,created_at) SELECT ?,?,?,?'+(expectedHash?' WHERE EXISTS(SELECT 1 FROM auth_credentials WHERE member_id=? AND password_hash=?)':''),crypto.randomUUID(),memberId,event,now(),...(expectedHash?[memberId,expectedHash]:[]));
}
async function loginLimit(request:Request,address:string) {
 const window=Math.floor(Date.now()/900000)*15;
 // Somente o cabeçalho do proxy Cloudflare; nunca X-Forwarded-For fornecido pelo cliente.
 for(const [subject,limit] of [[await digest('account:'+address),10],[await digest('network:'+(request.headers.get('CF-Connecting-IP')||'local')),50]] as const){
  const row=await statement('INSERT INTO rate_limits(key,window_start,hits) VALUES(?,?,1) ON CONFLICT(key) DO UPDATE SET window_start=excluded.window_start,hits=CASE WHEN rate_limits.window_start=excluded.window_start THEN rate_limits.hits+1 ELSE 1 END RETURNING hits','login:'+subject,window).first<{hits:number}>();
  if(!row||row.hits>limit)throw new AppError('Muitas tentativas de acesso. Aguarde 15 minutos e tente novamente.',429);
 }
 await statement("DELETE FROM rate_limits WHERE key LIKE 'login:%' AND window_start<?",window-30).run();
}
export async function login(request:Request,body:Record<string,unknown>) {
 const address=email(body.email);await loginLimit(request,address);
 const member=await statement('SELECT m.id,m.active,m.profile,c.password_hash,c.must_change,c.version,c.temporary_expires_at FROM members m LEFT JOIN auth_credentials c ON c.member_id=m.id WHERE m.email=?',address).first<Credential & {id:string;active:number;profile:Member['profile']}>();
 const valid=verifyPassword(body.password,member?.password_hash);
 if(!member||!valid||!member.active||!profiles.includes(member.profile)||(member.must_change&&(!member.temporary_expires_at||member.temporary_expires_at<=now())))
  throw new AppError('E-mail ou senha inválidos, ou acesso indisponível. Se for seu primeiro acesso, confirme a senha temporária com o gestor.',401);
 const session=sessionData(member.id,member.version);
 const results=await db().batch([await insertSession(session),statement('UPDATE auth_credentials SET last_login_at=? WHERE member_id=? AND version=?',now(),member.id,member.version),authEvent(member.id,'login'),statement('DELETE FROM auth_sessions WHERE expires_at<=?',now())]);
 if(!results[0].meta.changes)throw new AppError('Seu acesso mudou. Tente entrar novamente.',401);
 return {body:{ok:true,mustChangePassword:!!member.must_change},cookie:sessionCookie(session.token,request)};
}
export async function logout(request:Request) {
 const token=cookieToken(request.headers.get('Cookie'));
 if(token)await statement('DELETE FROM auth_sessions WHERE token_hash=?',await digest(token)).run();
 return {body:{ok:true},cookie:sessionCookie('',request,true)};
}
export async function changePassword(request:Request,body:Record<string,unknown>) {
 const member=await sessionMember(request);if(!member)throw new AppError('Sua sessão expirou. Entre novamente.',401);
 const password=validatePassword(body.newPassword);
 if(password!==body.confirmPassword)throw new AppError('A confirmação da senha não confere.');
 const old=await statement('SELECT * FROM auth_credentials WHERE member_id=?',member.id).first<Credential>();
 if(!old||old.version!==member.credential_version)throw new AppError('Sua sessão expirou. Entre novamente.',401);
 if(!member.must_change&&!verifyPassword(body.currentPassword,old.password_hash))throw new AppError('A senha atual está incorreta.');
 if(verifyPassword(password,old.password_hash))throw new AppError('Escolha uma senha diferente da senha atual ou temporária.');
 const hash=hashPassword(password),session=sessionData(member.id,old.version+1);
 const results=await db().batch([
  statement('UPDATE auth_credentials SET password_hash=?,must_change=0,temporary_expires_at=NULL,version=version+1,updated_at=? WHERE member_id=? AND version=? AND EXISTS(SELECT 1 FROM members WHERE id=? AND active=1)',hash,now(),member.id,old.version,member.id),
  await insertSession(session,hash),authEvent(member.id,'password_changed',hash)
 ]);
 if(!results[0].meta.changes||!results[1].meta.changes)throw new AppError('Seu acesso mudou. Entre novamente.',401);
 return {body:{ok:true},cookie:sessionCookie(session.token,request)};
}
export async function bootstrapPassword(request:Request,body:Record<string,unknown>) {
 await ensureIntegrity();
 const member=await bootstrapMember();if(!member)throw new AppError('A ativação é exclusiva de um gestor existente com identidade já vinculada e sem senha cadastrada.',403);
 const password=validatePassword(body.newPassword);
 if(password!==body.confirmPassword)throw new AppError('A confirmação da senha não confere.');
 const hash=hashPassword(password),session=sessionData(member.id,1);
 const results=await db().batch([
  statement("INSERT INTO auth_credentials(member_id,password_hash,must_change,version,updated_at) SELECT id,?,0,1,? FROM members WHERE id=? AND active=1 AND profile='manager' AND auth_id=? AND NOT EXISTS(SELECT 1 FROM auth_credentials WHERE member_id=?)",hash,now(),member.id,member.auth_id,member.id),
  await insertSession(session,hash),authEvent(member.id,'manager_bootstrap',hash)
 ]);
 if(!results[0].meta.changes)throw new AppError('Este gestor já ativou a senha. Use o login por e-mail e senha.',409);
 return {body:{ok:true},cookie:sessionCookie(session.token,request)};
}
