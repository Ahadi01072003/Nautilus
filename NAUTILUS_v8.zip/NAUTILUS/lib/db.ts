import {env} from 'cloudflare:workers';
export function db():D1Database {const database=(env as unknown as {DB?:D1Database}).DB;if(!database)throw new Error('Banco indisponível. Tente novamente.');return database;}
export function runtime(){return env as unknown as {RESEND_API_KEY?:string;EMAIL_FROM?:string;EMAIL_ENABLED?:string;AUTOMATION_TOKEN?:string;MEMBER_PROVISIONING?:string};}
