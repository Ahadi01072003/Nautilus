import {AppError} from './domain';
import {db} from './db';

export const MAX_BODY_BYTES=32768;
export async function boundedJSON(req:Request){
 if(!/^application\/json(?:\s*;.*)?$/i.test(req.headers.get('Content-Type')||''))throw new AppError('Formato inválido.',415);
 const reader=req.body?.getReader();if(!reader)throw new AppError('Dados inválidos.');
 let bytes=0;const decoder=new TextDecoder('utf-8',{fatal:true});let source='';
 try{while(true){const {done,value}=await reader.read();if(done)break;bytes+=value.byteLength;if(bytes>MAX_BODY_BYTES){await reader.cancel();throw new AppError('Dados excedem o limite.',413);}source+=decoder.decode(value,{stream:true});}source+=decoder.decode();}
 catch(e){if(e instanceof AppError)throw e;throw new AppError('Dados inválidos.');}
 let body;try{body=JSON.parse(source);}catch{throw new AppError('Dados inválidos.');}
 if(!body||Array.isArray(body)||typeof body!=='object')throw new AppError('Dados inválidos.');return body;
}
export function sameOrigin(req:Request){
 const origin=req.headers.get('Origin');
 if(origin!==new URL(req.url).origin||req.headers.get('Sec-Fetch-Site')==='cross-site')throw new AppError('Origem não autorizada.',403);
}
/** Contador atômico por conta, sem armazenar IP ou e-mail. */
export async function rateLimit(memberId:string,action:'read'|'write'|'export'|'automation'|'email_test'){
 const minute=Math.floor(Date.now()/60000),limit={read:90,write:30,export:5,automation:10,email_test:2}[action];
 const key=memberId+':'+action;
 const row=await db().prepare('INSERT INTO rate_limits(key,window_start,hits) VALUES(?,?,1) ON CONFLICT(key) DO UPDATE SET window_start=excluded.window_start,hits=CASE WHEN rate_limits.window_start=excluded.window_start THEN rate_limits.hits+1 ELSE 1 END RETURNING hits').bind(key,minute).first<{hits:number}>();
 if(!row||row.hits>limit)throw new AppError('Muitas solicitações. Aguarde um minuto e tente novamente.',429);
 await db().prepare("DELETE FROM rate_limits WHERE key NOT LIKE 'login:%' AND window_start<?").bind(minute-10).run();
}
export async function bearerMatches(received:string|null,secret:string|undefined){
 if(!secret||!received?.startsWith('Bearer '))return false;
 const digest=async(s:string)=>new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(s)));
 const [a,b]=await Promise.all([digest(received.slice(7)),digest(secret)]);let delta=0;for(let i=0;i<a.length;i++)delta|=a[i]^b[i];return delta===0;
}
export function securityHeaders(response:Response,request:Request){
 const result=new Response(response.body,response);result.headers.set('X-Content-Type-Options','nosniff');result.headers.set('Referrer-Policy','no-referrer');
 result.headers.set('Permissions-Policy','camera=(), microphone=(), geolocation=()');
 if(new URL(request.url).protocol==='https:')result.headers.set('Strict-Transport-Security','max-age=31536000');
 if(result.headers.get('Content-Type')?.includes('text/html')){
  result.headers.set('Cache-Control','private, no-store');
  result.headers.set('Content-Security-Policy',"default-src 'self'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self' data:; connect-src 'self'; object-src 'none'; base-uri 'self'; form-action 'self'; frame-ancestors 'self' https://chatgpt.com https://*.chatgpt.com");
 }
 return result;
}
