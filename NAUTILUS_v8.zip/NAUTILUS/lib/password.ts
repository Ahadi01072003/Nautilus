import {pbkdf2Sync, timingSafeEqual} from 'node:crypto';
import {AppError} from './domain';

const ITERATIONS=600000;
export const TEMPORARY_PASSWORD_DAYS=7;
export const SESSION_HOURS=8;
export function validatePassword(value:unknown,temporary=false):string {
 const minimum=temporary?10:12;
 if(typeof value!=='string'||value.length<minimum||value.length>128||!value.trim())
  throw new AppError('A senha deve ter entre '+minimum+' e 128 caracteres.');
 return value;
}
export function hashPassword(password:string) {
 const salt=crypto.getRandomValues(new Uint8Array(32));
 return ['pbkdf2-sha256',ITERATIONS,Buffer.from(salt).toString('hex'),Buffer.from(pbkdf2Sync(password,salt,ITERATIONS,32,'sha256')).toString('hex')].join('$');
}
const DUMMY_HASH=['pbkdf2-sha256',ITERATIONS,'0'.repeat(64),'0'.repeat(64)].join('$');
export function verifyPassword(password:unknown,stored:string|null|undefined) {
 if(typeof password!=='string'||password.length>128)return false;
 const parts=(stored||DUMMY_HASH).split('$');
 if(parts.length!==4||parts[0]!=='pbkdf2-sha256'||Number(parts[1])!==ITERATIONS||!parts.slice(2).every(s=>/^[a-f0-9]{64}$/.test(s)))return false;
 const candidate=pbkdf2Sync(password,Buffer.from(parts[2],'hex'),ITERATIONS,32,'sha256');
 return timingSafeEqual(candidate,Buffer.from(parts[3],'hex'))&&!!stored;
}
export async function digest(value:string) {
 return Buffer.from(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))).toString('hex');
}
