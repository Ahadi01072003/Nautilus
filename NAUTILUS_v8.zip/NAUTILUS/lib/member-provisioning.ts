import {db,runtime} from './db';
import {AppError,email} from './domain';
import {legacyRole,profiles,type Profile} from './permissions';

type Provisioning={revision:string;ownerEmail:string;members:{email:string;name:string;profile:Profile}[]};
let pending:{source:string;promise:Promise<void>}|null=null;
const invalid=()=>new AppError('A configuração inicial de acessos precisa ser revisada pelo proprietário.',503);
function parse(source:string):Provisioning{
 try{
  if(source.length>16000)throw invalid();
  const value:unknown=JSON.parse(source);
  if(!value||typeof value!=='object'||!('revision' in value)||!('ownerEmail' in value)||!('members' in value))throw invalid();
  if(typeof value.revision!=='string'||! /^[A-Za-z0-9_-]{8,80}$/.test(value.revision)||!Array.isArray(value.members)||value.members.length<1||value.members.length>20)throw invalid();
  const address=(input:unknown)=>{if(typeof input!=='string'||input.length>254||/[\x00-\x20\x7f]/.test(input))throw invalid();return email(input);};
  const ownerEmail=address(value.ownerEmail),seen=new Set<string>();
  const members=value.members.map((member:unknown)=>{
   if(!member||typeof member!=='object'||!('email' in member)||!('name' in member)||!('profile' in member)||typeof member.name!=='string'||!member.name.trim()||member.name.length>180||/[\x00-\x1f\x7f]/.test(member.name)||!profiles.includes(member.profile as Profile))throw invalid();
   const addr=address(member.email);if(seen.has(addr))throw invalid();seen.add(addr);
   return {email:addr,name:member.name.trim(),profile:member.profile as Profile};
  });
  if(!members.some(member=>member.email===ownerEmail&&member.profile==='manager'))throw invalid();
  return {revision:value.revision,ownerEmail,members};
 }catch{throw invalid();}
}
/** Importação única autorizada por configuração privada; nunca por dados de uma requisição. */
export function ensureMemberProvisioning(){
 const source=runtime().MEMBER_PROVISIONING;
 if(!source)return Promise.resolve();
 if(pending?.source===source)return pending.promise;
 const config=parse(source);
 const promise=apply(config).catch(error=>{pending=null;throw error;});
 pending={source,promise};return promise;
}
async function apply(config:Provisioning){
 const database=db();
 if(await database.prepare('SELECT revision FROM member_provisioning_batches WHERE revision=?').bind(config.revision).first())return;
 const owner=await database.prepare("SELECT id,name FROM members WHERE email=? AND active=1 AND profile='manager' AND auth_id IS NOT NULL").bind(config.ownerEmail).first<{id:string;name:string}>();
 if(!owner)throw invalid();
 const timestamp=new Date().toISOString();
 // Cada instrução usa a mesma guarda; batches concorrentes não repetem nem reativam acessos revogados.
 const guard="NOT EXISTS(SELECT 1 FROM member_provisioning_batches WHERE revision=?) AND EXISTS(SELECT 1 FROM members WHERE id=? AND email=? AND active=1 AND profile='manager' AND auth_id IS NOT NULL)";
 const values=[config.revision,owner.id,config.ownerEmail];
 await database.batch([
  ...config.members.map(member=>database.prepare(`INSERT INTO members(id,email,name,role,profile,can_fuel,notify_requests,notify_schedule,active,created_at) SELECT ?,?,?,?,?,?,1,1,1,? WHERE ${guard} ON CONFLICT(email) DO UPDATE SET name=excluded.name,role=excluded.role,profile=excluded.profile,can_fuel=excluded.can_fuel,notify_requests=1,notify_schedule=1,active=1`).bind(crypto.randomUUID(),member.email,member.name,legacyRole(member.profile),member.profile,Number(member.profile==='manager'||member.profile==='fueler'),timestamp,...values)),
  database.prepare(`INSERT INTO audits(id,action,entity_id,author_id,author_name,created_at,detail) SELECT ?,'Equipe inicial configurada',?,?,?,?,? WHERE ${guard}`).bind(crypto.randomUUID(),config.revision,owner.id,owner.name,timestamp,JSON.stringify({members:config.members.length}),...values),
  database.prepare(`INSERT INTO member_provisioning_batches(revision,owner_id,member_count,applied_at) SELECT ?,?,?,? WHERE ${guard}`).bind(config.revision,owner.id,config.members.length,timestamp,...values)
 ]);
 if(!await database.prepare('SELECT revision FROM member_provisioning_batches WHERE revision=?').bind(config.revision).first())throw invalid();
}
