'use client';
import {FormEvent,useCallback,useEffect,useRef,useState} from 'react';
import {Anchor,Compass,LoaderCircle,ShieldCheck} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Input} from '@/components/ui/input';
import {Alert,AlertDescription} from '@/components/ui/alert';
import {Field,FieldGroup,FieldLabel,FieldSet} from '@/components/ui/field';
import {apiRequest} from '@/lib/client-api';
import PasswordField from './password-field';
import PasswordChange from './password-change';
import Workspace from './workspace';
import './nautilus.css';

type Status={authenticated:boolean;user?:{id:string;name:string;email:string;role:string};mustChangePassword?:boolean;bootstrapEligible?:boolean;bootstrapName?:string|null};
export default function AuthShell(){
 const [status,setStatus]=useState<Status|null>(null),[checking,setChecking]=useState(true),[email,setEmail]=useState(''),[password,setPassword]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 const lock=useRef(false),errorRef=useRef<HTMLDivElement>(null);
 const check=useCallback(async()=>{try{setStatus(await apiRequest<Status>('/api/auth/me'));}catch(reason){setStatus(null);setError((reason as Error).message);}finally{setChecking(false);}},[]);
 // eslint-disable-next-line react-hooks/set-state-in-effect -- Consulta assíncrona da sessão no servidor; estado não derivado de props.
 useEffect(()=>{void check();const expire=()=>{setStatus({authenticated:false});setError('Sua sessão expirou ou foi encerrada pelo gestor. Entre novamente.');};window.addEventListener('nautilus:session-expired',expire);return()=>window.removeEventListener('nautilus:session-expired',expire);},[check]);
 async function logout(){try{await apiRequest('/api/auth/logout',{});setStatus({authenticated:false});setPassword('');setError('');}catch(reason){setError((reason as Error).message);}}
 async function login(event:FormEvent){event.preventDefault();if(lock.current)return;lock.current=true;setBusy(true);setError('');try{await apiRequest('/api/auth/login',{email,password});setPassword('');setChecking(true);await check();}catch(reason){setError((reason as Error).message);requestAnimationFrame(()=>errorRef.current?.focus());}finally{lock.current=false;setBusy(false);}}
 if(checking)return <main className="auth-loading" aria-busy="true"><Compass size={40}/><p>Verificando seu acesso…</p></main>;
 if(status?.authenticated&&!status.mustChangePassword&&status.user)return <Workspace identity={status.user} onLogout={()=>void logout()}/>;
 const firstAccess=!!status?.authenticated&&!!status.mustChangePassword,bootstrap=!!status?.bootstrapEligible;
 return <main className="auth-layout">
  <aside className="auth-brand"><div className="brand"><Compass size={42}/><div><b>NAUTILUS</b><small>ABASTECIMENTOS</small></div></div><div><p className="eyebrow">BASE AÇU · OPERAÇÃO</p><h1>Precisão em cada abastecimento.</h1><p>Solicitações, agenda e estoque em um só lugar. Cada pessoa com seu acesso e suas responsabilidades.</p></div><div className="auth-signature"><Anchor size={22}/><span>Precisão. Profundidade. Clareza.</span></div></aside>
  <section className="auth-content"><div className="auth-card"><span className="auth-kicker"><ShieldCheck size={18}/> Acesso individual</span><h2>{firstAccess?'Crie sua senha pessoal':bootstrap?'Ativar acesso do gestor':'Entrar no Nautilus'}</h2><p>{firstAccess?'Este é seu primeiro acesso ou sua senha foi redefinida.':bootstrap?'Olá, '+status?.bootstrapName+'. Defina sua senha para administrar os usuários dentro do sistema.':'Use o e-mail cadastrado pelo gestor e sua senha.'}</p>
   {firstAccess||bootstrap?<PasswordChange firstAccess={firstAccess} bootstrap={bootstrap} onDone={()=>{setChecking(true);void check();}} onCancel={firstAccess?()=>void logout():undefined}/>:<form onSubmit={login} className="auth-form"><FieldSet disabled={busy}><FieldGroup><Field><FieldLabel htmlFor="login-email">E-mail</FieldLabel><Input id="login-email" name="email" type="email" required maxLength={254} autoComplete="username" autoCapitalize="none" spellCheck={false} value={email} onChange={event=>setEmail(event.target.value)} placeholder="seu.email@empresa.com"/></Field><PasswordField label="Senha" value={password} onChange={setPassword} autoComplete="current-password"/></FieldGroup></FieldSet>{error&&<Alert ref={errorRef} variant="destructive" role="alert" tabIndex={-1}><AlertDescription>{error}</AlertDescription></Alert>}<Button type="submit" disabled={busy}>{busy?<><LoaderCircle className="animate-spin" data-icon="inline-start"/> Entrando…</>:'Entrar'}</Button><details className="auth-help"><summary>Primeiro acesso ou esqueceu sua senha?</summary><p>Peça ao gestor uma senha temporária. No primeiro login, você criará e confirmará sua nova senha. Se a senha temporária expirou, o gestor pode redefini-la em Usuários e acessos.</p></details><details className="auth-help"><summary>Sou gestor do sistema anterior</summary><p>Para ativar sua senha pela primeira vez, confirme sua identidade de gestor. Depois, cadastros e redefinições serão feitos dentro do Nautilus.</p><a href="/signin-with-chatgpt?return_to=/" target="_top">Confirmar meu acesso de gestor</a></details></form>}
   {error&&(firstAccess||bootstrap)&&<Alert variant="destructive" role="alert"><AlertDescription>{error}</AlertDescription></Alert>}
   {!status&&<Button variant="outline" onClick={()=>void check()}>Tentar conexão novamente</Button>}
   <p className="auth-footnote">Os acessos são criados e administrados pelo gestor da sua operação.</p></div><footer>NAUTILUS · Base Açu · Horário de Brasília</footer></section>
 </main>;
}
