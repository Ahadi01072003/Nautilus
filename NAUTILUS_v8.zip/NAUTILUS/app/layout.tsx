import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "NAUTILUS · Abastecimentos",
  description: "Registro de abastecimentos, controle de estoque e reposições da base.",
  other: {
    "codex-preview": "development",
  },
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="pt-BR">
      <body className="antialiased">{children}</body>
    </html>
  );
}
