'use client';
import {useId,useState} from 'react';
import {Eye,EyeOff} from 'lucide-react';
import {Field,FieldDescription,FieldLabel} from '@/components/ui/field';
import {InputGroup,InputGroupAddon,InputGroupButton,InputGroupInput} from '@/components/ui/input-group';

export default function PasswordField({label,value,onChange,temporary=false,autoComplete='new-password',required=true,disabled=false,error}:{label:string;value:string;onChange:(value:string)=>void;temporary?:boolean;autoComplete?:string;required?:boolean;disabled?:boolean;error?:string}){
 const id=useId(),[visible,setVisible]=useState(false),[caps,setCaps]=useState(false);
 return <Field data-invalid={!!error} data-disabled={disabled}>
  <FieldLabel htmlFor={id}>{label}</FieldLabel>
  <InputGroup><InputGroupInput id={id} type={visible?'text':'password'} required={required} disabled={disabled} minLength={autoComplete==='current-password'?undefined:temporary?10:12} maxLength={128} autoComplete={autoComplete} value={value} onChange={event=>onChange(event.target.value)} aria-invalid={!!error} aria-describedby={id+'-hint'} onKeyUp={event=>setCaps(event.getModifierState('CapsLock'))} onBlur={()=>setCaps(false)}/>
   <InputGroupAddon align="inline-end"><InputGroupButton disabled={disabled} size="icon-sm" aria-label={(visible?'Ocultar ':'Mostrar ')+label.toLowerCase()} aria-pressed={visible} onClick={()=>setVisible(show=>!show)}>{visible?<EyeOff/>:<Eye/>}</InputGroupButton></InputGroupAddon>
  </InputGroup>
  <FieldDescription id={id+'-hint'}>{error|| (caps?'Caps Lock ativado.':autoComplete==='current-password'?'Digite a senha recebida ou a sua senha atual.':temporary?'De 10 a 128 caracteres. Válida por 7 dias.':'De 12 a 128 caracteres. Use uma senha exclusiva para sua conta.')}</FieldDescription>
 </Field>;
}
