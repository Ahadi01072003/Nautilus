'use client';
import {useId,useMemo,useState} from 'react';
import {Plus,Search,Pencil,KeyRound,Users} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Badge} from '@/components/ui/badge';
import {InputGroup,InputGroupInput,InputGroupAddon} from '@/components/ui/input-group';
import {Table,TableHeader,TableHead,TableRow,TableBody,TableCell} from '@/components/ui/table';
import {Field,FieldLabel,FieldDescription,FieldGroup} from '@/components/ui/field';
import {Switch} from '@/components/ui/switch';
import {Alert,AlertDescription} from '@/components/ui/alert';
import PasswordField from './password-field';

export type User={id:string;name:string;email:string;role:string;active:number;passwordConfigured:number;mustChangePassword:number|null;temporaryExpiresAt:string|null;lastLoginAt:string|null};
const roles:Record<string,string>={requester:'Solicitante',planner:'Planejador',fueler:'Abastecedor',manager:'Gestor'};
export default function UserAccess({members,actorId,onNew,onEdit,now}:{members:User[];actorId:string;onNew:()=>void;onEdit:(user:User)=>void;now:number}){
 const [search,setSearch]=useState(''),[filter,setFilter]=useState('all');
 const rows=useMemo(()=>members.filter(user=>(filter==='all'||(filter==='active'?!!user.active:!user.active))&&(user.name+' '+user.email+' '+roles[user.role]).toLocaleLowerCase('pt-BR').includes(search.toLocaleLowerCase('pt-BR'))),[members,search,filter]);
 const status=(user:User)=>!user.passwordConfigured?'Sem senha definida':user.mustChangePassword?(user.temporaryExpiresAt&&new Date(user.temporaryExpiresAt).getTime()<=now?'Temporária expirada':'Troca obrigatória'):'Senha pessoal ativa';
 return <section className="n-panel"><div className="panel-heading"><div><h2>Usuários e acessos</h2><p>Cadastre pessoas, defina perfis e redefina senhas temporárias.</p></div><Button onClick={onNew}><Plus data-icon="inline-start"/> Novo usuário</Button></div>
  <div className="access-toolbar"><InputGroup><InputGroupAddon><Search/></InputGroupAddon><InputGroupInput aria-label="Buscar usuário por nome, e-mail ou perfil" placeholder="Buscar por nome, e-mail ou perfil" value={search} onChange={event=>setSearch(event.target.value)}/></InputGroup><label className="access-filter">Situação<select value={filter} onChange={event=>setFilter(event.target.value)}><option value="all">Todos</option><option value="active">Ativos</option><option value="inactive">Desativados</option></select></label></div>
  <div className="table-scroll"><Table><TableHeader><TableRow><TableHead>Usuário</TableHead><TableHead>Perfil</TableHead><TableHead>Acesso</TableHead><TableHead>Senha</TableHead><TableHead>Último login</TableHead><TableHead><span className="sr-only">Ações</span></TableHead></TableRow></TableHeader><TableBody>{rows.map(user=><TableRow key={user.id}><TableCell><b>{user.name}</b>{user.id===actorId&&<small>Você</small>}<small>{user.email}</small></TableCell><TableCell><Badge variant="outline">{roles[user.role]}</Badge></TableCell><TableCell><Badge variant={user.active?'secondary':'outline'}>{user.active?'Ativo':'Desativado'}</Badge></TableCell><TableCell>{status(user)}{user.mustChangePassword&&user.temporaryExpiresAt?<small>Validade: {new Date(user.temporaryExpiresAt).toLocaleDateString('pt-BR',{timeZone:'America/Sao_Paulo'})}</small>:null}</TableCell><TableCell>{user.lastLoginAt?new Date(user.lastLoginAt).toLocaleString('pt-BR',{timeZone:'America/Sao_Paulo'}):'Ainda não acessou'}</TableCell><TableCell><Button size="sm" variant="outline" onClick={()=>onEdit(user)} aria-label={'Editar acesso de '+user.name}><Pencil data-icon="inline-start"/> Gerenciar</Button></TableCell></TableRow>)}</TableBody></Table></div>
  {!rows.length&&<div className="access-empty"><Users/><p>{members.length?'Nenhum usuário corresponde aos filtros.':'Cadastre o primeiro usuário da equipe.'}</p></div>}
  <p className="table-caption">{rows.length} de {members.length} usuários. Desativar preserva o histórico e encerra as sessões. A senha pessoal nunca é exibida ao gestor.</p>
 </section>;
}
export function TemporaryPasswordFields({existing,own,enabled,onEnabled,password,confirmation,onPassword,onConfirmation}:{existing:boolean;own:boolean;enabled:boolean;onEnabled:(enabled:boolean)=>void;password:string;confirmation:string;onPassword:(password:string)=>void;onConfirmation:(confirmation:string)=>void}){
 const id=useId();
 if(own)return <Alert className="wide"><KeyRound/><AlertDescription>Para mudar sua própria senha, use Alterar minha senha no topo da página.</AlertDescription></Alert>;
 return <FieldGroup className="wide">
  {existing&&<Field orientation="horizontal"><div><FieldLabel htmlFor={id}>Definir nova senha temporária</FieldLabel><FieldDescription>Encerra as sessões e exige uma nova senha no próximo acesso.</FieldDescription></div><Switch id={id} checked={enabled} onCheckedChange={onEnabled}/></Field>}
  {(!existing||enabled)&&<><PasswordField label="Senha temporária" temporary value={password} onChange={onPassword}/><PasswordField label="Confirmar senha temporária" temporary value={confirmation} onChange={onConfirmation} error={confirmation&&confirmation!==password?'As senhas ainda não coincidem.':undefined}/><Alert><KeyRound/><AlertDescription>Entregue a senha temporária diretamente à pessoa. Ela terá 7 dias para entrar e definir sua senha pessoal.</AlertDescription></Alert></>}
 </FieldGroup>;
}
