'use client';
import {FormEvent,useRef,useState} from 'react';
import {LoaderCircle,ShieldCheck} from 'lucide-react';
import {Button} from '@/components/ui/button';
import {Alert,AlertDescription} from '@/components/ui/alert';
import {FieldGroup,FieldSet} from '@/components/ui/field';
import PasswordField from './password-field';
import {apiRequest} from '@/lib/client-api';

export default function PasswordChange({firstAccess=false,bootstrap=false,onDone,onCancel}:{firstAccess?:boolean;bootstrap?:boolean;onDone:()=>void;onCancel?:()=>void}){
 const [current,setCurrent]=useState(''),[password,setPassword]=useState(''),[confirmation,setConfirmation]=useState(''),[error,setError]=useState(''),[busy,setBusy]=useState(false);
 const lock=useRef(false),errorRef=useRef<HTMLDivElement>(null);
 async function submit(event:FormEvent){
  event.preventDefault();if(lock.current)return;
  if(password!==confirmation){setError('A confirmação da senha não confere.');requestAnimationFrame(()=>errorRef.current?.focus());return;}
  lock.current=true;setBusy(true);setError('');
  try{await apiRequest('/api/auth/'+(bootstrap?'bootstrap':'change-password'),{currentPassword:current,newPassword:password,confirmPassword:confirmation});setCurrent('');setPassword('');setConfirmation('');onDone();}
  catch(reason){setError(reason instanceof Error?reason.message:'Não foi possível alterar a senha.');requestAnimationFrame(()=>errorRef.current?.focus());}
  finally{lock.current=false;setBusy(false);}
 }
 return <form onSubmit={submit} className="auth-form">
  <Alert><ShieldCheck/><AlertDescription>{firstAccess?'Antes de acessar a operação, crie sua senha pessoal. Ela deve ser diferente da senha temporária.':bootstrap?'Você está ativando o acesso de um gestor já cadastrado. A partir de agora, o login será feito por e-mail e senha.':'Ao salvar, as outras sessões da sua conta serão encerradas.'}</AlertDescription></Alert>
  <FieldSet disabled={busy}><FieldGroup>
   {!firstAccess&&!bootstrap&&<PasswordField label="Senha atual" value={current} onChange={setCurrent} autoComplete="current-password"/>}
   <PasswordField label="Nova senha" value={password} onChange={setPassword}/>
   <PasswordField label="Confirmar nova senha" value={confirmation} onChange={setConfirmation} error={confirmation&&confirmation!==password?'As senhas ainda não coincidem.':undefined}/>
  </FieldGroup></FieldSet>
  {error&&<Alert variant="destructive" role="alert" tabIndex={-1} ref={errorRef}><AlertDescription>{error}</AlertDescription></Alert>}
  <div className="auth-actions">{onCancel&&<Button type="button" variant="outline" disabled={busy} onClick={onCancel}>{firstAccess?'Sair':'Cancelar'}</Button>}<Button type="submit" disabled={busy}>{busy?<><LoaderCircle data-icon="inline-start" className="animate-spin"/> Salvando…</>:bootstrap?'Ativar meu acesso':'Salvar nova senha'}</Button></div>
 </form>;
}
