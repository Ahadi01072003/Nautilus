import {authStatus,login,logout,changePassword,bootstrapPassword,sessionMember} from '@/lib/auth';
import {boundedJSON,sameOrigin,rateLimit} from '@/lib/security';
import {AppError} from '@/lib/domain';
export const dynamic='force-dynamic';
const json=(body:unknown,status=200,extra?:Record<string,string>)=>Response.json(body,{status,headers:{'Cache-Control':'private, no-store',...extra}});
function failure(error:unknown) {
 if(error instanceof AppError)return json({error:error.message},error.status,error.status===429?{'Retry-After':'900'}:undefined);
 console.error('NAUTILUS: falha no serviço de autenticação.');
 return json({error:'Não foi possível concluir o acesso. Tente novamente ou contate o gestor.'},500);
}
export async function GET(request:Request) {
 try{
  if(new URL(request.url).pathname!=='/api/auth/me')return json({error:'Ação não encontrada.'},404);
  return json(await authStatus(request));
 }catch(error){return failure(error);}
}
export async function POST(request:Request) {
 try{
  sameOrigin(request);
  const action=new URL(request.url).pathname.split('/').at(-1);
  if(action==='logout'){const result=await logout(request);return json(result.body,200,{'Set-Cookie':result.cookie});}
  const body=await boundedJSON(request);
  if(action==='change-password'){const member=await sessionMember(request);if(!member)throw new AppError('Sua sessão expirou. Entre novamente.',401);await rateLimit(member.id,'write');}
  const result=action==='login'?await login(request,body):action==='change-password'?await changePassword(request,body):action==='bootstrap'?await bootstrapPassword(request,body):null;
  if(!result)return json({error:'Ação não encontrada.'},404);
  return json(result.body,200,{'Set-Cookie':result.cookie});
 }catch(error){return failure(error);}
}
