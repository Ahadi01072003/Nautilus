import {actor,state,mutate,exportCSV} from '@/lib/service';
import {AppError} from '@/lib/domain';
import {runtime} from '@/lib/db';
import {boundedJSON,sameOrigin,rateLimit,bearerMatches} from '@/lib/security';
import {ensureIntegrity} from '@/lib/integrity';
export const dynamic='force-dynamic';
function json(value:unknown,status=200){return Response.json(value,{status,headers:{'Cache-Control':'no-store'}});}
function error(e:unknown){if(e instanceof AppError)return json({error:e.message},e.status);const msg=e instanceof Error?e.message:'Falha ao processar.';if(msg.includes('UNIQUE constraint')&&msg.includes('appointments.'))return json({error:'Já existe um agendamento para esse equipamento no mesmo horário. Escolha outro horário.'},409);const known=['Responsável sem autorização','Agendamento sem autorização','Agendamento indisponível','Acesso sem autorização','Equipamento incompatível ou inativo','Estoque insuficiente','Quantidade excede','Recebimento excede','Quantidade deve ser inteira','Equipamento incompatível','Operador inativo','Estoque alterado durante conferência','Mantenha ao menos um gestor ativo','Cancelamento sem autorização','Estoque sem autorização'];const found=known.find(x=>msg.includes(x));if(found)return json({error:found==='Quantidade excede'?'Quantidade excede a capacidade máxima.':found+'.'},409);if(msg.includes('UNIQUE constraint'))return json({error:'Este cadastro ou lançamento já existe. Atualize a tela.'},409);console.error('NAUTILUS: falha interna na operação.');return json({error:'Não foi possível concluir. Atualize a tela e confira o resultado antes de tentar novamente.'},500);}
export async function GET(req:Request){try{const a=await actor();const url=new URL(req.url),path=url.pathname.replace(/^\/api\//,'');if(path==='state'){await rateLimit(a.id,'read');return json(await state(a,Number(url.searchParams.get('page')||0),{search:url.searchParams.get('search'),fuel:url.searchParams.get('fuel'),start:url.searchParams.get('start'),end:url.searchParams.get('end')}));}if(path==='export'){await rateLimit(a.id,'export');return await exportCSV(url,a);}return json({error:'Página não encontrada.'},404);}catch(e){return error(e);}}
export async function POST(req:Request){try{
 const url=new URL(req.url),path=url.pathname.replace(/^\/api\//,'');
 if(path==='automation'){if(!await bearerMatches(req.headers.get('Authorization'),runtime().AUTOMATION_TOKEN))return json({error:'Acesso negado.'},401);await ensureIntegrity();await rateLimit('automation','automation');return json({ok:true});}
 sameOrigin(req);
 const a=await actor();await rateLimit(a.id,'write');if(path==='emails/test')await rateLimit(a.id,'email_test');const body=await boundedJSON(req);
 return json(await mutate(path,body,a));
 }catch(e){return error(e);}}
