> Documento histórico do pacote v7 recebido. Para a revisão v8, use docs/acesso-por-senha.md e scripts/prepare-development.mjs. O pacote de código atualizado não inclui o backup de dados de produção.

# NAUTILUS · Projeto completo exportado

Exportação de 09/10/2026 da versão 7 do **NAUTILUS · Abastecimentos**, commit `4e4add5a3a19bfe1b710eee7d91febfa6377efb4`. Os arquivos originais da aplicação foram preservados. A pasta `exportacao/` e este roteiro foram acrescentados para facilitar a abertura e a execução da cópia.

O pacote reúne interface React, servidor Vinext/Cloudflare Workers, banco SQLite/D1, migrações, regras de integridade, notificações Resend, testes e dependências declaradas com versões travadas. Inclui também uma cópia dos dados do banco de produção: **15 tabelas e 140 registros**. Ela contém cadastros, e-mails, identificadores de contas, agendas, abastecimentos, estoques, movimentações e auditoria. Mantenha essa pasta fora de repositórios públicos e distribua o ZIP somente para pessoas autorizadas. `exportacao/.gitignore` já ignora a cópia dos dados.

Nenhuma chave privada do Resend, token de publicação ou sessão do ChatGPT foi incluído. As dependências instaladas (`node_modules`), arquivos temporários e metadados Git não fazem parte do ZIP; `package.json`, `pnpm-lock.yaml` e `pnpm-workspace.yaml` permitem reinstalar as versões definidas. As licenças de código incorporado permanecem no pacote.

## 1. Abrir no Codex

1. Extraia o ZIP e abra a pasta **NAUTILUS** como projeto/pasta de trabalho no Codex.
2. Leia este arquivo, `README.md`, `docs/revisao-seguranca-2026-10-08.md` e `docs/configuracao-email-resend.md`.
3. Para continuar o mesmo site publicado, preserve `.openai/hosting.json`, cujo `project_id` identifica o NAUTILUS existente. O banco e as configurações privadas continuam na hospedagem. A cópia local não publica nada automaticamente.
4. Se decidir criar um projeto completamente novo, ele precisa de hospedagem, banco e autenticação próprios. Não reutilize o ID do site existente para esse novo projeto.

O site estava com o acesso externo **público** no momento da exportação, mas a API continua exigindo conta ChatGPT cadastrada, ativa e com o perfil autorizado. O texto sobre site privado em documentos anteriores descreve a configuração histórica e a proteção dos dados; a situação atual está registrada em `exportacao/MANIFESTO.json`.

## 2. Requisitos locais

- Node.js **22.13 ou superior**; o pacote foi conferido com Node.js **24.19.0**.
- pnpm **11.25.0**, conforme `packageManager` do projeto.
- Python 3, com o módulo padrão `sqlite3`, para executar os testes. Algumas verificações invocam o comando `python`; deixe-o apontando para Python 3. O projeto foi conferido com Python **3.12.14**.
- Acesso à internet na primeira instalação das dependências.

No Windows, a aplicação pode ser aberta normalmente, mas WSL/Linux facilita os scripts auxiliares de instalação e os testes. Para a instalação portátil abaixo, não é necessário usar o instalador especial do ambiente Sites nem os scripts que exigem `flock`/`timeout`.

## 3. Instalar dependências

No terminal, dentro da pasta `NAUTILUS`:

```sh
npm install --global pnpm@11.25.0
pnpm install --frozen-lockfile
```

Se essa versão do pnpm já estiver disponível, pule a instalação global. Preserve o arquivo de trava e o `pnpm-workspace.yaml`: ele também contém as substituições de dependências adotadas na revisão de segurança. Não substituir por `npm install` nem atualizar bibliotecas em massa durante a abertura.

## 4. Preparar um banco local

Escolha **um** dos comandos abaixo, em uma pasta de extração nova. Ambos usam exclusivamente D1 local, com ID fictício, e mantêm os e-mails pausados. Nenhuma operação remota é executada.

**Ambiente vazio para desenvolvimento**, com um gestor local e os combustíveis Diesel/Gás, sem registros reais:

```sh
node exportacao/preparar-local.mjs
```

**Ambiente com a cópia dos registros de produção**, acrescido de um gestor exclusivamente local:

```sh
node exportacao/preparar-local.mjs --com-dados
```

O script cria o banco em `.wrangler/state`, usando a mesma identidade fictícia de D1 do `vite.config.ts`. Ele instala as tabelas e regras e configura `.env.local` com `EMAIL_ENABLED=false`, sem credenciais. Se já houver estado local ou `.env.local`, ele interrompe para preservar esse ambiente; extraia outra cópia para começar um teste novo.

Não copiar `.wrangler`, `.env.local` ou a conta de desenvolvimento para produção. Os dados de teste do ambiente vazio não representam saldo físico real.

## 5. Executar a interface e o servidor

```sh
pnpm dev
```

Abra **http://localhost:5173** e clique em **Entrar com ChatGPT**. Nesta execução portátil, o plugin local simula a entrada como `seedy@sites.test`, vinculado a `local_seedy`. Essa conta foi criada como gestor pelo preparador local. É uma identidade de desenvolvimento, sem conexão com a conta real do ChatGPT.

O simulador de entrada é restrito a localhost e endereços de loopback. Não expor esse servidor à internet. O servidor local termina com `Ctrl+C`.

**Produção depende da autenticação fornecida pelo Sites.** Hospedar o Worker diretamente em outro provedor não implementa esse login automaticamente. Uma migração de hospedagem precisa substituir ou integrar `app/chatgpt-auth.ts`, conservar a autorização da API e configurar um banco D1 equivalente. Supabase é apenas um rascunho de portabilidade em `docs/supabase-schema-draft.sql`; não é o banco ativo.

## 6. Testes e compilação

```sh
pnpm exec tsc --noEmit --incremental false
pnpm test
pnpm build
```

Os dez grupos de testes existentes usam bancos isolados e envios simulados. Cobrem perfis, agenda, consumo/estoque, transações, migrações, destinatários, fila, segurança, renderização e provisionamento. Não enviam e-mails reais nem acessam o banco de produção.

O ZIP acrescenta uma validação da restauração SQL/SQLite, das relações entre tabelas e da igualdade dos estoques com a soma das movimentações. O registro dessas verificações e das verificações locais de abertura fica em `exportacao/VALIDACAO.json`.

O comando `pnpm start` original espera uma compilação em `dist/` e usa o runtime Worker local; para desenvolvimento com o simulador de entrada, prefira `pnpm dev`.

## 7. Conteúdo do banco

| Arquivo | Conteúdo/uso |
| --- | --- |
| `db/schema.ts` | Modelo da aplicação e configuração do Drizzle. |
| `drizzle/` | Cinco migrações publicadas, com histórico e snapshots do esquema. |
| `db/*integrity.sql` | Triggers que protegem estoque, autoria, perfis e agenda. |
| `exportacao/banco/nautilus.sqlite` | Banco SQLite restaurado e validado, com os dados e triggers. |
| `exportacao/banco/captura-producao.json` | Colunas e valores de todas as tabelas exportadas. |
| `exportacao/banco/estrutura.sql` | Esquema final, para um banco novo. |
| `exportacao/banco/dados-producao.sql` | INSERTs do banco, sem recriar tabelas. |
| `exportacao/banco/regras-integridade.sql` | Instalação das regras após restaurar os dados. |
| `exportacao/banco/restauracao-completa.sql` | Esquema, dados e regras, para um banco vazio. |

A leitura de produção foi feita por tabela e páginas, sem interromper a operação; **não é um snapshot transacional do servidor**. A cópia passou nas verificações de integridade e reconciliação descritas no manifesto. As datas da captura e quantidades por tabela estão nesse arquivo. Metadados internos do D1 e do provedor de hospedagem não fazem parte do banco exportado.

Para a mesma publicação existente, use o banco já conectado e não importe esta cópia sobre ele. Para uma restauração em novo D1 de produção, primeiro aplique as migrações pelo mecanismo do destino, preservando seu registro de migrações; só depois importe dados em tabelas vazias, **antes de ativar triggers/servidor**, para não repetir baixas de estoque. Instale as regras de integridade, confira `PRAGMA foreign_key_check` e reconcilie saldos. O SQL completo foi projetado para banco vazio e falha se suas tabelas já existirem.

## 8. E-mails e configurações privadas

O preparador local mantém a fila pausada. A presença de dados de notificações no backup não deve gerar um novo disparo dos avisos históricos. Não reiniciar estados `sent` nem zerar tentativas em massa ao restaurar.

| Configuração | Onde definir |
| --- | --- |
| `RESEND_API_KEY` | Segredo de execução do servidor, com acesso somente de envio. |
| `EMAIL_FROM` | Remetente do domínio verificado; o domínio atual é descrito na documentação Resend. |
| `EMAIL_ENABLED` | `false` para validação; ativar somente após conferir destinatários e entrega. |
| `AUTOMATION_TOKEN` | Opcional, para o endpoint de automação; não está configurado na produção atual. |
| `MEMBER_PROVISIONING` | Importação privada inicial; a lista já aplicada foi removida da configuração de produção. |

No site existente essas configurações continuam no Sites e não precisam ser solicitadas em texto no chat. Em outro ambiente, obtenha/provisione uma chave privada no mecanismo de segredos do destino. Nunca coloque valores em `NEXT_PUBLIC_*`, documentos, Git ou arquivos distribuídos no ZIP.

## 9. Mapa técnico

- **Interface e identidade visual:** `app/workspace.tsx`, `app/appointments.tsx`, `app/email-setup.tsx`, `app/nautilus.css`, `components/ui/`, `public/`.
- **API:** `app/api/[...path]/route.ts`.
- **Regras de negócio e acesso:** `lib/service.ts`, `lib/permissions.ts`, `lib/security.ts`, `lib/scheduling.ts`.
- **Notificações:** `lib/notifications.ts`, `lib/resend.ts`.
- **Servidor e integração de hospedagem:** `build/sites-worker.ts`, `vite.config.ts`, `app/chatgpt-auth.ts`.
- **Banco:** `db/`, `drizzle/`, `exportacao/banco/`.
- **Dependências e versões:** `package.json`, `pnpm-lock.yaml`, `pnpm-workspace.yaml`.
- **Validação:** `tests/`, `exportacao/VALIDACAO.json` e `exportacao/MANIFESTO.json`.

## 10. Manutenção do sistema

Preservar os quatro perfis: solicitante, planejador, abastecedor e gestor. As permissões devem continuar validadas na API e no banco. O botão de registrar abastecimento pertence ao módulo Abastecimentos; solicitações e agenda são um fluxo separado e integrado. O abastecimento é executado pela equipe autorizada, sem exigir uma pessoa exclusiva. Gestores recebem todos os tipos de alerta; planejadores recebem solicitações e abastecedores recebem agendamentos conforme cadastro.

O lote de notificações processa até 20 avisos e respeita um orçamento de tempo; filas excedentes e tentativas depois de falhas ainda dependem de novas ações/consultas ou reenvio pelo gestor. Nenhuma rotina externa de reenvio está configurada. O status `sent` da aplicação significa aceitação pelo Resend; a entrega é conferida no fornecedor.

Este ZIP não cria um novo site, não altera a publicação atual e não transfere automaticamente o banco ou o serviço de autenticação para outro provedor.
