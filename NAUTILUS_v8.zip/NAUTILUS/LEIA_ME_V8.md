# Nautilus v8

Código com login por e-mail e senha e gestão interna de usuários.

Leia docs/acesso-por-senha.md. Execute corepack pnpm install --frozen-lockfile, node scripts/prepare-development.mjs e corepack pnpm dev.

O ZIP contém código e configuração declarada. Dados de produção, segredos, sessões, senhas de teste e dependências instaladas não estão incluídos. As instruções históricas da exportação v7 são preservadas apenas como contexto.

Para atualizar o mesmo site, preserve .openai/hosting.json e o D1 existente; aplique somente drizzle/0005_password_access.sql e publique pelo mecanismo da hospedagem. Não restaure o backup v7 sobre a operação atual.
