# NAUTILUS · Ativação do Resend

Situação em 08/10/2026: o proprietário registrou `logoc.com.br` no Registro.br. O subdomínio `alertas.logoc.com.br` e os quatro registros de autenticação foram verificados no Resend. O remetente é `NAUTILUS <avisos@alertas.logoc.com.br>`. A chave exclusiva foi criada com **Sending access**, restrita a esse domínio, armazenada como segredo no Sites e aplicada na configuração de produção.

O teste realizado pelo gestor no aplicativo foi entregue pelo Resend às 16h07 (Brasília) e o proprietário confirmou o recebimento às 16h16. A autorização anterior de publicação e essa confirmação permitem ativar `EMAIL_ENABLED=true`. O resultado efetivo da implantação e sua revisão de configuração ficam registrados no Sites; não basta alterar a variável sem implantar uma versão.

## O que precisa ser definido

1. Conta Resend sob controle do responsável pelo projeto.
2. Domínio ou subdomínio que esse responsável esteja autorizado a usar e cujo DNS possa configurar.
3. Remetente nesse domínio: `NAUTILUS <avisos@alertas.logoc.com.br>`.
4. Chave exclusiva do NAUTILUS com permissão **Sending access**, restrita ao domínio. Não usar chave de administração geral no site.
5. Contas da equipe cadastradas e ativas, com compartilhamento do site privado e perfil do aplicativo.

O remetente padrão `resend.dev` é restrito a testes da própria conta e está bloqueado nesta integração destinada à equipe. Usar um domínio próprio dispensa alterações no DNS corporativo, mas não define a autorização organizacional para tratar dados da empresa.

## Configuração privada de execução

| Variável | Conteúdo | Proteção |
|---|---|---|
| `RESEND_API_KEY` | Chave de envio do NAUTILUS | Segredo, somente servidor |
| `EMAIL_FROM` | Nome e endereço do remetente verificado | Configuração do servidor |
| `EMAIL_ENABLED` | `false` durante validação; `true` após aprovação da ativação | Configuração do servidor |

Nunca colocar chaves no chat, no código, no Git, em variáveis públicas do navegador ou em arquivos de documentação. Conectar o plugin ao ChatGPT não configura automaticamente a credencial de execução do site. Essa credencial precisa ser provisionada por um mecanismo privado compatível com a hospedagem; não há formulário de credenciais no aplicativo.

A ausência de `EMAIL_ENABLED` mantém os alertas automáticos pausados. O diagnóstico exibido somente ao gestor valida a presença e o formato da configuração; não certifica que o domínio esteja verificado, a chave seja válida no Resend ou o e-mail tenha sido entregue.

## Ordem de ativação

1. Instalar/conectar o plugin Resend ou administrar a conta diretamente no painel do fornecedor.
2. Adicionar o domínio no Resend e cadastrar exatamente os registros SPF/DKIM fornecidos. Revisar DMARC. Verificar o domínio no painel.
3. Provisionar a credencial privada de envio, o remetente e `EMAIL_ENABLED=false`.
4. Publicar a configuração mantendo os alertas pausados durante o teste. A autorização de publicação deste projeto já foi recebida do proprietário.
5. Na aba **Alertas e reposições → Alertas por e-mail**, o gestor usa **Enviar teste para minha conta**. O destinatário é resolvido a partir de seu próprio cadastro autenticado; parâmetros livres de destinatário ou conteúdo são ignorados. Limite de dois testes por minuto e chave de idempotência preservada em nova tentativa.
6. Conferir a chegada real na caixa de entrada e no spam e, quando possível, o estado de entrega no painel do Resend. A aceitação da API não é comprovação de entrega.
7. Validar os perfis e as preferências e revisar a fila já pendente antes de autorizar `EMAIL_ENABLED=true`. A ativação poderá processar avisos acumulados e ainda elegíveis; versões de agendamento substituídas e pessoas revogadas serão dispensadas.
8. Após autorização, aplicar a configuração à versão aprovada e conferir um fluxo de solicitação, agendamento, realização e estoque mínimo com destinatários autorizados.

O teste real do aplicativo foi confirmado pelo fornecedor e pelo proprietário. Antes da ativação foram revisados os cinco cadastros ativos, seus perfis e os 12 avisos pendentes. Um aviso antigo de estoque mínimo ligado a uma reposição recebida foi dispensado automaticamente, preservando o histórico. Na investigação de 08/10 após a ativação, a fila tinha 31 avisos aceitos, um dispensado e nenhum pendente. O Resend confirmou os 32 e-mails como entregues, incluindo o teste próprio e 12 avisos de agendamento para os dois gestores e dois abastecedores.

A demora foi reproduzida: o limite anterior de dois avisos por requisição deixava cinco destinatários pendentes em um fluxo com solicitação e agendamento. Esta correção processa até 20 avisos por ação/consulta, com orçamento de 15 segundos para iniciar tentativas e intervalo mínimo de 500 ms entre envios. O timeout individual de 10 segundos preserva margem no limite de 30 segundos do trabalho em segundo plano. A tela atualiza a fila a cada cinco segundos enquanto há avisos pendentes/em envio e ao retornar à aba, evitando mostrar o estado anterior ao processamento por 45 segundos. Não há rotina externa de reenvio agendada; excesso de lote e novas tentativas após falha ainda dependem de ações/consultas ou do reenvio pelo gestor. O endpoint protegido de automação permanece disponível.

## Regras de envio e conteúdo

- Gestores ativos recebem solicitação, agendamento, realização, cancelamento e estoque mínimo.
- Planejadores recebem solicitações e abastecedores recebem agendamentos, conforme preferências.
- Destinatários somente cadastrados, ativos e elegíveis para o evento, sem cópia aberta ou oculta.
- Cada e-mail contém aviso resumido e link privado, sem TAG, nomes, horímetro, combustível, quantidades ou saldos. Os detalhes ficam no sistema.
- O histórico identifica solicitações **aceitas pelo Resend**; não afirma entrega na caixa de entrada. Não há webhook de confirmação de entrega integrado neste escopo.
- A fila reserva tentativas, revalida destinatários e mantém erros genéricos. Avisos de estoque mínimo só são enviados enquanto a reposição permanece aberta, em compra ou parcialmente recebida; reposições recebidas ou canceladas dispensam o aviso acumulado. O fornecedor conserva as chaves de idempotência por 24 horas; uma falha ambígua retomada depois desse prazo deve ser conferida no painel antes de reenvio manual. Não prometer ausência absoluta de duplicações.
- O plano gratuito consultado em 08/10/2026 oferece 3.000 e-mails/mês e 100/dia; cada destinatário consome um envio. Sem automação independente, filas grandes e tentativas posteriores dependem de novas ações/consultas. Dimensionar o volume antes da ativação.

## Validação técnica

O conjunto automatizado inclui dez grupos, com um grupo específico para configuração inválida, segredo protegido, isolamento dos perfis, pausa da fila, teste somente ao gestor autenticado, idempotência, limitação de frequência e falhas do fornecedor. A regressão de alertas de reposições encerradas foi reproduzida antes da correção; o teste verifica que compras recebidas ou canceladas não enviam, enquanto compras em andamento continuam notificando ambos os gestores. A regressão do lote de dois também foi reproduzida antes da correção: o teste agora conclui os sete destinatários de solicitação/agendamento em uma chamada, não duplica ao consultar novamente e preserva o restante da fila quando o fornecedor simulado é lento. Outro grupo valida o provisionamento privado da equipe, importação única, concorrência, rollback e preservação das revogações. Todos os envios no conjunto automatizado são simulados, sem dados ou serviços reais; o teste manual e os fluxos da equipe confirmados no fornecedor foram realizados separadamente no aplicativo publicado.

## Referências oficiais

- [Verificação de domínio](https://resend.com/docs/add-a-domain)
- [Criação e restrição da chave](https://resend.com/docs/create-an-api-key)
- [Envio e idempotência](https://resend.com/docs/api-reference/emails/send-email)
- [Planos](https://resend.com/pricing)
- [Limite do trabalho em segundo plano](https://developers.cloudflare.com/workers/runtime-apis/context/#waituntil)
