# Nautilus v8: acesso por e-mail e senha

O gestor administra usuários em **Operadores e acessos → Acessos e permissões → Usuários e acessos**. Cada usuário mantém o mesmo identificador e histórico do sistema anterior. O cadastro operacional de um operador continua separado da conta de login.

## Cadastro e primeiro acesso

1. Clique em **Novo usuário**.
2. Informe nome, e-mail, perfil e uma senha temporária; confirme a senha.
3. Entregue a senha diretamente à pessoa. A senha temporária tem de 10 a 128 caracteres e validade de 7 dias.
4. A pessoa entra com e-mail e senha na página inicial.
5. Antes de acessar qualquer dado ou ação operacional, cria e confirma uma senha pessoal de 12 a 128 caracteres, diferente da temporária.

O servidor também aplica o bloqueio: não basta alterar a URL ou ocultar o formulário para acessar a operação. E-mails são normalizados, e um cadastro duplicado não modifica o usuário existente.

## Gerenciamento diário

- **Gerenciar** permite editar nome, perfil, preferências de aviso e situação.
- Ative **Definir nova senha temporária** para recuperar um acesso. Todas as sessões anteriores são encerradas, e uma nova troca será obrigatória.
- **Desativar** preserva os registros e encerra as sessões, inclusive se o usuário for reativado depois.
- **Alterar minha senha**, no topo da página, exige a senha atual e encerra as outras sessões.
- Busca e filtro de situação incluem usuários desativados, contas sem senha e senhas temporárias expiradas.
- O gestor não visualiza senhas pessoais. Senhas temporárias não são devolvidas pela API nem gravadas na auditoria.

Quem esqueceu a senha procura um gestor. Não foi implantado envio automático de recuperação por e-mail. Recomenda-se manter dois gestores ativos para a recuperação entre gestores. Não existe senha mestra nem promoção automática de um visitante.

## Atualizar o site existente

A cópia local está pronta e foi validada. Ela não atualiza automaticamente o site publicado.

1. Faça um backup atual do D1 pelo mecanismo de hospedagem. A cópia do ZIP v7 é histórica e não deve ser importada sobre o banco em operação.
2. No mesmo projeto do Sites, preserve `.openai/hosting.json`, a ligação com o D1 e os segredos de e-mail existentes.
3. Aplique somente a nova migração **drizzle/0005_password_access.sql** pelo mecanismo de migrações da hospedagem. As cinco migrações anteriores permanecem intactas. A migração adiciona três tabelas e dois triggers, sem redefinir usuários, estoque, agenda ou histórico.
4. Publique a compilação desta versão no projeto existente.
5. Um gestor previamente ativo e com identidade ChatGPT já vinculada escolhe **Sou gestor do sistema anterior → Confirmar meu acesso de gestor** e cria sua senha pessoal. Essa ponte existe apenas para ativar uma conta de gestor já cadastrada e ainda sem senha.
6. Depois da ativação, o gestor entra por e-mail e senha e atribui senhas temporárias aos outros usuários, inclusive aos cadastros antigos sem senha.
7. Confira um cadastro, a troca obrigatória, a revogação de uma sessão e os quatro perfis no site publicado, usando contas de validação controladas. Não lance consumo fictício no estoque real.

A ativação inicial confia nos cabeçalhos autenticados fornecidos pelo Sites, como a versão anterior. Não exponha essa ponte em uma hospedagem que aceite esses cabeçalhos diretamente de visitantes. Após a senha ser ativada para uma conta, a identidade do ChatGPT não permite contornar a senha dessa conta.

Publicar o ambiente de desenvolvimento é diferente de implantar o site. Esta conversa não dispõe de ferramenta de implantação do Sites; a implantação no domínio atual ainda não foi executada.

## Desenvolvimento local

Requisitos: Node 22.13+, pnpm 11.25.0, Python 3 com o comando `python`.

```sh
corepack pnpm install --frozen-lockfile
node scripts/prepare-development.mjs
corepack pnpm dev
```

O preparador usa exclusivamente D1 local. Em um banco novo, aplica as migrações e cria um gestor fictício de desenvolvimento, além dos combustíveis Diesel/Gás sem consumo nem estoque real. Não depende do backup de produção. Em um banco existente, preserva os cadastros e verifica as estruturas de autenticação de modo aditivo. `.env.local` só é criado quando ausente, com e-mails pausados.

Na primeira abertura local, use **Sou gestor do sistema anterior**. O simulador de localhost identifica `seedy@sites.test`; crie uma senha exclusivamente de desenvolvimento. Nunca exporte essa conta ou os arquivos `.env.local`, `.wrangler` ou `.sites-runtime` para produção.

```sh
corepack pnpm exec tsc --noEmit --incremental false
corepack pnpm lint
corepack pnpm test
corepack pnpm build
corepack pnpm start
```

O comando `start` executa a compilação em Worker local; ele não publica o site.

## Proteções e validação

- PBKDF2-HMAC-SHA256, 600.000 iterações e salt aleatório individual, validado também no runtime Worker.
- Tokens de sessão aleatórios de 256 bits; somente seu hash fica no D1. Cookies HttpOnly, SameSite=Lax e Secure em HTTPS. Sessões de 8 horas.
- Origem verificada nos POSTs, limite de corpo de 32 KB, respostas sem cache e limites de tentativa por conta/rede.
- Versão de credencial e consultas atuais de autorização; redefinição, desativação e mudança de perfil revogam sessões.
- Proteção contra troca concorrente de senha: apenas uma transação pode vencer.
- API administrativa, perfis, auditoria e regras de integridade continuam conferidos no servidor.

Passaram os 13 grupos de testes: os dez originais, 65 cenários de autenticação/API, autenticação/concorrência em D1 real e filtros/reativação. Compilação, TypeScript e lint foram verificados. Playwright com Chromium percorreu cadastro, primeiro acesso, confirmação divergente, troca, isolamento de perfil, redefinição, rejeição da senha anterior e desativação, em desktop 1440×1000 e celular 390×844. A versão compilada em Worker local foi testada com esses mesmos fluxos, sem erros de execução no navegador.

A migração foi aplicada em uma cópia isolada do SQLite exportado: preservou os registros das 15 tabelas anteriores, os saldos e a integridade referencial. Nenhum banco remoto foi alterado e nenhum e-mail real foi enviado. Entrega de e-mails e implantação no domínio publicado continuam fora dessa validação local.

## Outras melhorias

- Filtros do histórico passam a consultar todo o conjunto autorizado, antes da paginação.
- Períodos inválidos e datas inexistentes são rejeitados.
- Operadores desativados ficam visíveis ao gestor para reativação.
- Campos de seleção e switches receberam associação/nomes acessíveis.
- Senhas podem ser exibidas com um botão, há aviso de Caps Lock e mensagens de erro recebem foco.
- Requisições têm timeout e respostas antigas são descartadas; formulários evitam envio duplo.
- Lint e TypeScript ignoram caches de ferramentas e saídas geradas, evitando varrer dependências fora do código.
