-- RASCUNHO: NÃO APLICADO. Requer projeto escolhido, CLI/migração oficial e QA PostgreSQL.
-- O aplicativo em produção usa D1. Nenhum adaptador Supabase está ativo.
-- Preserva IDs textuais e datas ISO UTC do contrato atual para portabilidade.
BEGIN;
CREATE SCHEMA nautilus;
REVOKE ALL ON SCHEMA nautilus FROM PUBLIC, anon, authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA nautilus REVOKE ALL ON TABLES FROM PUBLIC, anon, authenticated;
ALTER DEFAULT PRIVILEGES IN SCHEMA nautilus REVOKE EXECUTE ON FUNCTIONS FROM PUBLIC, anon, authenticated;
CREATE TABLE nautilus."audits" (
	"id" text PRIMARY KEY NOT NULL,
	"action" text NOT NULL,
	"entity_id" text NOT NULL,
	"author_id" text NOT NULL,
	"author_name" text NOT NULL,
	"created_at" text NOT NULL,
	"detail" text NOT NULL
);

CREATE TABLE nautilus."equipment" (
	"id" text PRIMARY KEY NOT NULL,
	"tag" text NOT NULL,
	"description" text NOT NULL,
	"type" text NOT NULL,
	"fuel_ids" text NOT NULL,
	"active" bigint DEFAULT 1 NOT NULL
);

CREATE UNIQUE INDEX "equipment_tag_unique" ON nautilus."equipment" ("tag");
CREATE TABLE nautilus."fuels" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"unit" text NOT NULL,
	"integral" bigint DEFAULT 0 NOT NULL,
	"capacity_milli" bigint NOT NULL,
	"minimum_milli" bigint NOT NULL,
	"stock_milli" bigint NOT NULL,
	"lead_days" bigint NOT NULL,
	"provisional" bigint DEFAULT 1 NOT NULL,
	"active" bigint DEFAULT 1 NOT NULL,
	"recipient" text DEFAULT '' NOT NULL,
	"version" bigint DEFAULT 0 NOT NULL,
	CONSTRAINT "stock_limits" CHECK("stock_milli">=0 AND "stock_milli"<="capacity_milli" AND "minimum_milli">=0 AND "minimum_milli"<"capacity_milli" AND "lead_days" between 1 and 60)
);

CREATE UNIQUE INDEX "fuels_name_unique" ON nautilus."fuels" ("name");
CREATE TABLE nautilus."holidays" (
	"date" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL
);

CREATE TABLE nautilus."members" (
	"id" text PRIMARY KEY NOT NULL,
	"auth_id" text,
	"email" text NOT NULL,
	"name" text NOT NULL,
	"role" text NOT NULL,
	"active" bigint DEFAULT 1 NOT NULL,
	"created_at" text NOT NULL,
	CONSTRAINT "member_role" CHECK("role" in ('admin','manager','operator'))
);

CREATE UNIQUE INDEX "members_auth_id_unique" ON nautilus."members" ("auth_id");
CREATE UNIQUE INDEX "members_email_unique" ON nautilus."members" ("email");
CREATE TABLE nautilus."movements" (
	"id" text PRIMARY KEY NOT NULL,
	"operation_key" text NOT NULL,
	"fuel_id" text NOT NULL,
	"delta_milli" bigint NOT NULL,
	"kind" text NOT NULL,
	"supply_id" text,
	"request_id" text,
	"balance_after_milli" bigint,
	"occurred_at" text NOT NULL,
	"author_id" text NOT NULL,
	"author_name" text NOT NULL,
	"reason" text NOT NULL ,
 "expected_version" bigint
);

CREATE UNIQUE INDEX "movements_operation_key_unique" ON nautilus."movements" ("operation_key");
CREATE INDEX "idx_movements_fuel_date" ON nautilus."movements" ("fuel_id","occurred_at");
CREATE TABLE nautilus."operators" (
	"id" text PRIMARY KEY NOT NULL,
	"name" text NOT NULL,
	"badge" text DEFAULT '' NOT NULL,
	"active" bigint DEFAULT 1 NOT NULL
);

CREATE TABLE nautilus."outbox" (
	"id" text PRIMARY KEY NOT NULL,
	"request_id" text NOT NULL,
	"recipient" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'pending' NOT NULL,
	"attempts" bigint DEFAULT 0 NOT NULL,
	"last_error" text DEFAULT '' NOT NULL,
	"created_at" text NOT NULL,
	"sent_at" text,
	"locked_at" text
);

CREATE UNIQUE INDEX "outbox_request_id_unique" ON nautilus."outbox" ("request_id");
CREATE TABLE nautilus."requests" (
	"id" text PRIMARY KEY NOT NULL,
	"fuel_id" text NOT NULL,
	"requested_milli" bigint NOT NULL,
	"received_milli" bigint DEFAULT 0 NOT NULL,
	"stock_reference_milli" bigint NOT NULL,
	"opened_at" text NOT NULL,
	"deadline" text NOT NULL,
	"status" text DEFAULT 'open' NOT NULL,
	"recipient" text DEFAULT '' NOT NULL,
	CONSTRAINT "request_received" CHECK("received_milli">=0 AND "received_milli"<="requested_milli" AND "requested_milli">0)
);

CREATE UNIQUE INDEX "idx_request_active_fuel" ON nautilus."requests" ("fuel_id") WHERE "status" in ('open','purchasing','partial');
CREATE TABLE nautilus."supplies" (
	"id" text PRIMARY KEY NOT NULL,
	"operation_key" text NOT NULL,
	"fuel_id" text NOT NULL,
	"equipment_id" text NOT NULL,
	"operator_id" text NOT NULL,
	"quantity_milli" bigint NOT NULL,
	"occurred_at" text NOT NULL,
	"created_at" text NOT NULL,
	"author_id" text NOT NULL,
	"author_name" text NOT NULL,
	"equipment_tag" text NOT NULL,
	"equipment_name" text NOT NULL,
	"operator_name" text NOT NULL,
	"fuel_name" text NOT NULL,
	"unit" text NOT NULL,
	"hourmeter_milli" bigint,
	"hourmeter_end_milli" bigint,
	"notes" text DEFAULT '' NOT NULL,
	"status" text DEFAULT 'confirmed' NOT NULL,
	"cancel_reason" text DEFAULT '' NOT NULL,
	CONSTRAINT "supply_qty" CHECK("quantity_milli">0)
);

CREATE UNIQUE INDEX "supplies_operation_key_unique" ON nautilus."supplies" ("operation_key");
CREATE INDEX "idx_supplies_date" ON nautilus."supplies" ("occurred_at");
CREATE INDEX "idx_supplies_fuel_date" ON nautilus."supplies" ("fuel_id","occurred_at");


ALTER TABLE nautilus."movements" ADD FOREIGN KEY ("fuel_id") REFERENCES nautilus."fuels"("id") ON UPDATE no action ON DELETE no action;
ALTER TABLE nautilus."movements" ADD FOREIGN KEY ("supply_id") REFERENCES nautilus."supplies"("id") ON UPDATE no action ON DELETE no action;
ALTER TABLE nautilus."movements" ADD FOREIGN KEY ("request_id") REFERENCES nautilus."requests"("id") ON UPDATE no action ON DELETE no action;
ALTER TABLE nautilus."movements" ADD FOREIGN KEY ("author_id") REFERENCES nautilus."members"("id") ON UPDATE no action ON DELETE no action;
ALTER TABLE nautilus."outbox" ADD FOREIGN KEY ("request_id") REFERENCES nautilus."requests"("id") ON UPDATE no action ON DELETE no action;
ALTER TABLE nautilus."requests" ADD FOREIGN KEY ("fuel_id") REFERENCES nautilus."fuels"("id") ON UPDATE no action ON DELETE no action;
ALTER TABLE nautilus."supplies" ADD FOREIGN KEY ("fuel_id") REFERENCES nautilus."fuels"("id") ON UPDATE no action ON DELETE no action;
ALTER TABLE nautilus."supplies" ADD FOREIGN KEY ("equipment_id") REFERENCES nautilus."equipment"("id") ON UPDATE no action ON DELETE no action;
ALTER TABLE nautilus."supplies" ADD FOREIGN KEY ("operator_id") REFERENCES nautilus."operators"("id") ON UPDATE no action ON DELETE no action;
ALTER TABLE nautilus."supplies" ADD FOREIGN KEY ("author_id") REFERENCES nautilus."members"("id") ON UPDATE no action ON DELETE no action;

CREATE FUNCTION nautilus.guard_movement() RETURNS trigger
LANGUAGE plpgsql SET search_path = '' AS $$
DECLARE f nautilus.fuels%ROWTYPE; r nautilus.requests%ROWTYPE;
BEGIN
 SELECT * INTO f FROM nautilus.fuels WHERE id=NEW.fuel_id FOR UPDATE;
 IF NOT FOUND OR f.active<>1 THEN RAISE EXCEPTION 'Combustível indisponível'; END IF;
 IF NEW.expected_version IS NOT NULL AND NEW.expected_version<>f.version THEN RAISE EXCEPTION 'Estoque alterado durante conferência'; END IF;
 IF f.integral=1 AND NEW.delta_milli%1000<>0 THEN RAISE EXCEPTION 'Quantidade deve ser inteira'; END IF;
 IF f.stock_milli+NEW.delta_milli<0 THEN RAISE EXCEPTION 'Estoque insuficiente'; END IF;
 IF f.stock_milli+NEW.delta_milli>f.capacity_milli THEN RAISE EXCEPTION 'Quantidade excede a capacidade máxima'; END IF;
 IF NEW.kind='receipt' AND NEW.request_id IS NOT NULL THEN
  SELECT * INTO r FROM nautilus.requests WHERE id=NEW.request_id FOR UPDATE;
  IF NOT FOUND OR r.fuel_id<>NEW.fuel_id OR r.status NOT IN ('open','purchasing','partial') OR NEW.delta_milli<=0 OR r.received_milli+NEW.delta_milli>r.requested_milli THEN RAISE EXCEPTION 'Recebimento inválido ou solicitação encerrada'; END IF;
 END IF;
 NEW.balance_after_milli=f.stock_milli+NEW.delta_milli;
 RETURN NEW;
END; $$;
CREATE TRIGGER movement_guard BEFORE INSERT ON nautilus.movements FOR EACH ROW EXECUTE FUNCTION nautilus.guard_movement();

CREATE FUNCTION nautilus.apply_movement() RETURNS trigger
LANGUAGE plpgsql SET search_path = '' AS $$
BEGIN
 UPDATE nautilus.fuels SET stock_milli=NEW.balance_after_milli,version=version+1 WHERE id=NEW.fuel_id;
 IF NEW.kind='receipt' AND NEW.request_id IS NOT NULL THEN
  UPDATE nautilus.requests SET received_milli=received_milli+NEW.delta_milli,status=CASE WHEN received_milli+NEW.delta_milli=requested_milli THEN 'received' ELSE 'partial' END WHERE id=NEW.request_id;
 END IF;
 RETURN NEW;
END; $$;
CREATE TRIGGER movement_apply AFTER INSERT ON nautilus.movements FOR EACH ROW EXECUTE FUNCTION nautilus.apply_movement();

CREATE FUNCTION nautilus.guard_supply() RETURNS trigger
LANGUAGE plpgsql SET search_path = '' AS $$
BEGIN
 IF NOT EXISTS(SELECT 1 FROM nautilus.equipment WHERE id=NEW.equipment_id AND active=1 AND fuel_ids::jsonb ? NEW.fuel_id) THEN RAISE EXCEPTION 'Equipamento incompatível ou inativo'; END IF;
 IF NOT EXISTS(SELECT 1 FROM nautilus.operators WHERE id=NEW.operator_id AND active=1) THEN RAISE EXCEPTION 'Operador inativo'; END IF;
 RETURN NEW;
END; $$;
CREATE TRIGGER supply_guard BEFORE INSERT ON nautilus.supplies FOR EACH ROW EXECUTE FUNCTION nautilus.guard_supply();

CREATE FUNCTION nautilus.debit_supply() RETURNS trigger
LANGUAGE plpgsql SET search_path = '' AS $$
BEGIN
 INSERT INTO nautilus.movements(id,operation_key,fuel_id,delta_milli,kind,supply_id,occurred_at,author_id,author_name,reason)
 VALUES(NEW.id,'supply:'||NEW.operation_key,NEW.fuel_id,-NEW.quantity_milli,'debit',NEW.id,NEW.created_at,NEW.author_id,NEW.author_name,'Abastecimento '||NEW.equipment_tag);
 RETURN NEW;
END; $$;
CREATE TRIGGER supply_debit AFTER INSERT ON nautilus.supplies FOR EACH ROW EXECUTE FUNCTION nautilus.debit_supply();

CREATE FUNCTION nautilus.enqueue_request() RETURNS trigger
LANGUAGE plpgsql SET search_path = '' AS $$
BEGIN
 INSERT INTO nautilus.outbox(id,request_id,recipient,status,created_at) VALUES(NEW.id,NEW.id,NEW.recipient,'pending',NEW.opened_at);
 RETURN NEW;
END; $$;
CREATE TRIGGER request_email AFTER INSERT ON nautilus.requests FOR EACH ROW EXECUTE FUNCTION nautilus.enqueue_request();

-- Sem políticas de cliente: acesso negado mesmo se o schema for exposto por engano.
ALTER TABLE nautilus.members ENABLE ROW LEVEL SECURITY;
ALTER TABLE nautilus.fuels ENABLE ROW LEVEL SECURITY;
ALTER TABLE nautilus.equipment ENABLE ROW LEVEL SECURITY;
ALTER TABLE nautilus.operators ENABLE ROW LEVEL SECURITY;
ALTER TABLE nautilus.supplies ENABLE ROW LEVEL SECURITY;
ALTER TABLE nautilus.movements ENABLE ROW LEVEL SECURITY;
ALTER TABLE nautilus.requests ENABLE ROW LEVEL SECURITY;
ALTER TABLE nautilus.holidays ENABLE ROW LEVEL SECURITY;
ALTER TABLE nautilus.audits ENABLE ROW LEVEL SECURITY;
ALTER TABLE nautilus.outbox ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON ALL TABLES IN SCHEMA nautilus FROM PUBLIC, anon, authenticated;
REVOKE EXECUTE ON ALL FUNCTIONS IN SCHEMA nautilus FROM PUBLIC, anon, authenticated;
-- Chave exclusiva do servidor; o servidor deve aplicar a autorização individual antes de usar o banco.
GRANT USAGE ON SCHEMA nautilus TO service_role;
GRANT SELECT,INSERT,UPDATE,DELETE ON ALL TABLES IN SCHEMA nautilus TO service_role;
GRANT EXECUTE ON ALL FUNCTIONS IN SCHEMA nautilus TO service_role;
COMMIT;
