# NAUTILUS · revisão aprovada — 08/10/2026

O proprietário aprovou a publicação desta revisão e informou a equipe inicial. O ponto de partida era a versão 4, privada e com acesso apenas ao proprietário. A equipe indicada foi provisionada e autorizada para visualização, com perfis internos separados e sem edição do projeto. O domínio remetente foi verificado, a chave privada provisionada e a entrega do teste do aplicativo confirmada pelo fornecedor e pelo proprietário em 08/10/2026. Essa confirmação libera a ativação das notificações na configuração de produção. Este relatório descreve o pacote aprovado; o resultado da implantação é registrado no Sites.

## Regras implementadas

| Perfil | Abas e dados acessíveis | Operações | E-mails |
| --- | --- | --- | --- |
| Solicitante | Solicitações próprias, incluindo andamento e encerramento | Solicitar com equipamento/TAG, horímetro e combustível; cancelar o próprio pedido enquanto aguarda planejamento | Nenhum aviso administrativo; acompanhamento pelo sistema |
| Planejador | Solicitações e agenda necessárias ao planejamento | Agendar, reagendar e cancelar com justificativa | Novas solicitações, se habilitado no cadastro |
| Abastecedor | Agenda compartilhada e seus próprios registros | Realizar qualquer item agendado, mesmo previsto para outra pessoa | Agendamentos, se habilitado no cadastro |
| Gestor | Toda a operação, cadastros, valores, estoque, correções, auditoria, permissões e exportação | Administrar todos os módulos; registros excepcionais sem agenda exigem justificativa | Todos os avisos: solicitação, agendamento, realização, cancelamento e estoque mínimo/reposição |

O responsável previsto é opcional e não bloqueia a execução. A identificação de quem registrou o consumo vem da conta autenticada. Solicitar e agendar não alteram o estoque. O botão **Registrar abastecimento** fica apenas no módulo Abastecimentos; **Solicitar abastecimento** ocupa a mesma posição no módulo Solicitações para os perfis autorizados.

Os e-mails saem individualmente para contas cadastradas, ativas e elegíveis para o evento. Não há campos para destinatários livres. Gestores ativos recebem todos os eventos independentemente das opções de outros perfis. O remetente e a chave do serviço ficam somente na configuração privada de execução, nunca no navegador ou no repositório. A fila não armazena cópias dos endereços: resolve o cadastro antes de enviar e reconfere revogações.

A fila usa idempotência por evento/destinatário, reserva atômica, tentativas com espera progressiva, recuperação de trabalhos interrompidos e reenvio pelo gestor. Agendamentos substituídos e alertas de estoque mínimo de reposições recebidas ou canceladas deixam de produzir avisos desatualizados. A aceitação pelo fornecedor não comprova chegada à caixa de entrada. A idempotência do Resend expira em 24 horas; uma falha ambígua retomada após esse prazo precisa de conferência antes de reenvio manual.

A investigação dos agendamentos pendentes confirmou 12 avisos desse tipo entregues no Resend e nenhuma pendência na fila naquele momento. O limite de dois avisos por requisição causava atraso e foi reproduzido em teste. O novo lote comporta até 20 avisos, inicia tentativas por até 15 segundos, espaça envios e preserva o timeout individual. A tela acompanha pendências a cada cinco segundos. O teste cobre sete destinatários em uma chamada, consulta posterior sem duplicação e interrupção segura por tempo com continuação do restante da fila. A alteração preserva a seleção por cadastro, perfis, revogação, idempotência e acesso privado; não cria destinatários livres nem dispara registros fictícios em produção.

A integração Resend acrescenta diagnóstico exclusivo do gestor e teste somente para o e-mail de sua própria conta autenticada. A fila automática fica pausada enquanto `EMAIL_ENABLED` não for `true`, mesmo com chave e remetente preenchidos. E-mails levam apenas aviso resumido e link privado; TAG, combustível, nomes, horímetro, saldos e quantidades ficam dentro do sistema. Consulte [o roteiro de ativação](configuracao-email-resend.md).

## Correções de segurança

- Separação de perfis aplicada na API, nas consultas e nas regras do banco, além da navegação. Retirar uma aba da tela não é o mecanismo principal de proteção.
- Solicitantes recebem somente seus pedidos; abastecedores recebem a agenda compartilhada e seus lançamentos. E-mails, permissões, movimentações, auditoria e fila de avisos ficam restritos ao gestor.
- Removida a promoção automática do primeiro visitante a administrador. Contas precisam ser previamente cadastradas; a identidade nativa fica vinculada ao cadastro.
- Acesso ativo e perfil são conferidos por requisição, novamente antes de responder consultas/exportações e nas operações sensíveis do banco. O último gestor ativo é protegido contra remoção acidental.
- Requisições de alteração exigem origem válida e JSON. O limite de 32 KB é aplicado aos bytes realmente recebidos, inclusive sem Content-Length ou com UTF-8 multibyte.
- Limites de frequência por conta/ação, sem guardar IP; token da rotina de e-mails comparado sem comparação direta de texto.
- Respostas privadas sem cache, cabeçalhos de proteção e erros sem detalhes internos ou mensagens privadas do fornecedor.
- Consultas parametrizadas, proteção contra fórmulas em CSV, exportação limitada a 10.000 registros e listagens paginadas.
- Preservadas as transações de estoque, autoria, justificativas e histórico; ajustes obsoletos, excesso de capacidade, frações indevidas e baixa duplicada são bloqueados.

## Dependências

| Auditoria | Antes | Versão de revisão |
| --- | --- | --- |
| Todas as dependências: ocorrências de alertas | 62: 8 baixos, 23 moderados, 30 altos, 1 crítico | 1 alto; nenhum crítico |
| Apenas dependências de produção | — | 0 alertas conhecidos |

O alerta remanescente é `braces@3.0.3`, usado por ferramentas de análise/compilação. O aviso [GHSA-vfj7-8cjw-p6xm](https://github.com/advisories/GHSA-vfj7-8cjw-p6xm) informa ausência de versão corrigida. A árvore de produção e os arquivos JavaScript entregues foram verificados; não foi encontrada essa dependência no código servido. O alerta permanece registrado, sem alterar o resultado da auditoria ou inventar uma correção. A compilação deve continuar restrita a código confiável.

Esses números descrevem avisos de dependências; não demonstram que houve exploração ou vazamento. As atualizações incluem framework, React, ferramentas de compilação, runtime e dependências transitivas com versões corrigidas.

## Preservação dos dados

As migrações já publicadas 0000–0002 permanecem intactas. A nova migração preserva solicitações, agendas, abastecimentos, movimentos, estoque, identidades e vínculos. Destinatários livres antigos são removidos, a fila antiga é desativada e os fluxos ainda pendentes entram na fila baseada em perfis. Registros concluídos antigos não geram um disparo de e-mails históricos.

A conversão é conservadora: administrador atual → gestor; gestor limitado antigo → planejador; operador com autorização antiga de abastecer → abastecedor; demais operadores → solicitante. O cadastro existente possui um administrador ativo com identidade vinculada; seu acesso é preservado como gestor. O proprietário definiu a carga inicial de dois gestores, um planejador e dois abastecedores. A lista é provisionada por configuração privada, sem e-mails no código, com importação única e atômica que preserva identidades e não desfaz revogações posteriores. Nenhum solicitante específico foi informado; esse perfil continua disponível para cadastro por um gestor.

## Verificações

`pnpm test` executa dez grupos: domínio/precisão e datas; integridade/concorrência de estoque; fluxo real de solicitação/agenda/realização e perfis; e-mails com fornecedor simulado; proteção das requisições; migração com dados anteriores; D1/Miniflare com transações e triggers reais do runtime local; renderização React da navegação e das ações por perfil; configuração Resend e teste restrito ao gestor; provisionamento privado da equipe, com importação única, concorrência, rollback, identidade preservada e revogação mantida.

Também são verificados TypeScript, lint dos arquivos alterados de aplicação, compatibilidade das dependências, compilação de produção, ausência de alterações nas migrações anteriores e artefato de distribuição. Os testes usam dados fictícios em bancos separados e não enviam e-mails reais.

## Ativação e limites operacionais

1. Aprovação desta versão e da equipe inicial recebida do proprietário em 08/10/2026.
2. Serviço, domínio, remetente e chave de envio configurados. Teste real do aplicativo entregue pelo Resend e recebimento confirmado pelo proprietário às 16h16 de 08/10/2026 (Brasília). A ativação usa `EMAIL_ENABLED=true` e exige implantação da versão correspondente.
3. Equipe de cinco contas ativas provisionada e público do Sites restrito a essas contas. Permissão do aplicativo e compartilhamento do Sites são controles separados; a equipe recebeu acesso de visualização, sem edição do projeto.
4. Não há rotina externa de reenvio agendada. A fila é processada após ações e consultas ao sistema; a rotina protegida por token está preparada se for necessário reenvio com o site fechado.
5. O controle de navegador exigido pela prévia gerenciada não está disponível nesta sessão. Há testes de renderização e fluxo no servidor, mas não uma validação visual/interativa completa em navegador.

Esta é uma revisão técnica para reduzir risco. Não representa garantia de vazamento zero nem certificação de conformidade com a LGPD. Finalidade, retenção, atendimento aos titulares e resposta a incidentes precisam seguir as definições da organização responsável.

Referência de orientação: [Perguntas frequentes da ANPD](https://www.gov.br/anpd/pt-br/acesso-a-informacao/perguntas-frequentes), incluindo direitos dos titulares e conservação dos dados.
