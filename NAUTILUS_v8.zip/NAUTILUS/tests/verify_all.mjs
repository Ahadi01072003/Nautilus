import {execFileSync} from 'node:child_process';
const checks=[
 [process.execPath,'tests/verify_domain.mjs'],['python','tests/verify_integrity.py'],
 [process.execPath,'tests/verify_scheduling.mjs'],[process.execPath,'tests/verify_notifications.mjs'],
 [process.execPath,'tests/verify_security.mjs'],['python','tests/verify_migration.py'],
 [process.execPath,'tests/verify_d1.mjs'],[process.execPath,'tests/verify_interface.mjs'],[process.execPath,'tests/verify_resend.mjs'],
 [process.execPath,'tests/verify_provisioning.mjs'],[process.execPath,'tests/verify_auth.mjs'],[process.execPath,'tests/verify_auth_d1.mjs'],[process.execPath,'tests/verify_filters.mjs'],
];
for(const [command,...args] of checks)execFileSync(command,args,{stdio:'inherit',env:{...process.env,CLOUDFLARE_CF_FETCH_ENABLED:'false',WRANGLER_SEND_METRICS:'false'}});
console.log('PASS: todos os treze grupos de verificação. Nenhum dado de produção ou e-mail real utilizado.');
