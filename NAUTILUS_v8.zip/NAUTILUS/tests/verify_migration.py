"""Atualização real de 0000–0002 para 0003 com relações já preenchidas."""
import sqlite3
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
c=sqlite3.connect(':memory:');c.row_factory=sqlite3.Row;c.execute('PRAGMA foreign_keys=ON')
for file in sorted((ROOT/'drizzle').glob('000[012]_*.sql')):c.executescript('BEGIN;\n'+file.read_text()+'\nCOMMIT;')
c.executescript((ROOT/'db/integrity.sql').read_text())
c.executescript("CREATE TRIGGER request_email AFTER INSERT ON requests BEGIN INSERT INTO outbox(id,request_id,recipient,created_at) VALUES(NEW.id,NEW.id,NEW.recipient,NEW.opened_at); END;")
T='2026-10-01T12:00:00.000Z'
with c:
 for identifier,role,can_fuel in [('old-admin','admin',0),('old-manager','manager',0),('old-fueler','operator',1),('old-requester','operator',0)]:
  c.execute('INSERT INTO members(id,auth_id,email,name,role,can_fuel,created_at) VALUES(?,?,?,?,?,?,?)',(identifier,'identity-'+identifier,identifier+'@example.com',identifier,role,can_fuel,T))
 c.execute("INSERT INTO operators(id,name) VALUES('o','Operador histórico')")
 c.execute("INSERT INTO equipment(id,tag,description,type,fuel_ids) VALUES('e','HIST-01','Equipamento histórico','Empilhadeira','[\"diesel\"]')")
 c.execute("INSERT INTO fuels(id,name,unit,capacity_milli,minimum_milli,stock_milli,lead_days,recipient) VALUES('diesel','Diesel','L',1000000,100000,0,2,'unregistered@example.net')")
 c.execute("INSERT INTO movements(id,operation_key,fuel_id,delta_milli,kind,occurred_at,author_id,author_name,reason) VALUES('initial','initial','diesel',1000000,'initial',?,'old-admin','Gestor','Inicial')",(T,))
 for identifier,status in [('completed','completed'),('pending','requested'),('scheduled','scheduled'),('cancelled','cancelled')]:
  c.execute('INSERT INTO appointments(id,operation_key,equipment_id,equipment_tag,equipment_name,fuel_id,fuel_name,hourmeter_milli,requester_id,requester_name,created_at,updated_at,status,scheduled_at,assigned_member_id,assigned_name,scheduled_by_id,scheduled_by_name,completed_at,version) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(identifier,identifier,'e','HIST-01','Equipamento histórico','diesel','Diesel',120125,'old-requester','Solicitante',T,T,status,None if status=='requested' else T,None if status=='requested' else 'old-fueler',None if status=='requested' else 'Abastecedor',None if status=='requested' else 'old-manager',None if status=='requested' else 'Planejador',T if status=='completed' else None,2 if status=='completed' else 1 if status=='scheduled' else 0))
 c.execute('INSERT INTO supplies(id,operation_key,appointment_id,fuel_id,equipment_id,operator_id,quantity_milli,occurred_at,created_at,author_id,author_name,equipment_tag,equipment_name,operator_name,fuel_name,unit,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',('supply','supply','completed','diesel','e','o',900000,T,T,'old-fueler','Abastecedor','HIST-01','Equipamento histórico','Operador histórico','Diesel','L','Registro anterior'))
 c.execute("INSERT INTO requests(id,fuel_id,requested_milli,stock_reference_milli,opened_at,deadline,recipient) VALUES('purchase','diesel',900000,100000,?,?,'unregistered@example.net')",(T,T))
original_appointments=[dict(row) for row in c.execute('SELECT * FROM appointments ORDER BY id')]
original_supplies=[dict(row) for row in c.execute('SELECT * FROM supplies ORDER BY id')]
original_movements=[dict(row) for row in c.execute('SELECT * FROM movements ORDER BY id')]
for file in sorted((ROOT/'drizzle').glob('0003_*.sql')):c.executescript('BEGIN;\n'+file.read_text()+'\nCOMMIT;')
for file in ['integrity.sql','scheduling-integrity.sql','security-integrity.sql']:c.executescript((ROOT/'db'/file).read_text())
for old in original_appointments:
 new=dict(c.execute('SELECT * FROM appointments WHERE id=?',(old['id'],)).fetchone())
 assert all(new[key]==value for key,value in old.items()),old['id']
 assert new['cancelled_by_id'] is None
assert [dict(row) for row in c.execute('SELECT * FROM supplies ORDER BY id')]==original_supplies
assert [dict(row) for row in c.execute('SELECT * FROM movements ORDER BY id')]==original_movements
assert c.execute('SELECT stock_milli FROM fuels').fetchone()[0]==100000
mapping={row['id']:row['profile'] for row in c.execute('SELECT * FROM members')}
assert mapping=={'old-admin':'manager','old-manager':'planner','old-fueler':'fueler','old-requester':'requester'}
assert c.execute('PRAGMA foreign_key_check').fetchall()==[]
assert c.execute("SELECT recipient,status FROM outbox WHERE id='purchase'").fetchone()[:]==('','skipped')
assert c.execute('SELECT recipient FROM fuels').fetchone()[0]==''
assert c.execute('SELECT recipient FROM requests').fetchone()[0]==''
assert c.execute("SELECT count(*) FROM notification_events WHERE entity_id='completed'").fetchone()[0]==0
assert c.execute('SELECT count(*) FROM notification_events').fetchone()[0]==3
assert c.execute('SELECT count(*) FROM notifications').fetchone()[0]==5
with c:c.execute("UPDATE appointments SET scheduled_at='2026-10-09T12:00:00.000Z',status='scheduled',assigned_member_id=NULL,assigned_name=NULL,scheduled_by_id='old-manager',version=version+1 WHERE id='pending'")
assert c.execute("SELECT assigned_member_id FROM appointments WHERE id='pending'").fetchone()[0] is None
assert c.execute('PRAGMA foreign_key_check').fetchall()==[]
print('PASS: migração com agendas, registros, movimentações, estoque e vínculos existentes; perfis conservadores, destinatários antigos removidos e fila ativa preservada.')
