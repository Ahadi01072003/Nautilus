import sqlite3,tempfile,threading
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
T='2026-10-07T18:00:00.000Z'
def schema(c):
 c.execute('PRAGMA foreign_keys=ON')
 for file in sorted((ROOT/'drizzle').glob('*.sql')):c.executescript('BEGIN;\n'+file.read_text()+'\nCOMMIT;')
 c.executescript((ROOT/'db/integrity.sql').read_text())
 c.executescript((ROOT/'db/scheduling-integrity.sql').read_text())
 c.executescript((ROOT/'db/security-integrity.sql').read_text())
 with c:
  c.execute('INSERT INTO members(id,email,name,role,profile,created_at) VALUES(?,?,?,?,?,?)',('u','qa@example.com','QA','admin','manager',T))
  c.execute("INSERT INTO operators(id,name) VALUES('o','Operador QA')")
  c.execute('INSERT INTO equipment(id,tag,description,type,fuel_ids) VALUES(?,?,?,?,?)',('e','QA-01','Equipamento de teste','Teste','["diesel","gas"]'))
  for fid,name,unit,cap,minimum,lead,integral in [('diesel','Diesel','L',1000000,100000,2,0),('gas','Gás','cilindros',5000,2000,5,1)]:
   c.execute('INSERT INTO fuels(id,name,unit,capacity_milli,minimum_milli,stock_milli,lead_days,integral) VALUES(?,?,?,?,?,0,?,?)',(fid,name,unit,cap,minimum,lead,integral))
   c.execute('INSERT INTO movements(id,operation_key,fuel_id,delta_milli,kind,occurred_at,author_id,author_name,reason) VALUES(?,?,?,?,?,?,?,?,?)',('initial-'+fid,'initial:'+fid,fid,cap,'initial',T,'u','QA','Inicial'))
def supply(c,key,q,fuel='diesel'):
 with c:c.execute('INSERT INTO supplies(id,operation_key,fuel_id,equipment_id,operator_id,quantity_milli,occurred_at,created_at,author_id,author_name,equipment_tag,equipment_name,operator_name,fuel_name,unit,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',(key,key,fuel,'e','o',q,T,T,'u','QA','QA-01','Equipamento de teste','Operador QA',fuel,'L' if fuel=='diesel' else 'cilindros','Teste de estoque independente da agenda'))
def stock(c,f='diesel'):return c.execute('SELECT stock_milli FROM fuels WHERE id=?',(f,)).fetchone()[0]
def rejected(fn):
 try:fn()
 except sqlite3.IntegrityError:return
 raise AssertionError('Operação deveria ser rejeitada')
c=sqlite3.connect(':memory:');schema(c)
supply(c,'120-litros',120000);assert stock(c)==880000
rejected(lambda:supply(c,'120-litros',120000));assert stock(c)==880000;assert c.execute("SELECT count(*) FROM movements WHERE kind='debit'").fetchone()[0]==1
rejected(lambda:supply(c,'insuficiente',900000));assert stock(c)==880000
rejected(lambda:supply(c,'fracao-cilindro',1500,'gas'));assert stock(c,'gas')==5000
supply(c,'gas-1',1000,'gas');supply(c,'gas-2',2000,'gas');assert stock(c,'gas')==2000
with c:c.execute("INSERT INTO requests(id,fuel_id,requested_milli,stock_reference_milli,opened_at,deadline) VALUES('pedido','gas',3000,2000,?,?)",(T,'2026-10-14T18:00:00Z'))
rejected(lambda:c.execute("INSERT INTO requests(id,fuel_id,requested_milli,stock_reference_milli,opened_at,deadline) VALUES('duplicado','gas',3000,2000,?,?)",(T,T)));c.rollback()
assert c.execute('SELECT count(*) FROM outbox').fetchone()[0]==0
supply(c,'gas-3',1000,'gas');assert stock(c,'gas')==1000
with c:c.execute("INSERT INTO movements(id,operation_key,fuel_id,delta_milli,kind,request_id,occurred_at,author_id,author_name,reason) VALUES('receb','receb','gas',3000,'receipt','pedido',?,'u','QA','Reposição')",(T,))
assert stock(c,'gas')==4000;assert c.execute("SELECT status,received_milli FROM requests WHERE id='pedido'").fetchone()==('received',3000)
rejected(lambda:c.execute("INSERT INTO movements(id,operation_key,fuel_id,delta_milli,kind,occurred_at,author_id,author_name,reason) VALUES('excesso','excesso','gas',2000,'receipt',?,'u','QA','Excesso')",(T,)));c.rollback();assert stock(c,'gas')==4000
version=c.execute("SELECT version FROM fuels WHERE id='diesel'").fetchone()[0]
supply(c,'outra-saida',10000)
rejected(lambda:c.execute("INSERT INTO movements(id,operation_key,fuel_id,delta_milli,kind,occurred_at,author_id,author_name,reason,expected_version) VALUES('ajuste-obsoleto','ajuste-obsoleto','diesel',-120000,'adjustment',?,'u','QA','Conferência',?)",(T,version)));c.rollback();assert stock(c)==870000
with c:c.execute("INSERT INTO movements(id,operation_key,fuel_id,delta_milli,kind,occurred_at,author_id,author_name,reason,expected_version) VALUES('ajuste','ajuste','diesel',-110000,'adjustment',?,'u','QA','Conferência',?)",(T,version+1))
assert stock(c)==760000
c.execute("UPDATE operators SET active=0 WHERE id='o'");c.commit();rejected(lambda:supply(c,'operador-inativo',1000));assert stock(c)==760000
with tempfile.TemporaryDirectory() as temp:
 path=str(Path(temp)/'concurrency.sqlite');conn=sqlite3.connect(path);schema(conn);conn.close();barrier=threading.Barrier(2);out=[]
 def run(q):
  cx=sqlite3.connect(path,timeout=10);cx.execute('PRAGMA foreign_keys=ON');barrier.wait()
  try:supply(cx,'concurrent-'+str(q),q);out.append('ok')
  except sqlite3.IntegrityError:out.append('rejected')
  finally:cx.close()
 threads=[threading.Thread(target=run,args=(q,)) for q in [800000,300000]]
 for th in threads:th.start()
 for th in threads:th.join()
 cx=sqlite3.connect(path);assert sorted(out)==['ok','rejected'];assert stock(cx) in [200000,700000];assert cx.execute("SELECT count(*) FROM supplies").fetchone()[0]==1;cx.close()
upgrade=sqlite3.connect(':memory:');upgrade.execute('PRAGMA foreign_keys=ON')
for file in sorted((ROOT/'drizzle').glob('000[01]_*.sql')):upgrade.executescript(file.read_text())
upgrade.executescript((ROOT/'db/integrity.sql').read_text())
with upgrade:
 upgrade.execute("INSERT INTO members(id,email,name,role,created_at) VALUES('old','old@example.com','Histórico','admin',?)",(T,))
 upgrade.execute("INSERT INTO operators(id,name) VALUES('old-op','Operador histórico')")
 upgrade.execute('INSERT INTO equipment(id,tag,description,type,fuel_ids) VALUES(?,?,?,?,?)',('old-equipment','HIST-01','Equipamento histórico','Teste','["diesel"]'))
 upgrade.execute("INSERT INTO fuels(id,name,unit,capacity_milli,minimum_milli,stock_milli,lead_days) VALUES('diesel','Diesel','L',1000000,100000,0,2)")
 upgrade.execute("INSERT INTO movements(id,operation_key,fuel_id,delta_milli,kind,occurred_at,author_id,author_name,reason) VALUES('old-initial','old-initial','diesel',1000000,'initial',?,'old','Histórico','Inicial')",(T,))
 upgrade.execute('INSERT INTO supplies(id,operation_key,fuel_id,equipment_id,operator_id,quantity_milli,occurred_at,created_at,author_id,author_name,equipment_tag,equipment_name,operator_name,fuel_name,unit) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)',('old-supply','old-supply','diesel','old-equipment','old-op',100000,T,T,'old','Histórico','HIST-01','Equipamento histórico','Operador histórico','Diesel','L'))
for file in sorted((ROOT/'drizzle').glob('0002_*.sql')):upgrade.executescript(file.read_text())
for file in sorted((ROOT/'drizzle').glob('0003_*.sql')):upgrade.executescript('BEGIN;\n'+file.read_text()+'\nCOMMIT;')
upgrade.executescript((ROOT/'db/scheduling-integrity.sql').read_text())
upgrade.executescript((ROOT/'db/security-integrity.sql').read_text())
assert upgrade.execute("SELECT quantity_milli,appointment_id,status FROM supplies WHERE id='old-supply'").fetchone()==(100000,None,'confirmed')
assert stock(upgrade)==900000
assert upgrade.execute("SELECT profile,can_fuel FROM members WHERE id='old'").fetchone()==('manager',1)
assert upgrade.execute('PRAGMA foreign_key_check').fetchall()==[]
print('PASS: estoque, concorrência e atualização do schema preservando abastecimentos anteriores.')
