import assert from 'node:assert/strict';
import {mkdtempSync,readFileSync,readdirSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {createRequire} from 'node:module';
import {harness} from './service_harness.mjs';
const require=createRequire(import.meta.resolve('wrangler/package.json'));
const {Miniflare,convertV4MiniflareOptions}=require('miniflare');
const temp=mkdtempSync(join(tmpdir(),'nautilus-d1-'));
const mf=new Miniflare(convertV4MiniflareOptions({modules:true,script:'export default {fetch(){return new Response("qa");}}',compatibilityDate:'2026-09-30',d1Databases:{DB:'qa-current',LEGACY:'qa-legacy'},d1Persist:temp,cf:false}));
function statements(file){return readFileSync(file,'utf8').split('--> statement-breakpoint').map(s=>s.trim()).filter(s=>s.replace(/--[^\n]*/g,'').trim());}
const migrations=readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort();
const apply=async(database,files)=>{for(const file of files)await database.batch(statements('drizzle/'+file).map(sql=>database.prepare(sql)));};
const install=async(database)=>{for(const file of ['integrity.sql','scheduling-integrity.sql','security-integrity.sql'])await database.batch(statements('db/'+file).map(sql=>database.prepare(sql.replace('CREATE TRIGGER ','CREATE TRIGGER IF NOT EXISTS '))));};
const T=new Date().toISOString();
try{
 const d=await mf.getD1Database('DB');await apply(d,migrations);await install(d);await install(d);
 await d.batch([
  ...[['a','manager','admin'],['p','planner','manager'],['r','requester','operator'],['f','fueler','operator'],['f2','fueler','operator']].map(([id,profile,role])=>d.prepare('INSERT INTO members(id,email,name,profile,role,created_at) VALUES(?,?,?,?,?,?)').bind(id,id+'@example.com',id,profile,role,T)),
  d.prepare("INSERT INTO equipment(id,tag,description,type,fuel_ids) VALUES('e','QA-01','Equipamento','Teste','[\"diesel\"]')"),
  d.prepare("INSERT INTO operators(id,name) VALUES('o','Operador QA')"),
  d.prepare("INSERT INTO fuels(id,name,unit,capacity_milli,minimum_milli,stock_milli,lead_days) VALUES('diesel','Diesel','L',1000000,100000,0,2)"),
  d.prepare("INSERT INTO movements(id,operation_key,fuel_id,delta_milli,kind,occurred_at,author_id,author_name,reason) VALUES('initial','initial','diesel',1000000,'initial',?,'a','Gestor','Inicial QA')").bind(T),
  d.prepare("INSERT INTO appointments(id,operation_key,equipment_id,equipment_tag,equipment_name,fuel_id,fuel_name,hourmeter_milli,requester_id,requester_name,created_at,updated_at) VALUES('request','request','e','QA-01','Equipamento','diesel','Diesel',0,'r','Solicitante',?,?)").bind(T,T)
 ]);
 await d.prepare("UPDATE appointments SET status='scheduled',scheduled_at=?,assigned_member_id=NULL,scheduled_by_id='p',version=version+1 WHERE id='request'").bind(T).run();
 const notesBefore=(await d.prepare('SELECT count(*) n FROM notification_events').first()).n;
 await d.batch([
  d.prepare("UPDATE appointments SET version=version+1 WHERE id='request' AND version=99"),
  d.prepare("INSERT INTO audits(id,action,entity_id,author_id,author_name,created_at,detail) SELECT 'stale','Abastecimento agendado','request','p','Planejador',?,'{}' WHERE changes()>0").bind(T),
  d.prepare("INSERT INTO notification_events(id,kind,entity_type,entity_id,created_at) SELECT 'stale','scheduled','appointments','request',? WHERE changes()>0").bind(T)
 ]);
 assert.equal((await d.prepare('SELECT count(*) n FROM notification_events').first()).n,notesBefore);
 await d.prepare("UPDATE appointments SET assigned_member_id='f' WHERE id='request'").run();
 const supply="INSERT INTO supplies(id,operation_key,appointment_id,fuel_id,equipment_id,operator_id,quantity_milli,occurred_at,created_at,author_id,author_name,equipment_tag,equipment_name,operator_name,fuel_name,unit,notes,hourmeter_milli) VALUES(?,?,?,'diesel','e','o',?,?,?,?,'Abastecedor','QA-01','Equipamento','Operador QA','Diesel','L',?,0)";
 await d.prepare(supply).bind('supply','supply','request',80000,T,T,'f2','QA').run();
 assert.equal((await d.prepare("SELECT status FROM appointments WHERE id='request'").first()).status,'completed');
 assert.equal((await d.prepare("SELECT stock_milli FROM fuels WHERE id='diesel'").first()).stock_milli,920000);
 await assert.rejects(()=>d.batch([d.prepare(supply).bind('over','over',null,2000000,T,T,'a','Exceção QA'),d.prepare("INSERT INTO notification_events(id,kind,entity_type,entity_id,created_at) VALUES('failed','completed','supplies','over',?)").bind(T)]),/Estoque insuficiente/);
 assert.equal((await d.prepare("SELECT count(*) n FROM notification_events WHERE id='failed'").first()).n,0);
 assert.equal((await d.prepare("SELECT stock_milli FROM fuels WHERE id='diesel'").first()).stock_milli,920000);
 assert.deepEqual((await d.prepare('PRAGMA foreign_key_check').all()).results,[]);
 // Importação real no D1; a credencial privada jamais faz parte do artefato.
 await d.prepare("UPDATE members SET auth_id='owner-identity' WHERE id='a'").run();
 const provisioned=harness(null,d),setup={revision:'qa-real-d1-v1',ownerEmail:'a@example.com',members:[{email:'a@example.com',name:'Gestor atualizado',profile:'manager'},{email:'new@example.com',name:'Novo planejador',profile:'planner'}]};
 provisioned.config({MEMBER_PROVISIONING:JSON.stringify(setup)});await provisioned.load('lib/member-provisioning.ts').ensureMemberProvisioning();
 assert.equal((await d.prepare("SELECT auth_id FROM members WHERE id='a'").first()).auth_id,'owner-identity');
 assert.equal((await d.prepare("SELECT profile FROM members WHERE email='new@example.com'").first()).profile,'planner');
 await d.prepare("UPDATE members SET active=0 WHERE email='new@example.com'").run();
 const restart=harness(null,d);restart.config({MEMBER_PROVISIONING:JSON.stringify(setup)});await restart.load('lib/member-provisioning.ts').ensureMemberProvisioning();
 assert.equal((await d.prepare("SELECT active FROM members WHERE email='new@example.com'").first()).active,0);
 // Recria o schema anterior com um abastecimento já ligado a uma agenda.
 const legacy=await mf.getD1Database('LEGACY');await apply(legacy,migrations.filter(f=>f<'0003_'));
 await legacy.batch([
  legacy.prepare("INSERT INTO members(id,email,name,role,created_at) VALUES('old','old@example.com','Gestor','admin',?)").bind(T),
  legacy.prepare("INSERT INTO operators(id,name) VALUES('o','Operador')"),
  legacy.prepare("INSERT INTO equipment(id,tag,description,type,fuel_ids) VALUES('e','HIST-01','Equipamento','Teste','[\"diesel\"]')"),
  legacy.prepare("INSERT INTO fuels(id,name,unit,capacity_milli,minimum_milli,stock_milli,lead_days) VALUES('diesel','Diesel','L',1000000,100000,910000,2)"),
  legacy.prepare("INSERT INTO appointments(id,operation_key,equipment_id,equipment_tag,equipment_name,fuel_id,fuel_name,hourmeter_milli,requester_id,requester_name,created_at,updated_at,status,scheduled_at,assigned_member_id,scheduled_by_id,completed_at) VALUES('old-request','old-request','e','HIST-01','Equipamento','diesel','Diesel',0,'old','Gestor',?,?,'completed',?,'old','old',?)").bind(T,T,T,T),
  legacy.prepare(supply).bind('old-supply','old-supply','old-request',90000,T,T,'old','Anterior')
 ]);
 await apply(legacy,migrations.filter(f=>f>='0003_'));await install(legacy);
 assert.equal((await legacy.prepare("SELECT profile FROM members WHERE id='old'").first()).profile,'manager');
 assert.equal((await legacy.prepare("SELECT appointment_id FROM supplies WHERE id='old-supply'").first()).appointment_id,'old-request');
 assert.equal((await legacy.prepare("SELECT stock_milli FROM fuels WHERE id='diesel'").first()).stock_milli,910000);
 assert.deepEqual((await legacy.prepare('PRAGMA foreign_key_check').all()).results,[]);
 console.log('PASS: D1/Miniflare real, migrações e triggers preparados, agenda compartilhada, baixa, rollback, changes() e atualização de vínculos já existentes.');
}finally{await mf.dispose();rmSync(temp,{recursive:true,force:true});}
