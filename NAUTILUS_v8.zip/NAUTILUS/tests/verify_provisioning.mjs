import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {harness} from './service_harness.mjs';
const temp=mkdtempSync(join(tmpdir(),'nautilus-provisioning-'));
const config={revision:'qa-team-v1',ownerEmail:'admin@example.com',members:[
 {name:'Gestor QA atualizado',email:'admin@example.com',profile:'manager'},
 {name:'Outro gestor novo',email:'second-new@example.com',profile:'manager'},
 {name:'Planejador novo',email:'planner-new@example.com',profile:'planner'},
 {name:'Abastecedor um',email:'fueler-one@example.com',profile:'fueler'},
 {name:'Abastecedor dois',email:'fueler-two@example.com',profile:'fueler'}
]};
try{
 const path=join(temp,'qa.sqlite'),h=harness(path);h.bridge({setup:true});
 const service=h.load('lib/service.ts'),provision=h.load('lib/member-provisioning.ts').ensureMemberProvisioning;
 const original=await h.row("SELECT * FROM members WHERE id='admin'"),originalMovements=await h.all('SELECT * FROM movements ORDER BY id');
 const count=(await h.row('SELECT count(*) n FROM members')).n;
 await provision();assert.equal((await h.row('SELECT count(*) n FROM members')).n,count);
 for(const invalid of [
  'invalid',JSON.stringify({...config,revision:'bad'}),JSON.stringify({...config,members:[]}),
  JSON.stringify({...config,members:[...config.members,config.members[0]]}),
  JSON.stringify({...config,members:[{...config.members[0],profile:'operator'}]}),
  JSON.stringify({...config,members:[{...config.members[0],profile:'requester'}]}),
  JSON.stringify({...config,members:[{...config.members[0],email:'bad@example.com\r\nCC:other@example.com'}]})
 ]){
  h.config({MEMBER_PROVISIONING:invalid});await assert.rejects(async()=>provision(),e=>e.status===503&&!e.message.includes('@'));
  assert.equal((await h.row('SELECT count(*) n FROM members')).n,count);
 }
 h.config({MEMBER_PROVISIONING:JSON.stringify(config)});const other=harness(path);other.config({MEMBER_PROVISIONING:JSON.stringify(config)});
 await Promise.all([provision(),other.load('lib/member-provisioning.ts').ensureMemberProvisioning()]);
 assert.equal((await h.row('SELECT count(*) n FROM members')).n,count+4);
 assert.equal((await h.row('SELECT count(*) n FROM member_provisioning_batches')).n,1);
 assert.equal((await h.row("SELECT count(*) n FROM audits WHERE action='Equipe inicial configurada'")).n,1);
 const owner=await h.row("SELECT * FROM members WHERE email='admin@example.com'");
 assert.equal(owner.id,original.id);assert.equal(owner.auth_id,original.auth_id);assert.equal(owner.created_at,original.created_at);assert.equal(owner.profile,'manager');
 assert.deepEqual(await h.all('SELECT * FROM movements ORDER BY id'),originalMovements);
 for(const member of config.members){const row=await h.row('SELECT * FROM members WHERE email=?',member.email);assert.equal(row.profile,member.profile);assert.equal(row.active,1);assert.equal(row.notify_requests,1);assert.equal(row.notify_schedule,1);}
 h.identity({email:'planner-new@example.com',userId:'new-planner-identity'});const planner=await service.actor();assert.equal(planner.profile,'planner');
 assert.equal((await h.row('SELECT auth_id FROM members WHERE id=?',planner.id)).auth_id,'new-planner-identity');
 const state=await service.state(planner);assert.deepEqual(state.actor.modules,['solicitacoes']);assert.equal(state.members.length,0);assert.ok(!JSON.stringify(state).includes('second-new@example.com'));assert.ok(!JSON.stringify(state).includes(config.revision));
 await assert.rejects(()=>service.mutate('members',{...config,MEMBER_PROVISIONING:JSON.stringify(config),email:'outsider@example.com',name:'Falso gestor',role:'manager'},planner),e=>e.status===403);
 h.identity({email:'outsider@example.com',userId:'first-random-login'});await assert.rejects(()=>service.actor(),e=>e.status===403);
 h.identity({email:'planner-new@example.com',userId:'different-identity'});await assert.rejects(()=>service.actor(),e=>e.status===403);
 await h.run("UPDATE members SET active=0 WHERE email='fueler-two@example.com'");
 const reboot=harness(path);reboot.config({MEMBER_PROVISIONING:JSON.stringify({...config,members:config.members.map(m=>({...m,name:'Alteração indevida',profile:'manager'}))})});
 reboot.identity({email:'fueler-two@example.com',userId:'revoked-identity'});await assert.rejects(()=>reboot.load('lib/service.ts').actor(),e=>e.status===403);
 assert.equal((await h.row("SELECT active FROM members WHERE email='fueler-two@example.com'")).active,0);
 assert.equal((await h.row("SELECT profile FROM members WHERE email='planner-new@example.com'")).profile,'planner');
 const empty=harness(join(temp,'empty.sqlite'));empty.bridge({setup:true,empty:true});empty.config({MEMBER_PROVISIONING:JSON.stringify(config)});
 await assert.rejects(async()=>empty.load('lib/member-provisioning.ts').ensureMemberProvisioning(),e=>e.status===503);assert.equal((await empty.row('SELECT count(*) n FROM members')).n,0);
 const rollback=harness(join(temp,'rollback.sqlite'));rollback.bridge({setup:true});rollback.config({MEMBER_PROVISIONING:JSON.stringify(config)});
 await rollback.run("CREATE TRIGGER provisioning_qa_guard BEFORE INSERT ON members WHEN NEW.email='planner-new@example.com' BEGIN SELECT RAISE(ABORT,'QA rollback'); END");
 await assert.rejects(async()=>rollback.load('lib/member-provisioning.ts').ensureMemberProvisioning(),/QA rollback/);
 assert.equal((await rollback.row('SELECT count(*) n FROM member_provisioning_batches')).n,0);assert.equal((await rollback.row("SELECT count(*) n FROM members WHERE email='second-new@example.com'")).n,0);
 assert.equal((await rollback.row("SELECT name FROM members WHERE id='admin'")).name,original.name);
 console.log('PASS: equipe por configuração privada, importação única/concorrente e atômica, identidade e histórico preservados, perfis isolados, revogação mantida e nenhuma promoção por primeiro login.');
}finally{rmSync(temp,{recursive:true,force:true});}
