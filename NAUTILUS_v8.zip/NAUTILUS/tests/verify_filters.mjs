import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {join} from 'node:path';
import {tmpdir} from 'node:os';
import {harness} from './service_harness.mjs';
const folder=mkdtempSync(join(tmpdir(),'nautilus-filters-'));
try {
 const h=harness(join(folder,'filters.sqlite'));h.bridge({setup:true});
 const {actor,state,exportCSV,mutate}=h.load('lib/service.ts'),a=await actor();
 for(let i=0;i<102;i++)await h.run("INSERT INTO supplies(id,operation_key,fuel_id,equipment_id,operator_id,quantity_milli,occurred_at,created_at,author_id,author_name,equipment_tag,equipment_name,operator_name,fuel_name,unit,notes) VALUES(?,?,'diesel','e','o',1000,?,'2026-01-01T00:00:00.000Z','admin','Gestor QA',?,?,'Operador QA','Diesel','L','Exceção QA')",'record-'+i,'operation-'+i,i===101?'2025-01-01T12:00:00.000Z':'2026-01-01T12:00:00.000Z',i===101?'ANTIGO-ESPECIAL':'QA-01',i===101?'ÁRVORE ESPECIAL':'Equipamento QA');
 const initial=await state(a);assert.equal(initial.supplies.length,100);assert.equal(initial.pagination.supplies,102);assert.ok(!initial.supplies.some(s=>s.equipment_tag==='ANTIGO-ESPECIAL'));
 const searched=await state(a,0,{search:'antigo-especial'});assert.equal(searched.supplies.length,1);assert.equal(searched.pagination.supplies,1);assert.equal(searched.supplies[0].id,'record-101');
 assert.equal((await state(a,0,{search:'árvore'})).pagination.supplies,1);
 assert.equal((await state(a,0,{start:'2025-01-01',end:'2025-12-31'})).pagination.supplies,1);
 assert.equal((await state(a,0,{fuel:'gas'})).supplies.length,0);
 await assert.rejects(()=>state(a,0,{start:'2026-02-30'}),e=>e.status===400);
 await assert.rejects(()=>state(a,0,{start:'2026-10-01',end:'2026-09-01'}),e=>e.status===400);
 await assert.rejects(()=>exportCSV(new URL('https://qa.example.com/api/export?start=2026-02-30'),a),e=>e.status===400);
 await assert.rejects(()=>exportCSV(new URL('https://qa.example.com/api/export?start=2026-10-01&end=2026-09-01'),a),e=>e.status===400);
 await mutate('operators',{id:'o',name:'Operador físico QA',active:false},a);
 assert.equal((await state(a)).operators.find(o=>o.id==='o').active,0);
 h.identity({userId:'executor',email:'executor@example.com'});const fueler=await actor();assert.equal((await state(fueler)).operators.length,0);assert.equal((await state(fueler,0,{search:'antigo'})).supplies.length,0);
 await mutate('operators',{id:'o',name:'Operador físico QA',active:true},a);assert.equal((await state(a)).operators.find(o=>o.id==='o').active,1);
 assert.deepEqual(await h.all('PRAGMA foreign_key_check'),[]);
 console.log('PASS: filtros em todo o histórico, contagem/paginação, períodos reais, isolamento por perfil e reativação de operador.');
}finally{rmSync(folder,{recursive:true,force:true});}
