import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {mkdtempSync,readFileSync,readdirSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {harness} from './service_harness.mjs';
const require=createRequire(import.meta.resolve('wrangler/package.json'));
const {Miniflare,convertV4MiniflareOptions}=require('miniflare');
const folder=mkdtempSync(join(tmpdir(),'nautilus-auth-d1-'));
const mf=new Miniflare(convertV4MiniflareOptions({modules:true,script:'export default {fetch(){return new Response("qa")}}',compatibilityDate:'2026-09-30',d1Databases:{DB:'qa-auth'},d1Persist:folder,cf:false}));
try{
 const database=await mf.getD1Database('DB');
 for(const file of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())await database.batch(readFileSync('drizzle/'+file,'utf8').split('--> statement-breakpoint').map(s=>s.trim()).filter(s=>s.replace(/--[^\n]*/g,'').trim()).map(sql=>database.prepare(sql)));
 await database.prepare("INSERT INTO members(id,email,name,role,profile,auth_id,created_at) VALUES('admin','admin@example.com','Gestor QA','admin','manager','admin',?)").bind(new Date().toISOString()).run();
 const h=harness(null,database,{simulateIdentity:false}),auth=h.load('lib/auth.ts');
 const req=(cookie='')=>new Request('https://qa.example.com/api/auth/change-password',{method:'POST',headers:{Cookie:cookie}});
 const initial='GestorPrincipal-2026',first='AlteracaoPessoal-2026A',second='AlteracaoPessoal-2026B';
 const activated=await auth.bootstrapPassword(req(),{newPassword:initial,confirmPassword:initial});
 const cookie=activated.cookie.split(';')[0];assert.ok(await auth.sessionMember(req(cookie)));
 // Two real D1 transactions compete for the same credential version. Exactly one may win.
 const changed=await Promise.allSettled([auth.changePassword(req(cookie),{currentPassword:initial,newPassword:first,confirmPassword:first}),auth.changePassword(req(cookie),{currentPassword:initial,newPassword:second,confirmPassword:second})]);
 assert.equal(changed.filter(r=>r.status==='fulfilled').length,1);assert.equal(changed.filter(r=>r.status==='rejected').length,1);
 assert.equal(await auth.sessionMember(req(cookie)),null);
 assert.equal((await database.prepare("SELECT count(*) n FROM auth_sessions WHERE member_id='admin'").first()).n,1);
 assert.equal((await database.prepare("SELECT count(*) n FROM auth_events WHERE event='password_changed'").first()).n,1);
 const winner=changed.find(r=>r.status==='fulfilled').value.cookie.split(';')[0];assert.ok(await auth.sessionMember(req(winner)));
 await database.prepare("UPDATE members SET profile='requester' WHERE id='admin'").run();assert.equal(await auth.sessionMember(req(winner)),null);
 await database.prepare("UPDATE members SET profile='manager' WHERE id='admin'").run();assert.equal(await auth.sessionMember(req(winner)),null);
 assert.deepEqual((await database.prepare('PRAGMA foreign_key_check').all()).results,[]);
 console.log('PASS: autenticação em D1 real, troca concorrente com um único vencedor, auditoria e revogação após mudança de perfil.');
}finally{await mf.dispose();rmSync(folder,{recursive:true,force:true});}
