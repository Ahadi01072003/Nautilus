import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
import React from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
const require=createRequire(import.meta.url);
const toolsRequire=createRequire(import.meta.resolve('wrangler/package.json'));
const {build}=toolsRequire('esbuild');
async function compile(entry,exports=''){
 const result=await build({entryPoints:[entry],bundle:true,platform:'node',format:'cjs',write:false,jsx:'automatic',external:['react','react/*','react-dom','react-dom/*'],loader:{'.css':'empty'},logLevel:'silent',plugins:exports?[{name:'test-exports',setup(b){b.onLoad({filter:/app\/workspace\.tsx$/},({path})=>({contents:readFileSync(path,'utf8')+'\n'+exports,loader:'tsx'}));}}]:[]});
 const compiledModule={exports:{}};new Function('require','module','exports',result.outputFiles[0].text)(require,compiledModule,compiledModule.exports);return compiledModule.exports;
}
const {default:Appointments}=await compile('app/appointments.tsx');
const {Navigation,SidebarProvider}=await compile('app/workspace.tsx','export {Navigation,SidebarProvider};');
const {default:EmailSetupPanel}=await compile('app/email-setup.tsx');
for(const ready of [false,true]){
 const html=renderToStaticMarkup(React.createElement(EmailSetupPanel,{setup:{provider:'Resend',ready,enabled:false,apiKeyConfigured:ready,senderConfigured:ready,sender:ready?'NAUTILUS <avisos@example.com>':null,domain:ready?'example.com':null,status:ready?'configured':'missing',message:ready?'Configuração preenchida':'Falta configurar'}}));
 assert.ok(html.includes('Enviar teste para minha conta'));assert.ok(html.includes('Pausados'));assert.equal(/<button[^>]*\sdisabled(?:=|\s|>)/.test(html),!ready);assert.ok(!html.includes('type="password"'));assert.ok(!html.includes('RESEND_API_KEY'));
}
const now=Date.now(),base={id:'qa',equipment_tag:'QA-01',equipment_name:'Equipamento QA',fuel_name:'Diesel',hourmeter_milli:0,requester_id:'requester',requester_name:'Solicitante QA',created_at:new Date(now).toISOString(),status:'requested'};
const scheduled={...base,id:'qa-2',status:'scheduled',scheduled_at:new Date(now+3600000).toISOString(),assigned_name:null};
const modules={requester:['solicitacoes'],planner:['solicitacoes'],fueler:['solicitacoes','abastecimentos'],manager:['visao','solicitacoes','abastecimentos','estoque','alertas','equipamentos','operadores','combustiveis','exportacao']};
for(const role of Object.keys(modules)){
 const actor={id:role,name:'Conta QA',role,modules:modules[role],canFuel:['fueler','manager'].includes(role),canPlan:['planner','manager'].includes(role),canRequest:['requester','manager'].includes(role)};
 const data={actor,requests:[]};
 const navigation=renderToStaticMarkup(React.createElement(SidebarProvider,null,React.createElement(Navigation,{view:'solicitacoes',setView(){},data,identity:null})));
 assert.ok(navigation.includes('Solicitações e agenda'));
 for(const restricted of ['Controle de estoque','Alertas e reposições','Operadores e acessos','Combustíveis e unidades','Exportação'])assert.equal(navigation.includes(restricted),role==='manager');
 assert.equal(navigation.includes('>Abastecimentos<'),['fueler','manager'].includes(role));
 const html=renderToStaticMarkup(React.createElement(Appointments,{rows:[base,scheduled],actor,now,onOpen(){},onExecute(){},onViewSupply(){}}));
 if(role==='requester'){assert.ok(html.includes('Minhas solicitações'));assert.ok(!html.includes('>Agendar<'));assert.ok(!html.includes('Ir para abastecimento'));}
 if(role==='planner'){assert.ok(html.includes('>Agendar<'));assert.ok(!html.includes('Ir para abastecimento'));}
 if(role==='fueler'){assert.ok(html.includes('Ir para abastecimento'));assert.ok(html.includes('Equipe de abastecimento'));assert.ok(!html.includes('>Reagendar<'));assert.ok(!html.includes('value="requests"'));}
}
console.log('PASS: renderização React das abas por perfil; solicitante sem planejamento, planejador sem realização, abastecedor com agenda compartilhada e gestor com módulos administrativos.');
