import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {harness} from './service_harness.mjs';
const temp=mkdtempSync(join(tmpdir(),'nautilus-security-'));
try{
 const h=harness(join(temp,'qa.sqlite'));h.bridge({setup:true});
 const {GET,POST}=h.load('app/api/[...path]/route.ts');
 const {boundedJSON,sameOrigin,MAX_BODY_BYTES,bearerMatches,securityHeaders,rateLimit}=h.load('lib/security.ts');
 const request=(path,body='{}',headers={},method='POST')=>new Request('https://qa.example.com/api/'+path,{method,headers:{Origin:'https://qa.example.com','Content-Type':'application/json',...headers},...(method==='POST'?{body}:{})});
 const status=async(req,code)=>assert.equal((await (req.method==='POST'?POST(req):GET(req))).status,code);
 h.identity(null);await status(request('state',null,{},'GET'),401);
 h.identity({userId:'unknown',email:'unknown@example.com'});await status(request('state',null,{},'GET'),403);
 h.identity({userId:'requester',email:'requester@example.com'});
 await status(new Request('https://qa.example.com/api/appointments',{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'}),403);
 await status(request('appointments','{}',{Origin:'https://attacker.example.com'}),403);
 await status(request('appointments','{}',{'Sec-Fetch-Site':'cross-site'}),403);
 await status(request('appointments','{}',{'Content-Type':'text/plain'}),415);
 for(const body of ['invalid','[]','null'])await status(request('appointments',body),400);
 await status(request('appointments',JSON.stringify({field:'x'.repeat(MAX_BODY_BYTES)})),413);
 await status(request('appointments',JSON.stringify({field:'€'.repeat(12000)}),{'Content-Length':'1'}),413);
 const data=JSON.stringify({field:'x'.repeat(MAX_BODY_BYTES-12)});assert.equal(new TextEncoder().encode(data).length,MAX_BODY_BYTES);
 assert.equal((await boundedJSON(request('appointments',data))).field.length,MAX_BODY_BYTES-12);
 assert.throws(()=>sameOrigin(request('appointments','{}',{Origin:'null'})),e=>e.status===403);
 const read=await GET(request('state',null,{},'GET'));assert.equal(read.headers.get('Cache-Control'),'no-store');const state=await read.json();assert.deepEqual(state.actor.modules,['solicitacoes']);assert.ok(!JSON.stringify(state).includes('@example.com'));
 await status(request('export',null,{},'GET'),403);
 for(const route of ['stock','members','fuels','equipment','operators','holidays','supplies','appointments/schedule','emails/retry'])await status(request(route),403);
 await status(request('state?page=-1',null,{},'GET'),400);
 await status(request('state?page=1.5',null,{},'GET'),400);
 await status(request('automation'),401);h.config({AUTOMATION_TOKEN:'QA_AUTOMATION_SECRET'});
 await status(request('automation','{}',{Authorization:'Bearer wrong'}),401);
 await status(request('automation','{}',{Authorization:'Bearer QA_AUTOMATION_SECRET'}),200);
 assert.equal(await bearerMatches('Bearer QA_AUTOMATION_SECRET','QA_AUTOMATION_SECRET'),true);assert.equal(await bearerMatches('Bearer QA_AUTOMATION_SECRETx','QA_AUTOMATION_SECRET'),false);assert.equal(await bearerMatches(null,'QA'),false);
 await h.run('DELETE FROM rate_limits');
 const realNow=Date.now,minuteNow=realNow();Date.now=()=>minuteNow;
 try{
 for(let i=0;i<30;i++)await rateLimit('requester','write');await assert.rejects(()=>rateLimit('requester','write'),e=>e.status===429);
 await h.run('UPDATE rate_limits SET window_start=window_start-1');await rateLimit('requester','write');assert.equal((await h.row("SELECT hits FROM rate_limits WHERE key='requester:write'")).hits,1);
 }finally{Date.now=realNow;}
 const headers=securityHeaders(new Response('<html></html>',{headers:{'Content-Type':'text/html'}}),new Request('https://qa.example.com'));
 assert.equal(headers.headers.get('Cache-Control'),'private, no-store');assert.equal(headers.headers.get('X-Content-Type-Options'),'nosniff');assert.equal(headers.headers.get('Referrer-Policy'),'no-referrer');assert.match(headers.headers.get('Content-Security-Policy'),/object-src 'none'/);assert.match(headers.headers.get('Strict-Transport-Security'),/31536000/);
 const empty=harness(join(temp,'empty.sqlite'));empty.bridge({setup:true,empty:true});empty.identity({userId:'first-user',email:'first-user@example.com'});
 await assert.rejects(()=>empty.load('lib/service.ts').actor(),e=>e.status===403);assert.equal((await empty.row('SELECT count(*) n FROM members')).n,0);
 console.log('PASS: API sem identidade/acesso, isolamento, CSRF/origem, limite real de 32 KB, UTF-8, formato, paginação, frequência, token e ausência de promoção automática no primeiro login.');
}finally{rmSync(temp,{recursive:true,force:true});}
