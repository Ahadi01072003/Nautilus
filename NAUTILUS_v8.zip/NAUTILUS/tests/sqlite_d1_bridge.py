"""SQLite bridge for isolated integration tests of the actual service functions."""
import json,sqlite3,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
request=json.load(sys.stdin)
connection=sqlite3.connect(request['path'])
connection.row_factory=sqlite3.Row
connection.execute('PRAGMA foreign_keys=ON')
try:
 if request.get('setup'):
  for file in sorted((root/'drizzle').glob('*.sql')):connection.executescript('BEGIN;\n'+file.read_text()+'\nCOMMIT;')
  for file in ['integrity.sql','scheduling-integrity.sql','security-integrity.sql']:connection.executescript((root/'db'/file).read_text())
  if not request.get("empty"):
   with connection:
    for identifier,name,profile in [('admin','Gestor QA','manager'),('manager2','Outro gestor QA','manager'),('planner','Planejador QA','planner'),('requester','Solicitante QA','requester'),('requester2','Outro solicitante QA','requester'),('executor','Abastecedor QA','fueler'),('other','Outro abastecedor QA','fueler')]:
     role='admin' if profile=='manager' else 'manager' if profile=='planner' else 'operator'
     connection.execute('INSERT INTO members(id,auth_id,email,name,role,profile,can_fuel,created_at) VALUES(?,?,?,?,?,?,?,?)',(identifier,identifier,identifier+'@example.com',name,role,profile,int(profile in ('manager','fueler')),'2026-01-01T00:00:00.000Z'))
    connection.execute("INSERT INTO operators(id,name) VALUES('o','Operador físico QA')")
    connection.execute("INSERT INTO equipment(id,tag,description,type,fuel_ids) VALUES('e','QA-01','Equipamento QA','Empilhadeira','[\"diesel\",\"gas\"]')")
    connection.execute("INSERT INTO equipment(id,tag,description,type,fuel_ids) VALUES('e2','QA-02','Outro equipamento QA','Empilhadeira','[\"diesel\"]')")
    for identifier,name,unit,capacity,minimum,lead,integral in [('diesel','Diesel','L',1000000,100000,2,0),('gas','Gás','cilindros',5000,2000,5,1)]:
     connection.execute('INSERT INTO fuels(id,name,unit,capacity_milli,minimum_milli,stock_milli,lead_days,integral) VALUES(?,?,?,?,?,0,?,?)',(identifier,name,unit,capacity,minimum,lead,integral))
     connection.execute('INSERT INTO movements(id,operation_key,fuel_id,delta_milli,kind,occurred_at,author_id,author_name,reason) VALUES(?,?,?,?,?,?,?,?,?)',('initial-'+identifier,'initial:'+identifier,identifier,capacity,'initial','2026-01-01T00:00:00.000Z','admin','Admin QA','Inicial QA'))
  print(json.dumps({'success':True}))
 else:
  output=[]
  with connection:
   for statement in request['statements']:
    cursor=connection.execute(statement['sql'],statement.get('params',[]))
    rows=[dict(row) for row in cursor.fetchall()] if cursor.description else []
    changes=connection.execute('SELECT changes()').fetchone()[0]
    output.append({'results':rows,'success':True,'meta':{'changes':changes}})
  print(json.dumps(output))
except Exception as error:
 connection.rollback()
 print(json.dumps({'error':str(error)}))
finally:connection.close()
