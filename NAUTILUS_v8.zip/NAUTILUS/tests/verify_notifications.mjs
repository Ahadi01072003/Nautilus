import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {harness} from './service_harness.mjs';
const temp=mkdtempSync(join(tmpdir(),'nautilus-notifications-'));
const h=harness(join(temp,'qa.sqlite')),originalFetch=global.fetch,sent=[];
try{
 h.bridge({setup:true});
 const {actor,mutate}=h.load('lib/service.ts'),{flushNotifications}=h.load('lib/notifications.ts');
 const as=async(id)=>{h.identity({userId:id,email:id+'@example.com'});return actor();};
 const admin=await as('admin'),requester=await as('requester'),planner=await as('planner'),executor=await as('executor');
 const post=(path,body,a)=>mutate(path,body,a,'https://qa.example.com');
 const future=new Date(Date.now()+86400000).toISOString();
 let key=0;
 const create=()=>post('appointments',{operationKey:'mail-'+(++key),equipmentId:'e',fuelId:'diesel',hourmeter:0},requester);
 global.fetch=async()=>{throw new Error('Nenhum envio é permitido sem configuração.');};
 const request=await create();
 await flushNotifications('https://qa.example.com');
 assert.equal((await h.row("SELECT sum(attempts) total FROM notifications")).total,0);
 h.config({RESEND_API_KEY:'re_qa_dummy_secret_for_tests_only',EMAIL_FROM:'qa@example.com',EMAIL_ENABLED:'true'});
 global.fetch=async(url,options)=>{
  assert.equal(url,'https://api.resend.com/emails');assert.equal(options.headers.Authorization,'Bearer re_qa_dummy_secret_for_tests_only');
  const body=JSON.parse(options.body);assert.equal(body.to.length,1);assert.ok(!body.text.includes('@example.com'));assert.ok(!body.text.includes('re_qa_dummy_secret_for_tests_only'));assert.ok(!body.cc);assert.ok(!body.bcc);assert.ok(!/Equipamento:|Horímetro|Quantidade:|Saldo na abertura|Combustível:/.test(body.text));
  sent.push({key:options.headers['Idempotency-Key'],...body});return Response.json({id:'qa-message'});
 };
 await h.run("UPDATE members SET active=0 WHERE id='planner'");
 await h.run("UPDATE members SET notify_requests=0,notify_schedule=0 WHERE profile='manager'");
 for(let i=0;i<3;i++)await Promise.all([flushNotifications('https://qa.example.com'),flushNotifications('https://qa.example.com')]);
 assert.deepEqual(sent.map(x=>x.to[0]).sort(),['admin@example.com','manager2@example.com']);
 assert.equal(new Set(sent.map(x=>x.key)).size,sent.length);
 assert.equal((await h.row("SELECT status FROM notifications WHERE member_id='planner'")).status,'skipped');
 await h.run("UPDATE members SET active=1 WHERE id='planner'");
 await post('appointments/schedule',{id:request.id,version:0,scheduledAt:future},planner);
 await h.run("UPDATE members SET active=0 WHERE id='other'");
 await h.run("UPDATE members SET notify_schedule=0 WHERE id='executor'");
 for(let i=0;i<3;i++)await flushNotifications('https://qa.example.com');
 const scheduled=sent.filter(x=>x.subject.includes('agendado'));
 assert.deepEqual(scheduled.map(x=>x.to[0]).sort(),['admin@example.com','manager2@example.com']);
 const completed=await post('supplies',{operationKey:'mail-supply',appointmentId:request.id,equipmentId:'e',fuelId:'diesel',operatorId:'o',quantity:900,hourmeter:0,occurredAt:new Date().toISOString()},executor);
 for(let i=0;i<3;i++)await Promise.all([flushNotifications('https://qa.example.com'),flushNotifications('https://qa.example.com')]);
 assert.equal(sent.filter(x=>x.subject.includes('realizado')).length,2);assert.equal(sent.filter(x=>x.subject.includes('Estoque mínimo')).length,2);
 for(const recipient of ['admin@example.com','manager2@example.com']){
  for(const title of ['Nova solicitação','agendado','realizado','Estoque mínimo'])assert.ok(sent.some(x=>x.to[0]===recipient&&x.subject.includes(title)));
 }
 assert.equal(new Set(sent.map(x=>x.key)).size,sent.length);
 const request2=await create();
 global.fetch=async()=>new Response('Detalhes privados do fornecedor re_qa_dummy_secret_for_tests_only',{status:500});
 for(let i=0;i<2;i++)await flushNotifications('https://qa.example.com');
 const failed=await h.all("SELECT * FROM notifications WHERE status='failed'");assert.equal(failed.length,3);assert.ok(failed.every(x=>x.attempts===1));assert.ok(failed.every(x=>!x.last_error.includes('re_qa_dummy_secret_for_tests_only')));
 await flushNotifications('https://qa.example.com');assert.ok((await h.all("SELECT attempts FROM notifications WHERE status='failed'")).every(x=>x.attempts===1));
 await h.run("UPDATE notifications SET locked_at='2000-01-01T00:00:00.000Z' WHERE status='failed'");
 const failedKeys=new Set(failed.map(x=>'nautilus-notice/'+x.id)),retryKeys=[];
 global.fetch=async(url,options)=>{retryKeys.push(options.headers['Idempotency-Key']);return Response.json({id:'qa-retry'});};
 for(let i=0;i<3;i++)await Promise.all([flushNotifications('https://qa.example.com'),flushNotifications('https://qa.example.com')]);
 assert.equal(retryKeys.length,3);assert.deepEqual(new Set(retryKeys),failedKeys);assert.equal((await h.row("SELECT count(*) n FROM notifications WHERE status='failed'")).n,0);
 // Uma promoção/revogação antes do envio não muda a lista por endereço livre.
 await h.run("UPDATE members SET notify_requests=0 WHERE id='planner'");
 const request3=await create();assert.equal((await h.row('SELECT count(*) n FROM notifications n JOIN notification_events e ON e.id=n.event_id WHERE e.entity_id=?',request3.id)).n,2);

 // Reagendamento torna a versão anterior dispensável, sem envio duplicado.
 await post('appointments/schedule',{id:request2.id,version:0,scheduledAt:future},planner);
 await post('appointments/schedule',{id:request2.id,version:1,scheduledAt:new Date(Date.now()+2*86400000).toISOString()},planner);
 for(let i=0;i<4;i++)await flushNotifications('https://qa.example.com');
 assert.equal((await h.row("SELECT count(*) n FROM notifications n JOIN notification_events e ON e.id=n.event_id WHERE e.entity_id=? AND e.kind='scheduled' AND e.version=1 AND n.status='skipped'",request2.id)).n,2);
 await post('supplies/cancel',{id:completed.id,reason:'Correção QA'},admin);for(let i=0;i<3;i++)await flushNotifications('https://qa.example.com');
 assert.equal((await h.row("SELECT count(*) n FROM notifications n JOIN notification_events e ON e.id=n.event_id WHERE e.entity_type='supplies' AND e.kind='cancelled' AND n.status='sent'")).n,2);
 assert.equal((await h.row("SELECT count(*) n FROM notifications WHERE status='sending'")).n,0);
 // Avisos acumulados não podem pedir reposição de uma compra já concluída ou cancelada.
 const minimumEvent=await h.row("SELECT id,entity_id FROM notification_events WHERE kind='minimum' LIMIT 1");
 assert.ok(minimumEvent);
 let minimumCalls=0;
 global.fetch=async()=>{minimumCalls++;return Response.json({id:'qa-minimum'});};
 const resetMinimum=()=>h.run("UPDATE notifications SET status='pending',attempts=0,locked_at=NULL,sent_at=NULL WHERE event_id=?",minimumEvent.id);
 for(const status of ['received','cancelled']){
  await h.run('UPDATE requests SET status=? WHERE id=?',status,minimumEvent.entity_id);
  await resetMinimum();
  await flushNotifications('https://qa.example.com');
  assert.equal(minimumCalls,0,`Reposição ${status} não deve enviar alerta antigo de estoque mínimo.`);
  assert.equal((await h.row("SELECT count(*) n FROM notifications WHERE event_id=? AND status='skipped'",minimumEvent.id)).n,2);
 }
 // Uma reposição ainda em andamento continua notificando ambos os gestores.
 await h.run("UPDATE requests SET status='purchasing' WHERE id=?",minimumEvent.entity_id);
 await resetMinimum();
 await flushNotifications('https://qa.example.com');
 assert.equal(minimumCalls,2);
 assert.equal((await h.row("SELECT count(*) n FROM notifications WHERE event_id=? AND status='sent'",minimumEvent.id)).n,2);
 // Uma única ação deve processar o fluxo completo, sem novas visitas à página.
 const queue=harness(join(temp,'single-action.sqlite'));queue.bridge({setup:true});
 queue.config({RESEND_API_KEY:'re_qa_dummy_secret_for_tests_only',EMAIL_FROM:'qa@example.com',EMAIL_ENABLED:'true'});
 const service=queue.load('lib/service.ts'),flushQueue=queue.load('lib/notifications.ts').flushNotifications;
 queue.identity({userId:'requester',email:'requester@example.com'});
 const single=await service.mutate('appointments',{operationKey:'single-action-request',equipmentId:'e',fuelId:'diesel',hourmeter:0},await service.actor());
 queue.identity({userId:'planner',email:'planner@example.com'});
 await service.mutate('appointments/schedule',{id:single.id,version:0,scheduledAt:future},await service.actor());
 const singleRecipients=[];
 global.fetch=async(url,options)=>{singleRecipients.push(JSON.parse(options.body));return Response.json({id:'qa-single-action'});};
 await flushQueue('https://qa.example.com');
 assert.equal((await queue.row("SELECT count(*) n FROM notifications WHERE status IN ('pending','sending','failed')")).n,0,'Um único processamento deve concluir todos os destinatários do fluxo.');
 assert.equal(singleRecipients.length,7);
 assert.deepEqual(singleRecipients.filter(x=>x.subject.includes('agendado')).map(x=>x.to[0]).sort(),['admin@example.com','executor@example.com','manager2@example.com','other@example.com']);
 await flushQueue('https://qa.example.com');assert.equal(singleRecipients.length,7,'Atualizar a página não deve repetir os avisos.');
 // Fornecedor lento: o lote termina dentro do orçamento e preserva o restante.
 await queue.run("UPDATE notifications SET status='pending',attempts=0,locked_at=NULL,sent_at=NULL");
 const realNow=Date.now;let elapsed=realNow(),slowCalls=0;
 Date.now=()=>elapsed;
 global.fetch=async()=>{elapsed+=9000;slowCalls++;return Response.json({id:'qa-slow-send'});};
 try{await flushQueue('https://qa.example.com');}finally{Date.now=realNow;}
 assert.equal(slowCalls,2);
 assert.equal((await queue.row("SELECT count(*) n FROM notifications WHERE status='pending'")).n,5);
 assert.equal((await queue.row("SELECT count(*) n FROM notifications WHERE status='sending'")).n,0);
 global.fetch=async()=>Response.json({id:'qa-remaining-send'});
 await flushQueue('https://qa.example.com');
 assert.equal((await queue.row("SELECT count(*) n FROM notifications WHERE status='sent'")).n,7);
 console.log('PASS: destinatários por perfil, todos os avisos aos gestores, revogação e preferências, fila sem configuração, envio individual simulado, concorrência, idempotência, falha/reenvio, versões antigas e reposições encerradas dispensadas.');
}finally{global.fetch=originalFetch;rmSync(temp,{recursive:true,force:true});}
