import {readFileSync} from 'node:fs';
import {execFileSync} from 'node:child_process';
import ts from 'typescript';
import {createRequire} from 'node:module';
const nativeRequire=createRequire(import.meta.url);

/** Executa o serviço real com SQLite isolado; não usa dados ou serviços reais. */
export function harness(path,liveDatabase=null,{simulateIdentity=true}={}){
 let identity={userId:'admin',email:'admin@example.com'},config={},requestHeaders=new Headers();
 const cache=new Map();
 function bridge(input){
  const result=JSON.parse(execFileSync('python',['tests/sqlite_d1_bridge.py'],{input:JSON.stringify({path,...input}),encoding:'utf8'}));
  if(result.error)throw new Error(result.error);return result;
 }
 function prepare(sql,params=[]){return {sql,params,bind(...values){return prepare(sql,values)},async run(){return bridge({statements:[{sql,params}]})[0]},async all(){return this.run()},async first(column){const row=(await this.run()).results[0]||null;return column&&row?row[column]:row}};}
 const database=liveDatabase||{prepare,async batch(statements){return bridge({statements:statements.map(({sql,params})=>({sql,params}))});}};
 function load(file){
  if(cache.has(file))return cache.get(file);
  const source=ts.transpileModule(readFileSync(file,'utf8'),{compilerOptions:{module:ts.ModuleKind.CommonJS,target:ts.ScriptTarget.ES2022}}).outputText;
  const compiledModule={exports:{}};
  const imports=name=>{
   if(name==='./db'||name==='@/lib/db')return {db:()=>database,runtime:()=>config};
   if(name==='./integrity'||name==='@/lib/integrity')return {ensureIntegrity:async()=>{}};
   if(name==='next/headers')return {headers:async()=>requestHeaders};
   if(name.startsWith('node:'))return nativeRequire(name);
   // Business suites inject an authenticated principal; verify_auth exercises real cookies and credentials.
   if(name==='./auth'&&file==='lib/service.ts'&&simulateIdentity)return {sessionMember:async()=>{
    if(!identity)return null;
    let member=await database.prepare('SELECT * FROM members WHERE email=?').bind(identity.email.toLowerCase()).first();
    const {AppError}=load('lib/domain.ts');
    if(!member||!member.active)throw new AppError('Acesso indisponível.',403);
    if(member.auth_id&&member.auth_id!==identity.userId)throw new AppError('Identidade não corresponde.',403);
    if(!member.auth_id){await database.prepare('UPDATE members SET auth_id=? WHERE id=?').bind(identity.userId,member.id).run();member={...member,auth_id:identity.userId};}
    return {...member,must_change:0};
   }};
   if(name==='@/app/chatgpt-auth')return {getChatGPTUser:async()=>identity};
   if(name.startsWith('@/lib/'))return load('lib/'+name.slice(6)+'.ts');
   if(name.startsWith('./'))return load('lib/'+name.slice(2)+'.ts');
   throw new Error('Unexpected import '+name);
  };
  new Function('require','module','exports',source)(imports,compiledModule,compiledModule.exports);cache.set(file,compiledModule.exports);return compiledModule.exports;
 }
 return {bridge,database,load,config(value){config=value;},identity(value){identity=value;},headers(value){requestHeaders=new Headers(value);},row:async(sql,...params)=>database.prepare(sql).bind(...params).first(),run:async(sql,...params)=>database.prepare(sql).bind(...params).run(),all:async(sql,...params)=>(await database.prepare(sql).bind(...params).all()).results};
}
