import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {harness} from './service_harness.mjs';
const temp=mkdtempSync(join(tmpdir(),'nautilus-resend-')),previousFetch=global.fetch;
const key='re_qa_resend_secret_for_isolated_tests',base={RESEND_API_KEY:key,EMAIL_FROM:'NAUTILUS <avisos@example.com>'};
try{
 const h=harness(join(temp,'qa.sqlite'));h.bridge({setup:true});
 const {actor,state,mutate}=h.load('lib/service.ts'),{emailSetup,sendResendEmail}=h.load('lib/resend.ts'),{flushNotifications}=h.load('lib/notifications.ts'),{POST}=h.load('app/api/[...path]/route.ts');
 const as=async(id)=>{h.identity({userId:id,email:id+'@example.com'});return actor();};
 const manager=await as('admin'),requester=await as('requester');
 let calls=0;global.fetch=async()=>{calls++;throw new Error('Envio não autorizado no teste.');};
 assert.equal(emailSetup().status,'missing');await assert.rejects(()=>mutate('emails/test',{operationKey:'qa-test-missing-config'},manager),e=>e.status===409);
 for(const config of [{...base,RESEND_API_KEY:'re_bad\nkey'},{...base,EMAIL_FROM:'NAUTILUS <avisos@resend.dev>'},{...base,EMAIL_FROM:'avisos@example.com\r\nBcc: other@example.com'},{...base,EMAIL_FROM:'avisos@example.com,other@example.com'}]){
  h.config({...config,EMAIL_ENABLED:'true'});assert.equal(emailSetup().status,'invalid');assert.equal((await state(manager)).emailReady,false);await flushNotifications('https://qa.example.com');
 }
 assert.equal(calls,0);
 h.config(base);assert.equal(emailSetup().ready,true);assert.equal(emailSetup().enabled,false);assert.equal((await state(manager)).emailReady,false);
 const managerState=await state(manager);assert.equal(managerState.emailSetup.domain,'example.com');assert.ok(!JSON.stringify(managerState).includes(key));
 const requesterState=await state(requester);assert.ok(!('emailSetup' in requesterState));assert.ok(!JSON.stringify(requesterState).includes('avisos@example.com'));
 await mutate('appointments',{operationKey:'qa-request-paused-email',equipmentId:'e',fuelId:'diesel',hourmeter:0},requester);await flushNotifications('https://qa.example.com');assert.equal(calls,0);
 assert.equal((await h.row('SELECT sum(attempts) n FROM notifications')).n,0);
 for(const profile of ['requester','planner','executor'])await assert.rejects(async()=>mutate('emails/test',{operationKey:'qa-self-only-test-000'},await as(profile)),e=>e.status===403);
 h.identity({userId:'admin',email:'admin@example.com'});
 const sent=[];global.fetch=async(url,options)=>{calls++;assert.equal(url,'https://api.resend.com/emails');assert.equal(options.headers.Authorization,'Bearer '+key);sent.push({headers:options.headers,body:JSON.parse(options.body)});return Response.json({id:'qa-provider-accepted'});};
 const result=await mutate('emails/test',{operationKey:'qa-self-only-test-000',to:'outsider@example.com',email:'other@example.com',subject:'Alterado',text:'Alterado'},manager);
 assert.equal(result.accepted,true);assert.deepEqual(sent[0].body.to,['admin@example.com']);assert.match(sent[0].body.subject,/Teste de envio/);assert.ok(!sent[0].body.cc&&!sent[0].body.bcc);assert.ok(!JSON.stringify(result).includes(key));
 assert.equal((await h.row('SELECT sum(attempts) n FROM notifications')).n,0);
 // Mesmo teste repetido preserva a chave enviada ao fornecedor; ele deduplica por 24 h.
 await mutate('emails/test',{operationKey:'qa-self-only-test-000'},manager);assert.equal(sent[0].headers['Idempotency-Key'],sent[1].headers['Idempotency-Key']);
 const req=()=>new Request('https://qa.example.com/api/emails/test',{method:'POST',headers:{Origin:'https://qa.example.com','Content-Type':'application/json'},body:JSON.stringify({operationKey:'qa-api-self-test-0001'})});
 assert.equal((await POST(req())).status,200);assert.equal((await POST(req())).status,200);assert.equal((await POST(req())).status,429);
 global.fetch=async()=>Response.json({error:'private '+key});await assert.rejects(()=>sendResendEmail('admin@example.com','Teste','Aviso','qa-invalid-response'),e=>e.status===502&&!e.message.includes(key));
 global.fetch=async()=>new Response('private '+key,{status:403});await assert.rejects(()=>sendResendEmail('admin@example.com','Teste','Aviso','qa-denied-response'),e=>e.status===502&&!e.message.includes(key));
 await h.run("UPDATE members SET active=0 WHERE id='admin'");await assert.rejects(()=>mutate('emails/test',{operationKey:'qa-revoked-test-0001'},manager),e=>e.status===403);
 console.log('PASS: Resend sem credenciais, configuração inválida, segredo isolado, alertas pausados, teste somente ao gestor autenticado, destinatário livre ignorado, idempotência, frequência e falhas do fornecedor. Nenhum e-mail real enviado.');
}finally{global.fetch=previousFetch;rmSync(temp,{recursive:true,force:true});}
