import assert from 'node:assert/strict';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
const temporary=mkdtempSync(join(tmpdir(),'nautilus-domain-'));
try{
  execFileSync(process.execPath,['node_modules/typescript/bin/tsc','lib/domain.ts','--outDir',temporary,'--target','ES2022','--module','commonjs','--skipLibCheck'],{stdio:'pipe'});
  const {milli,businessDeadline,safeCSV,dateISO}=createRequire(import.meta.url)(join(temporary,'domain.js'));
  assert.equal(milli(0.123),123);
  assert.throws(()=>milli(1.5,true));
  assert.throws(()=>milli(1.0001));
  assert.throws(()=>milli(-1));
  assert.equal(milli(0,false,true),0);
  assert.equal(businessDeadline('2026-10-09T18:30:00.000Z',2,['2026-10-12']),'2026-10-14T18:30:00.000Z');
  assert.equal(businessDeadline('2026-10-10T01:30:00.000Z',1,[]),'2026-10-13T01:30:00.000Z');
  assert.equal(safeCSV(-25),'"-25"');
  assert.equal(safeCSV('=SUM(A1:A2)'), '"\'=SUM(A1:A2)"');
  assert.equal(safeCSV('a"b'),'"a""b"');
  assert.throws(()=>dateISO('invalid'));
  assert.throws(()=>dateISO(new Date(Date.now()+3600000).toISOString()));
  console.log('PASS: precisão, dias úteis, feriado, Brasília, perfil e proteção CSV.');
}finally{rmSync(temporary,{recursive:true,force:true});}
